"""
Pydantic v2 schemas — request bodies, response models, WebSocket payloads.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────
class ConfigurationBase(BaseModel):
    active: bool = False
    project_name: str = ""
    lom_nr: str = ""
    description: str = ""
    interval_s: int = Field(1, ge=1)
    duration_h: int = Field(1000, ge=1)
    min_voltage: float = 0.0
    max_voltage: float = 10.0
    machine: str = "Machine-1"
    equipment_type: str = "DAQ9600"
    ip_address: str = "192.168.1.100"
    netmask: str = "255.255.255.0"
    channels: List[bool] = Field(default_factory=lambda: [False] * 10)


class ConfigurationCreate(ConfigurationBase):
    pass


class ConfigurationUpdate(ConfigurationBase):
    pass


class ConfigurationRead(ConfigurationBase):
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────────────
# Session
# ─────────────────────────────────────────────────────────────────────────────
class SessionRead(BaseModel):
    id: uuid.UUID
    configuration_id: int
    status: str
    error_message: Optional[str] = None
    started_at: datetime
    stopped_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class SessionStart(BaseModel):
    configuration_id: int


class SessionStop(BaseModel):
    session_id: uuid.UUID


# ─────────────────────────────────────────────────────────────────────────────
# Measurement
# ─────────────────────────────────────────────────────────────────────────────
class MeasurementRead(BaseModel):
    id: int
    session_id: uuid.UUID
    ch1:  Optional[float]
    ch2:  Optional[float]
    ch3:  Optional[float]
    ch4:  Optional[float]
    ch5:  Optional[float]
    ch6:  Optional[float]
    ch7:  Optional[float]
    ch8:  Optional[float]
    ch9:  Optional[float]
    ch10: Optional[float]
    recorded_at: datetime

    model_config = {"from_attributes": True}

    def to_channel_list(self) -> List[Optional[float]]:
        """Return [ch1..ch10] as a list for Vue frontend compatibility."""
        return [self.ch1, self.ch2, self.ch3, self.ch4, self.ch5,
                self.ch6, self.ch7, self.ch8, self.ch9, self.ch10]


# ─────────────────────────────────────────────────────────────────────────────
# WebSocket live payload
# ─────────────────────────────────────────────────────────────────────────────
class LiveReading(BaseModel):
    """Sent over WebSocket /ws/live/{config_id} on every DAQ interval."""
    session_id: str
    configuration_id: int
    timestamp: str                   # "DD.MM.YY HH:MM"
    values: List[Optional[float]]    # always 10 items
    status: str                      # "ok" | "error"
    error: Optional[str] = None


# ─────────────────────────────────────────────────────────────────────────────
# Generic responses
# ─────────────────────────────────────────────────────────────────────────────
class StatusResponse(BaseModel):
    ok: bool
    message: str = ""
