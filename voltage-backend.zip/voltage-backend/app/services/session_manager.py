"""
session_manager.py  —  Fully Isolated Async DAQ Task Manager
=============================================================

Design Goals
------------
1. Every config slot runs its own independent asyncio.Task.
2. A crash / error in one slot NEVER touches other slots.
3. Each physical IP address gets an asyncio.Semaphore(1) so two slots
   sharing the same instrument are safely serialised at the VISA level.
4. A lightweight watchdog coroutine monitors all tasks; if one dies
   unexpectedly it logs clearly and updates the session status.
5. All DB writes go through a per-slot queue so back-pressure from
   a slow DB never blocks the DAQ read loop.

Slot Lifecycle
--------------
  IDLE  ──start()──►  RUNNING  ──stop()──►  STOPPING ──►  IDLE
                            │                                ▲
                            └──── error / complete ─────────┘
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional

from sqlalchemy import update

from app.core.config import settings
from app.daq.driver_factory import get_driver
from app.db.database import AsyncSessionLocal
from app.models.models import Configuration, Measurement, MeasurementSession
from app.schemas.schemas import LiveReading
from app.services.ws_manager import ws_manager

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Slot state
# ─────────────────────────────────────────────────────────────────────────────
class SlotStatus(str, Enum):
    IDLE      = "idle"
    RUNNING   = "running"
    STOPPING  = "stopping"
    ERROR     = "error"
    COMPLETED = "completed"


@dataclass
class SlotState:
    """Runtime state for one config slot."""
    config_id: int
    session_id: str                          # UUID string
    status: SlotStatus = SlotStatus.IDLE
    task: Optional[asyncio.Task] = None
    stop_event: asyncio.Event = field(default_factory=asyncio.Event)
    error_message: Optional[str] = None
    samples_written: int = 0
    started_at: Optional[datetime] = None
    last_reading_at: Optional[datetime] = None

    # Per-slot write queue: DAQ loop pushes, writer coroutine drains to DB
    write_queue: asyncio.Queue = field(default_factory=lambda: asyncio.Queue(maxsize=500))


# ─────────────────────────────────────────────────────────────────────────────
# Manager
# ─────────────────────────────────────────────────────────────────────────────
class SessionManager:
    """
    Singleton.  One SlotState per running config slot.
    One asyncio.Semaphore per unique IP address (VISA serialisation).
    """

    def __init__(self) -> None:
        # config_id → SlotState
        self._slots: Dict[int, SlotState] = {}
        # ip_address → Semaphore(1)  — prevents concurrent VISA on same device
        self._ip_locks: Dict[str, asyncio.Semaphore] = {}
        # watchdog task
        self._watchdog_task: Optional[asyncio.Task] = None

    # ── Public API ────────────────────────────────────────────────────────────

    async def start(self, config_id: int) -> MeasurementSession:
        """
        Start a new DAQ task for config_id.
        Raises ValueError if the slot is already running.
        """
        if config_id in self._slots and self._slots[config_id].status == SlotStatus.RUNNING:
            raise ValueError(f"Config {config_id} is already running.")

        async with AsyncSessionLocal() as db:
            config = await db.get(Configuration, config_id)
            if config is None:
                raise ValueError(f"Configuration {config_id} not found.")
            if not config.active:
                raise ValueError(f"Configuration {config_id} is not active.")

            session = MeasurementSession(configuration_id=config_id, status="running")
            db.add(session)
            await db.commit()
            await db.refresh(session)

        session_id = str(session.id)

        # Snapshot config for the isolated task
        cfg = _snapshot(config)

        # Create per-slot state
        slot = SlotState(
            config_id=config_id,
            session_id=session_id,
            status=SlotStatus.RUNNING,
            started_at=datetime.now(timezone.utc),
        )
        self._slots[config_id] = slot

        # Ensure IP semaphore exists
        if cfg["ip_address"] not in self._ip_locks:
            self._ip_locks[cfg["ip_address"]] = asyncio.Semaphore(1)

        # Spawn isolated task pair: DAQ reader + DB writer
        slot.task = asyncio.create_task(
            self._run_slot(slot, cfg),
            name=f"daq-slot-{config_id}",
        )

        # Ensure watchdog is running
        self._ensure_watchdog()

        logger.info("[Slot %s] Started  session=%s", config_id, session_id[:8])
        return session

    async def stop(self, config_id: int) -> None:
        """Request graceful stop of a running slot."""
        slot = self._slots.get(config_id)
        if slot is None or slot.status != SlotStatus.RUNNING:
            raise ValueError(f"Slot {config_id} is not running.")

        logger.info("[Slot %s] Stop requested", config_id)
        slot.status = SlotStatus.STOPPING
        slot.stop_event.set()           # signals the DAQ loop to exit cleanly

        # Give the task up to 10 s to wrap up, then cancel
        try:
            await asyncio.wait_for(asyncio.shield(slot.task), timeout=10.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            if slot.task and not slot.task.done():
                slot.task.cancel()
                try:
                    await slot.task
                except asyncio.CancelledError:
                    pass

    async def stop_by_session(self, session_id: str) -> None:
        """Stop a slot identified by session UUID string."""
        for config_id, slot in self._slots.items():
            if slot.session_id == session_id:
                await self.stop(config_id)
                return
        raise ValueError(f"No running slot with session_id={session_id[:8]}")

    def is_running(self, config_id: int) -> bool:
        slot = self._slots.get(config_id)
        return slot is not None and slot.status == SlotStatus.RUNNING

    def get_status(self, config_id: int) -> Optional[dict]:
        slot = self._slots.get(config_id)
        if slot is None:
            return None
        return {
            "config_id": slot.config_id,
            "session_id": slot.session_id,
            "status": slot.status.value,
            "samples_written": slot.samples_written,
            "started_at": slot.started_at.isoformat() if slot.started_at else None,
            "last_reading_at": slot.last_reading_at.isoformat() if slot.last_reading_at else None,
            "error": slot.error_message,
        }

    def all_statuses(self) -> List[dict]:
        return [self.get_status(cid) for cid in self._slots]

    @property
    def active_session_ids(self) -> List[str]:
        return [
            s.session_id for s in self._slots.values()
            if s.status == SlotStatus.RUNNING
        ]

    # ── Slot runner (isolated per config) ────────────────────────────────────

    async def _run_slot(self, slot: SlotState, cfg: dict) -> None:
        """
        Top-level coroutine for one slot.
        Spawns two sub-tasks that run in parallel:
          • _daq_reader  — reads from instrument, pushes to slot.write_queue
          • _db_writer   — drains write_queue, INSERT to PostgreSQL

        If _daq_reader raises, _db_writer is cancelled and vice-versa.
        Either way the other slots are completely unaffected.
        """
        ip_lock = self._ip_locks[cfg["ip_address"]]

        reader_task = asyncio.create_task(
            self._daq_reader(slot, cfg, ip_lock),
            name=f"daq-reader-{slot.config_id}",
        )
        writer_task = asyncio.create_task(
            self._db_writer(slot),
            name=f"daq-writer-{slot.config_id}",
        )

        try:
            # Wait for BOTH to finish — if reader exits, signal writer to drain+stop
            done, pending = await asyncio.wait(
                {reader_task, writer_task},
                return_when=asyncio.FIRST_EXCEPTION,
            )

            # Propagate any exception from the finished task
            for t in done:
                exc = t.exception()
                if exc is not None:
                    raise exc

            # If reader finished normally, let writer drain the queue
            await slot.write_queue.join()

        except asyncio.CancelledError:
            pass

        except Exception as exc:
            slot.error_message = str(exc)
            slot.status = SlotStatus.ERROR
            logger.error("[Slot %s] Error: %s", slot.config_id, exc, exc_info=True)
            await self._set_db_status(slot.session_id, "error", str(exc))
            # Notify frontend
            await ws_manager.broadcast(slot.config_id, _error_payload(slot, str(exc)))

        finally:
            # Cancel any surviving sub-tasks
            for t in (reader_task, writer_task):
                if not t.done():
                    t.cancel()
                    try:
                        await t
                    except (asyncio.CancelledError, Exception):
                        pass

            # Final status update if not already set to error
            if slot.status not in (SlotStatus.ERROR,):
                final = "stopped" if slot.status == SlotStatus.STOPPING else "completed"
                slot.status = SlotStatus.COMPLETED
                await self._set_db_status(slot.session_id, final)

            self._slots.pop(slot.config_id, None)
            logger.info("[Slot %s] Task finished  samples=%s", slot.config_id, slot.samples_written)

    # ── DAQ reader sub-task ───────────────────────────────────────────────────

    async def _daq_reader(
        self,
        slot: SlotState,
        cfg: dict,
        ip_lock: asyncio.Semaphore,
    ) -> None:
        """
        Connects to the instrument, reads one interval at a time,
        pushes readings onto slot.write_queue.

        The ip_lock ensures that if two slots share the same IP
        (unusual but possible), VISA calls are serialised.
        """
        active_channels = [i + 1 for i, on in enumerate(cfg["channels"]) if on]
        total_samples   = int(cfg["duration_h"] * 3600 / max(cfg["interval_s"], 1))
        driver = get_driver(cfg["equipment_type"], cfg["ip_address"])

        async with ip_lock:
            await driver.connect()
            try:
                await driver.setup_scan(
                    active_channels=active_channels,
                    interval_s=cfg["interval_s"],
                    min_v=cfg["min_voltage"],
                    max_v=cfg["max_voltage"],
                )

                for _ in range(total_samples):
                    if slot.stop_event.is_set():
                        break

                    # Sleep interval — interruptible by stop_event
                    try:
                        await asyncio.wait_for(
                            slot.stop_event.wait(),
                            timeout=cfg["interval_s"],
                        )
                        break   # stop_event fired during sleep
                    except asyncio.TimeoutError:
                        pass    # normal — interval elapsed, take reading

                    values = await driver.read_channels(active_channels)
                    now    = datetime.now(timezone.utc)

                    slot.last_reading_at = now
                    slot.samples_written += 1   # optimistic count

                    # Push to write queue (non-blocking — drops if full)
                    reading = {
                        "session_id": slot.session_id,
                        "config_id":  cfg["id"],
                        "values":     values,
                        "recorded_at": now,
                    }
                    try:
                        slot.write_queue.put_nowait(reading)
                    except asyncio.QueueFull:
                        logger.warning("[Slot %s] Write queue full — dropping reading", slot.config_id)

                    # Live push to WebSocket (fire-and-forget, never blocks reader)
                    asyncio.create_task(
                        ws_manager.broadcast(
                            cfg["id"],
                            LiveReading(
                                session_id=slot.session_id,
                                configuration_id=cfg["id"],
                                timestamp=now.strftime("%d.%m.%y %H:%M"),
                                values=values,
                                status="ok",
                            ).model_dump(),
                        )
                    )

            finally:
                try:
                    await driver.stop_scan()
                except Exception:
                    pass
                await driver.disconnect()

    # ── DB writer sub-task ────────────────────────────────────────────────────

    async def _db_writer(self, slot: SlotState) -> None:
        """
        Drains slot.write_queue and batch-INSERTs into PostgreSQL.
        Runs independently from the reader — DB slowness never stalls the DAQ.
        Exits when it receives the sentinel None from the queue.
        """
        BATCH_SIZE = 20   # rows per INSERT
        batch: List[dict] = []

        async def flush(rows: List[dict]) -> None:
            if not rows:
                return
            async with AsyncSessionLocal() as db:
                db.add_all([
                    Measurement(
                        session_id=uuid.UUID(r["session_id"]),
                        recorded_at=r["recorded_at"],
                        **{f"ch{i+1}": v for i, v in enumerate(r["values"])},
                    )
                    for r in rows
                ])
                await db.commit()

        try:
            while True:
                try:
                    item = await asyncio.wait_for(slot.write_queue.get(), timeout=2.0)
                except asyncio.TimeoutError:
                    # Flush partial batch on timeout even if not full
                    await flush(batch)
                    batch = []
                    # Exit if reader is done AND queue is empty
                    if slot.stop_event.is_set() and slot.write_queue.empty():
                        break
                    continue

                if item is None:    # sentinel — drain and exit
                    await flush(batch)
                    slot.write_queue.task_done()
                    break

                batch.append(item)
                slot.write_queue.task_done()

                if len(batch) >= BATCH_SIZE:
                    await flush(batch)
                    batch = []

        except asyncio.CancelledError:
            # Flush whatever is in the batch before exiting
            if batch:
                try:
                    await flush(batch)
                except Exception as exc:
                    logger.error("[Slot %s] Final flush failed: %s", slot.config_id, exc)
            raise

    # ── Watchdog ──────────────────────────────────────────────────────────────

    def _ensure_watchdog(self) -> None:
        if self._watchdog_task is None or self._watchdog_task.done():
            self._watchdog_task = asyncio.create_task(
                self._watchdog(), name="daq-watchdog"
            )

    async def _watchdog(self) -> None:
        """
        Polls every 5 s, logs dead tasks, cleans up stale slot entries.
        Does NOT restart tasks automatically — restarts are always user-triggered.
        """
        logger.debug("Watchdog started")
        while self._slots:
            await asyncio.sleep(5)
            for config_id, slot in list(self._slots.items()):
                if slot.task and slot.task.done():
                    exc = slot.task.exception() if not slot.task.cancelled() else None
                    if exc:
                        logger.warning(
                            "[Watchdog] Slot %s task died unexpectedly: %s",
                            config_id, exc,
                        )
                    # Slot cleanup is handled inside _run_slot finally block
        logger.debug("Watchdog exiting — no active slots")

    # ── DB helpers ────────────────────────────────────────────────────────────

    async def _set_db_status(
        self,
        session_id: str,
        status: str,
        error: Optional[str] = None,
    ) -> None:
        try:
            async with AsyncSessionLocal() as db:
                await db.execute(
                    update(MeasurementSession)
                    .where(MeasurementSession.id == uuid.UUID(session_id))
                    .values(
                        status=status,
                        error_message=error,
                        stopped_at=datetime.now(timezone.utc),
                    )
                )
                await db.commit()
        except Exception as exc:
            logger.error("Failed to update session status in DB: %s", exc)


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _snapshot(config: Configuration) -> dict:
    """Extract plain dict from ORM object — safe to pass into a task."""
    return {
        "id":             config.id,
        "equipment_type": config.equipment_type,
        "ip_address":     config.ip_address,
        "channels":       list(config.channels),
        "interval_s":     config.interval_s,
        "duration_h":     config.duration_h,
        "min_voltage":    config.min_voltage,
        "max_voltage":    config.max_voltage,
    }


def _error_payload(slot: SlotState, error: str) -> dict:
    return LiveReading(
        session_id=slot.session_id,
        configuration_id=slot.config_id,
        timestamp=datetime.now(timezone.utc).strftime("%d.%m.%y %H:%M"),
        values=[None] * 10,
        status="error",
        error=error,
    ).model_dump()


# Global singleton
session_manager = SessionManager()
