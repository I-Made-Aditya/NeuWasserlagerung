"""
ws_manager.py
=============
Manages WebSocket connections per config_id.
Multiple frontend tabs can subscribe to the same config.
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from typing import Dict, Set

from fastapi import WebSocket

logger = logging.getLogger(__name__)


class WebSocketManager:
    def __init__(self) -> None:
        # config_id → set of connected WebSocket clients
        self._connections: Dict[int, Set[WebSocket]] = defaultdict(set)

    async def connect(self, config_id: int, ws: WebSocket) -> None:
        await ws.accept()
        self._connections[config_id].add(ws)
        logger.info("WS connected config=%s  total=%s", config_id, len(self._connections[config_id]))

    def disconnect(self, config_id: int, ws: WebSocket) -> None:
        self._connections[config_id].discard(ws)
        logger.info("WS disconnected config=%s  remaining=%s", config_id, len(self._connections[config_id]))

    async def broadcast(self, config_id: int, data: dict) -> None:
        """Send JSON payload to all subscribers of config_id."""
        dead: Set[WebSocket] = set()
        for ws in list(self._connections.get(config_id, set())):
            try:
                await ws.send_text(json.dumps(data, default=str))
            except Exception:
                dead.add(ws)
        for ws in dead:
            self.disconnect(config_id, ws)


# Global singleton
ws_manager = WebSocketManager()
