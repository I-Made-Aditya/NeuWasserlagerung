"""
driver_factory.py
=================
Returns the correct driver instance based on equipment_type string.
"""

from app.daq.base_driver import BaseDaqDriver
from app.daq.daq6510_driver import DAQ6510Driver
from app.daq.daq9600_driver import DAQ9600Driver


def get_driver(equipment_type: str, ip_address: str) -> BaseDaqDriver:
    """
    Parameters
    ----------
    equipment_type : "DAQ6510" | "DAQ9600"
    ip_address     : e.g. "192.168.1.101"

    Returns
    -------
    BaseDaqDriver subclass instance (not yet connected)
    """
    drivers = {
        "DAQ6510": DAQ6510Driver,
        "DAQ9600": DAQ9600Driver,
    }
    cls = drivers.get(equipment_type.upper())
    if cls is None:
        raise ValueError(
            f"Unknown equipment type '{equipment_type}'. "
            f"Supported: {list(drivers.keys())}"
        )
    return cls(ip_address)
