"""
daq9600_driver.py
=================
Concrete driver for the Keithley DAQ9600.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from app.daq.base_driver import BaseDaqDriver
from app.daq.scpi_commands import DAQ9600Commands as CMD

logger = logging.getLogger(__name__)


class DAQ9600Driver(BaseDaqDriver):

    async def setup_scan(
        self,
        active_channels: List[int],
        interval_s: float,
        min_v: float,
        max_v: float,
    ) -> None:
        logger.info("DAQ9600 @ %s — setup scan ch=%s", self.ip_address, active_channels)

        await self.write(CMD.RESET)
        await self.write(CMD.CLEAR_STATUS)
        await self.write(CMD.BEEP_OFF)
        await self.write(CMD.DISPLAY_OFF)

        # Set DC voltage on all channels first, then limit to active ones
        await self.write(CMD.FUNC_VOLT_DC)

        if max_v > 0:
            await self.write(CMD.volt_range(max_v))
        else:
            await self.write(CMD.VOLT_RANGE_AUTO)

        await self.write(CMD.volt_nplc(1))

        # Buffer
        await self.write(CMD.BUFF_CLEAR)
        await self.write(CMD.buff_size(100000))
        await self.write(CMD.BUFF_CTRL_NEXT)

        # Scan setup
        await self.write(CMD.set_scan_channels(active_channels))
        await self.write(CMD.SCAN_COUNT_INF)
        await self.write(CMD.scan_interval(interval_s))

        logger.info("DAQ9600 setup complete.")

    async def read_channels(self, active_channels: List[int]) -> List[Optional[float]]:
        raw = await self.query(CMD.READ)
        parsed = [float(v) for v in raw.strip().split(",") if v.strip()]

        values: List[Optional[float]] = [None] * 10
        for idx, ch in enumerate(active_channels):
            if idx < len(parsed):
                values[ch - 1] = parsed[idx]
        return values

    async def stop_scan(self) -> None:
        logger.info("DAQ9600 @ %s — stopping scan", self.ip_address)
        try:
            await self.write(CMD.SCAN_STOP)
            await self.write(CMD.DISPLAY_ON)
        except Exception as exc:
            logger.warning("DAQ9600 stop error: %s", exc)
