"""
daq6510_driver.py
=================
Concrete driver for the Keithley DAQ6510.
Uses SCPI commands from scpi_commands.DAQ6510Commands.
"""

from __future__ import annotations

import logging
from typing import List, Optional

from app.daq.base_driver import BaseDaqDriver
from app.daq.scpi_commands import DAQ6510Commands as CMD

logger = logging.getLogger(__name__)


class DAQ6510Driver(BaseDaqDriver):

    async def setup_scan(
        self,
        active_channels: List[int],
        interval_s: float,
        min_v: float,
        max_v: float,
    ) -> None:
        logger.info("DAQ6510 @ %s — setup scan ch=%s", self.ip_address, active_channels)

        await self.write(CMD.RESET)
        await self.write(CMD.CLEAR_STATUS)
        await self.write(CMD.BEEP_OFF)
        await self.write(CMD.DISPLAY_OFF)

        # Set DC voltage function
        await self.write(CMD.FUNC_VOLT_DC)

        # Auto-range or fixed range based on max voltage
        if max_v > 0:
            await self.write(CMD.volt_range(max_v))
        else:
            await self.write(CMD.VOLT_RANGE_AUTO)

        await self.write(CMD.volt_nplc(1))

        # Buffer setup
        await self.write(CMD.BUFF_CLEAR)
        await self.write(CMD.buff_size(100000))
        await self.write(CMD.BUFF_FEED_SENS)
        await self.write(CMD.BUFF_CTRL_NEXT)

        # Scan channel list and interval
        await self.write(CMD.set_scan_channels(active_channels))
        await self.write(CMD.SCAN_COUNT_INF)
        await self.write(CMD.scan_interval(interval_s))

        logger.info("DAQ6510 setup complete.")

    async def read_channels(self, active_channels: List[int]) -> List[Optional[float]]:
        """
        Trigger READ? and parse into a 10-element list.
        Inactive channels are None.
        """
        raw = await self.query(CMD.READ)
        # DAQ6510 READ? returns comma-separated floats in scan-channel order
        parsed = [float(v) for v in raw.strip().split(",") if v.strip()]

        values: List[Optional[float]] = [None] * 10
        for idx, ch in enumerate(active_channels):
            if idx < len(parsed):
                values[ch - 1] = parsed[idx]  # ch is 1-based
        return values

    async def stop_scan(self) -> None:
        logger.info("DAQ6510 @ %s — aborting scan", self.ip_address)
        try:
            await self.write(CMD.SCAN_STOP)
            await self.write(CMD.DISPLAY_ON)
        except Exception as exc:
            logger.warning("DAQ6510 stop error: %s", exc)
