"""
scpi_commands.py
================
Single source of truth for all SCPI command strings used with
Keithley DAQ6510 and DAQ9600 instruments.

References
----------
- Keithley DAQ6510 Reference Manual  (177-3000-01 Rev. C)
- Keithley DAQ9600 Reference Manual  (DAQ9600-901-01 Rev. A)

Usage
-----
    from app.daq.scpi_commands import DAQ6510Commands as D65

    instrument.write(D65.reset())
    instrument.write(D65.set_scan_channels([1, 2, 3]))
    response = instrument.query(D65.READ)
"""

from __future__ import annotations
from typing import List


# ─────────────────────────────────────────────────────────────────────────────
# DAQ6510  (Model 7700 / 7702 mux card assumed)
# ─────────────────────────────────────────────────────────────────────────────
class DAQ6510Commands:
    # ── Reset / identification ────────────────────────────────────────────────
    RESET       = "*RST"
    CLEAR_STATUS= "*CLS"
    IDENTIFY    = "*IDN?"
    OPERATION_COMPLETE = "*OPC?"

    # ── System ────────────────────────────────────────────────────────────────
    BEEP_OFF    = "SYST:BEEP:STAT OFF"
    BEEP_ON     = "SYST:BEEP:STAT ON"
    DISPLAY_OFF = "DISP:STAT OFF"
    DISPLAY_ON  = "DISP:STAT ON"
    ERROR_QUERY = "SYST:ERR?"

    # ── Sense / function ─────────────────────────────────────────────────────
    # Set the measurement function for a channel list
    FUNC_VOLT_DC = "SENS:FUNC 'VOLT:DC'"
    FUNC_VOLT_AC = "SENS:FUNC 'VOLT:AC'"
    FUNC_CURR_DC = "SENS:FUNC 'CURR:DC'"
    FUNC_RES     = "SENS:FUNC 'RES'"
    FUNC_TEMP    = "SENS:FUNC 'TEMP'"

    # DC Voltage range / NPLC
    VOLT_RANGE_AUTO     = "SENS:VOLT:RANG:AUTO ON"
    VOLT_NPLC_DEFAULT   = "SENS:VOLT:NPLC 1"

    @staticmethod
    def volt_range(volts: float) -> str:
        """e.g. SENS:VOLT:RANG 10"""
        return f"SENS:VOLT:RANG {volts}"

    @staticmethod
    def volt_nplc(nplc: float) -> str:
        """Power-line cycles per reading. 0.001–15 (50/60 Hz)."""
        return f"SENS:VOLT:NPLC {nplc}"

    # ── Route / scan ─────────────────────────────────────────────────────────
    @staticmethod
    def set_scan_channels(channels: List[int], slot: int = 1) -> str:
        """
        Build the channel list string.
        channels: 1-based list, e.g. [1,2,3] → "@101:103"
        slot: card slot number (default 1)
        """
        ch_strs = [f"{slot}{str(ch).zfill(2)}" for ch in channels]
        ch_list = ",".join(ch_strs)
        return f"ROUT:SCAN:CRE (@{ch_list})"

    SCAN_COUNT_INF  = "ROUT:SCAN:COUN:SCAN 0"     # 0 = infinite

    @staticmethod
    def scan_count(n: int) -> str:
        return f"ROUT:SCAN:COUN:SCAN {n}"

    @staticmethod
    def scan_interval(seconds: float) -> str:
        """Interval between scan passes."""
        return f"ROUT:SCAN:INT {seconds}"

    SCAN_START  = "INIT"
    SCAN_STOP   = "ABOR"

    # ── Read / fetch ─────────────────────────────────────────────────────────
    READ        = "READ?"                   # triggers + fetches one reading
    FETCH       = "FETC?"                   # fetches without triggering
    TRACE_DATA  = "TRAC:DATA? 1, 99999"     # bulk fetch all buffered readings

    # ── Buffer ────────────────────────────────────────────────────────────────
    BUFF_CLEAR  = "TRAC:CLE"
    BUFF_SIZE   = "TRAC:POIN 10000"

    @staticmethod
    def buff_size(n: int) -> str:
        return f"TRAC:POIN {n}"

    BUFF_FEED_SENS  = "TRAC:FEED SENS"
    BUFF_FEED_CALC  = "TRAC:FEED CALC"
    BUFF_CTRL_NEXT  = "TRAC:FEED:CONT NEXT"
    BUFF_CTRL_OFF   = "TRAC:FEED:CONT NEVER"

    # ── Status / event ────────────────────────────────────────────────────────
    STATUS_OPER_QUERY   = "STAT:OPER?"
    STATUS_QUES_QUERY   = "STAT:QUES?"
    SERVICE_REQ_ENABLE  = "*SRE 1"


# ─────────────────────────────────────────────────────────────────────────────
# DAQ9600  (Model 9300 mux card)
# ─────────────────────────────────────────────────────────────────────────────
class DAQ9600Commands:
    # ── Reset / identification ────────────────────────────────────────────────
    RESET       = "*RST"
    CLEAR_STATUS= "*CLS"
    IDENTIFY    = "*IDN?"
    OPERATION_COMPLETE = "*OPC?"

    # ── System ────────────────────────────────────────────────────────────────
    BEEP_OFF    = "SYST:BEEP:STAT OFF"
    BEEP_ON     = "SYST:BEEP:STAT ON"
    DISPLAY_OFF = "DISP:ENAB OFF"
    DISPLAY_ON  = "DISP:ENAB ON"
    ERROR_QUERY = "SYST:ERR?"

    # ── Sense / function ─────────────────────────────────────────────────────
    FUNC_VOLT_DC = "SENS:FUNC 'VOLT:DC', (@101:110)"
    FUNC_VOLT_AC = "SENS:FUNC 'VOLT:AC', (@101:110)"
    FUNC_CURR_DC = "SENS:FUNC 'CURR:DC', (@101:110)"
    FUNC_RES     = "SENS:FUNC 'RES', (@101:110)"
    FUNC_TEMP    = "SENS:FUNC 'TEMP', (@101:110)"

    VOLT_RANGE_AUTO = "SENS:VOLT:DC:RANG:AUTO ON, (@101:110)"
    VOLT_NPLC_1     = "SENS:VOLT:DC:NPLC 1, (@101:110)"

    @staticmethod
    def volt_range(volts: float, slot: int = 1) -> str:
        return f"SENS:VOLT:DC:RANG {volts}, (@{slot}01:{slot}10)"

    @staticmethod
    def volt_nplc(nplc: float, slot: int = 1) -> str:
        return f"SENS:VOLT:DC:NPLC {nplc}, (@{slot}01:{slot}10)"

    # ── Route / scan ─────────────────────────────────────────────────────────
    @staticmethod
    def set_scan_channels(channels: List[int], slot: int = 1) -> str:
        """
        Build channel list.  channels: 1-based list, slot default 1.
        [1,2,3] → ROUT:SCAN (@101,102,103)
        """
        ch_strs = [f"{slot}{str(ch).zfill(2)}" for ch in channels]
        ch_list = ",".join(ch_strs)
        return f"ROUT:SCAN (@{ch_list})"

    @staticmethod
    def scan_count(n: int) -> str:
        """0 = continuous."""
        return f"ROUT:SCAN:COUN {n}"

    SCAN_COUNT_INF  = "ROUT:SCAN:COUN 0"

    @staticmethod
    def scan_interval(seconds: float) -> str:
        return f"ROUT:SCAN:INT {seconds}"

    SCAN_START  = "ROUT:SCAN:STAT ON"
    SCAN_STOP   = "ROUT:SCAN:STAT OFF"

    # ── Read / fetch ─────────────────────────────────────────────────────────
    READ            = "READ?"
    FETCH           = "FETC?"
    TRACE_LAST_N    = "TRAC:DATA:SEL? LAST,{n}"    # use .format(n=count)

    @staticmethod
    def trace_last(n: int) -> str:
        return f"TRAC:DATA:SEL? LAST,{n}"

    # ── Buffer ────────────────────────────────────────────────────────────────
    BUFF_CLEAR      = "TRAC:CLE"

    @staticmethod
    def buff_size(n: int) -> str:
        return f"TRAC:POIN {n}"

    BUFF_CTRL_NEXT  = "TRAC:FEED:CONT NEXT"
    BUFF_CTRL_OFF   = "TRAC:FEED:CONT NEVER"

    # ── Status ────────────────────────────────────────────────────────────────
    STATUS_OPER_QUERY   = "STAT:OPER?"
    STATUS_QUES_QUERY   = "STAT:QUES?"


# ─────────────────────────────────────────────────────────────────────────────
# Shared VISA connection helpers (equipment-independent)
# ─────────────────────────────────────────────────────────────────────────────
class VISAAddress:
    @staticmethod
    def tcp(ip: str, port: int = 5025) -> str:
        """TCPIP VISA resource string for raw socket (no VXI-11)."""
        return f"TCPIP0::{ip}::{port}::SOCKET"

    @staticmethod
    def vxi11(ip: str) -> str:
        """VXI-11 VISA resource string (slower but more compatible)."""
        return f"TCPIP0::{ip}::inst0::INSTR"
