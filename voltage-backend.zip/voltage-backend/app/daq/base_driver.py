"""
base_driver.py
==============
Abstract base class that both DAQ6510Driver and DAQ9600Driver implement.
Handles the PyVISA connection lifecycle and SCPI I/O.
"""

from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import List, Optional

import pyvisa

from app.core.config import settings

logger = logging.getLogger(__name__)


class BaseDaqDriver(ABC):
    """
    Wraps a PyVISA instrument resource.
    Subclasses implement `setup_scan()` and `read_channels()`.
    """

    def __init__(self, ip_address: str) -> None:
        self.ip_address = ip_address
        self._rm: Optional[pyvisa.ResourceManager] = None
        self._instr = None

    # ── Connection ────────────────────────────────────────────────────────────
    async def connect(self) -> None:
        """Open VISA connection in a thread pool (PyVISA is blocking)."""
        await asyncio.get_event_loop().run_in_executor(None, self._connect_sync)
        logger.info("Connected to %s", self.ip_address)

    def _connect_sync(self) -> None:
        from app.daq.scpi_commands import VISAAddress
        self._rm = pyvisa.ResourceManager()
        resource_str = VISAAddress.tcp(self.ip_address)
        self._instr = self._rm.open_resource(resource_str)
        self._instr.timeout = settings.DAQ_READ_TIMEOUT * 1000  # ms
        self._instr.read_termination  = "\n"
        self._instr.write_termination = "\n"

    async def disconnect(self) -> None:
        await asyncio.get_event_loop().run_in_executor(None, self._disconnect_sync)
        logger.info("Disconnected from %s", self.ip_address)

    def _disconnect_sync(self) -> None:
        try:
            if self._instr:
                self._instr.close()
            if self._rm:
                self._rm.close()
        except Exception as exc:
            logger.warning("Disconnect error: %s", exc)
        finally:
            self._instr = None
            self._rm = None

    # ── Low-level I/O ─────────────────────────────────────────────────────────
    async def write(self, cmd: str) -> None:
        await asyncio.get_event_loop().run_in_executor(
            None, self._instr.write, cmd
        )

    async def query(self, cmd: str) -> str:
        return await asyncio.get_event_loop().run_in_executor(
            None, self._instr.query, cmd
        )

    async def identify(self) -> str:
        return (await self.query("*IDN?")).strip()

    # ── Abstract interface ────────────────────────────────────────────────────
    @abstractmethod
    async def setup_scan(
        self,
        active_channels: List[int],   # 1-based, e.g. [1,2,3]
        interval_s: float,
        min_v: float,
        max_v: float,
    ) -> None:
        """Configure the instrument for scanning."""

    @abstractmethod
    async def read_channels(self, active_channels: List[int]) -> List[Optional[float]]:
        """
        Trigger one scan and return a list of 10 values.
        Inactive channels → None.
        """

    @abstractmethod
    async def stop_scan(self) -> None:
        """Abort/stop the running scan."""
