import logging
import sys
from app.core.config import settings


def setup_logging() -> None:
    level = getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO)
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    logging.basicConfig(stream=sys.stdout, level=level, format=fmt)
    # Quiet noisy libs
    logging.getLogger("pyvisa").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
