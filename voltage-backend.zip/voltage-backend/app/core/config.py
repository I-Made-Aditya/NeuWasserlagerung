from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:password@localhost:5432/voltage_monitoring"

    # App
    APP_ENV: str = "development"
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000
    LOG_LEVEL: str = "info"

    # DAQ timeouts
    DAQ_CONNECT_TIMEOUT: int = 5
    DAQ_READ_TIMEOUT: int = 10

    @property
    def is_dev(self) -> bool:
        return self.APP_ENV == "development"


settings = Settings()
