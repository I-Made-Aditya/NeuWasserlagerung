from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import Configuration
from app.schemas.schemas import ConfigurationCreate, ConfigurationRead, ConfigurationUpdate

router = APIRouter(prefix="/api/configs", tags=["configurations"])


@router.get("/", response_model=List[ConfigurationRead])
async def list_configs(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Configuration).order_by(Configuration.id))
    return result.scalars().all()


@router.get("/{config_id}", response_model=ConfigurationRead)
async def get_config(config_id: int, db: AsyncSession = Depends(get_db)):
    obj = await db.get(Configuration, config_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Configuration not found")
    return obj


@router.post("/", response_model=ConfigurationRead, status_code=status.HTTP_201_CREATED)
async def create_config(body: ConfigurationCreate, db: AsyncSession = Depends(get_db)):
    obj = Configuration(**body.model_dump())
    db.add(obj)
    await db.commit()
    await db.refresh(obj)
    return obj


@router.put("/{config_id}", response_model=ConfigurationRead)
async def update_config(
    config_id: int, body: ConfigurationUpdate, db: AsyncSession = Depends(get_db)
):
    obj = await db.get(Configuration, config_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Configuration not found")
    for field, value in body.model_dump().items():
        setattr(obj, field, value)
    await db.commit()
    await db.refresh(obj)
    return obj


@router.delete("/{config_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_config(config_id: int, db: AsyncSession = Depends(get_db)):
    obj = await db.get(Configuration, config_id)
    if obj is None:
        raise HTTPException(status_code=404, detail="Configuration not found")
    await db.delete(obj)
    await db.commit()
