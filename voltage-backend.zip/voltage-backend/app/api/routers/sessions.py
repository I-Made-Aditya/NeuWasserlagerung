from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import MeasurementSession
from app.schemas.schemas import SessionRead, SessionStart, SessionStop, StatusResponse
from app.services.session_manager import session_manager

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


@router.post("/start", response_model=SessionRead)
async def start_session(body: SessionStart):
    """
    Trigger: Vue frontend presses Start.
    Spawns an isolated async DAQ task for the given configuration.
    Multiple configs can be started in parallel — each runs independently.
    """
    try:
        session = await session_manager.start(body.configuration_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Could not start DAQ: {exc}")
    return session


@router.post("/stop", response_model=StatusResponse)
async def stop_session(body: SessionStop):
    """Gracefully stop a session by session UUID."""
    try:
        await session_manager.stop_by_session(str(body.session_id))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return StatusResponse(ok=True, message=f"Session {str(body.session_id)[:8]} stopped")


@router.post("/stop/{config_id}", response_model=StatusResponse)
async def stop_by_config(config_id: int):
    """Convenience: stop the running session for a config slot by config ID."""
    if not session_manager.is_running(config_id):
        raise HTTPException(status_code=404, detail=f"Slot {config_id} is not running")
    await session_manager.stop(config_id)
    return StatusResponse(ok=True, message=f"Slot {config_id} stopped")


@router.get("/active", response_model=List[str])
async def active_sessions():
    """List session IDs that are currently running."""
    return session_manager.active_session_ids


@router.get("/status", response_model=List[dict])
async def all_slot_statuses():
    """
    Real-time status of all known slots (running + recently finished).
    Includes samples_written, last_reading_at, error message.
    """
    return session_manager.all_statuses()


@router.get("/status/{config_id}", response_model=dict)
async def slot_status(config_id: int):
    status = session_manager.get_status(config_id)
    if status is None:
        raise HTTPException(status_code=404, detail=f"No slot info for config {config_id}")
    return status


@router.get("/{config_id}", response_model=List[SessionRead])
async def list_sessions(config_id: int, db: AsyncSession = Depends(get_db)):
    """Session history for a config slot (from DB)."""
    result = await db.execute(
        select(MeasurementSession)
        .where(MeasurementSession.configuration_id == config_id)
        .order_by(MeasurementSession.started_at.desc())
    )
    return result.scalars().all()
