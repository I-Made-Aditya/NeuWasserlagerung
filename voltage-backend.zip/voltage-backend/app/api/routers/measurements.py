from typing import List
import uuid

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.models.models import Measurement
from app.schemas.schemas import MeasurementRead

router = APIRouter(prefix="/api/measurements", tags=["measurements"])


@router.get("/{session_id}", response_model=List[MeasurementRead])
async def get_measurements(
    session_id: uuid.UUID,
    limit: int = Query(default=5000, le=50000),
    offset: int = Query(default=0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """Paginated measurement data for a session — used by Data & Graph modals."""
    result = await db.execute(
        select(Measurement)
        .where(Measurement.session_id == session_id)
        .order_by(Measurement.recorded_at.asc())
        .limit(limit)
        .offset(offset)
    )
    return result.scalars().all()
