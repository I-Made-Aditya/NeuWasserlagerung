from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from app.services.ws_manager import ws_manager

router = APIRouter(tags=["websocket"])


@router.websocket("/ws/live/{config_id}")
async def live_feed(config_id: int, ws: WebSocket):
    """
    Vue frontend connects here to receive real-time readings.
    Each message is a JSON LiveReading payload (see schemas.py).

    Connect URL: ws://localhost:8000/ws/live/{config_id}
    """
    await ws_manager.connect(config_id, ws)
    try:
        # Keep connection open — client sends nothing, server pushes data
        while True:
            await ws.receive_text()  # allows clean disconnect detection
    except WebSocketDisconnect:
        ws_manager.disconnect(config_id, ws)
