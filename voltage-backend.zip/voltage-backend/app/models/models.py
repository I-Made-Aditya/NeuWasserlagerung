"""
SQLAlchemy ORM models for the voltage monitoring system.

Tables
------
configurations   — one row per config slot (mirrors Vue ConfigRow)
sessions         — one row per Start→Stop measurement run
measurements     — one row per DAQ reading (real-time insert)
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    Boolean, DateTime, Float, ForeignKey,
    Integer, String, Text, func,
)
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────
class Configuration(Base):
    __tablename__ = "configurations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    active: Mapped[bool] = mapped_column(Boolean, default=False)

    # Project metadata
    project_name: Mapped[str] = mapped_column(String(64), default="")
    lom_nr: Mapped[str] = mapped_column(String(64), default="")
    description: Mapped[str] = mapped_column(String(128), default="")

    # Measurement parameters
    interval_s: Mapped[int] = mapped_column(Integer, default=1)     # seconds between readings
    duration_h: Mapped[int] = mapped_column(Integer, default=1000)  # total run duration in hours
    min_voltage: Mapped[float] = mapped_column(Float, default=0.0)
    max_voltage: Mapped[float] = mapped_column(Float, default=10.0)

    # Hardware
    machine: Mapped[str] = mapped_column(String(32), default="Machine-1")
    equipment_type: Mapped[str] = mapped_column(String(16), default="DAQ9600")  # DAQ9600 | DAQ6510
    ip_address: Mapped[str] = mapped_column(String(15), default="192.168.1.100")
    netmask: Mapped[str] = mapped_column(String(15), default="255.255.255.0")

    # 10-channel enable flags (stored as boolean array)
    channels: Mapped[List[bool]] = mapped_column(ARRAY(Boolean), default=list)

    # Timestamps
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    sessions: Mapped[List["MeasurementSession"]] = relationship(
        "MeasurementSession", back_populates="configuration", cascade="all, delete-orphan"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Measurement Session  (one per Start button press)
# ─────────────────────────────────────────────────────────────────────────────
class MeasurementSession(Base):
    __tablename__ = "sessions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    configuration_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("configurations.id", ondelete="CASCADE"), index=True
    )

    status: Mapped[str] = mapped_column(
        String(16), default="running"  # running | stopped | error | completed
    )
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    stopped_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    configuration: Mapped["Configuration"] = relationship("Configuration", back_populates="sessions")
    measurements: Mapped[List["Measurement"]] = relationship(
        "Measurement", back_populates="session", cascade="all, delete-orphan"
    )


# ─────────────────────────────────────────────────────────────────────────────
# Measurement  (one row per DAQ reading interval)
# ─────────────────────────────────────────────────────────────────────────────
class Measurement(Base):
    __tablename__ = "measurements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("sessions.id", ondelete="CASCADE"), index=True
    )

    # One float per channel (10 channels).  NULL = channel inactive.
    ch1:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch2:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch3:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch4:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch5:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch6:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch7:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch8:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch9:  Mapped[Optional[float]] = mapped_column(Float, nullable=True)
    ch10: Mapped[Optional[float]] = mapped_column(Float, nullable=True)

    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )

    # Relationship
    session: Mapped["MeasurementSession"] = relationship("MeasurementSession", back_populates="measurements")
