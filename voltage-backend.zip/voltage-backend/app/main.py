from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.logging import setup_logging
from app.db.database import Base, engine
from app.api.routers import configs, sessions, measurements, websocket


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ──
    setup_logging()
    # Auto-create tables (use Alembic for production migrations)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # ── Shutdown ──
    await engine.dispose()


def create_app() -> FastAPI:
    app = FastAPI(
        title="Voltage Monitoring API",
        version="1.0.0",
        docs_url="/docs" if settings.is_dev else None,
        redoc_url="/redoc" if settings.is_dev else None,
        lifespan=lifespan,
    )

    # CORS — allow Vue dev server
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:8080", "http://localhost:3000"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Routers
    app.include_router(configs.router)
    app.include_router(sessions.router)
    app.include_router(measurements.router)
    app.include_router(websocket.router)

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    return app


app = create_app()
