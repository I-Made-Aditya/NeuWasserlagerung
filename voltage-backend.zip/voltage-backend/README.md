# Voltage Monitoring — Backend

FastAPI + PostgreSQL + PyVISA backend untuk sistem monitoring tegangan DAQ6510/DAQ9600.

## Struktur Proyek

```
voltage-backend/
├── app/
│   ├── main.py                       # FastAPI app factory + lifespan
│   ├── core/
│   │   ├── config.py                 # Settings via .env
│   │   └── logging.py                # Logging setup
│   ├── db/
│   │   └── database.py               # Async SQLAlchemy engine + get_db()
│   ├── models/
│   │   └── models.py                 # ORM: Configuration, MeasurementSession, Measurement
│   ├── schemas/
│   │   └── schemas.py                # Pydantic schemas + LiveReading WS payload
│   ├── api/
│   │   └── routers/
│   │       ├── configs.py            # GET/POST/PUT/DELETE /api/configs
│   │       ├── sessions.py           # POST /api/sessions/start|stop
│   │       ├── measurements.py       # GET /api/measurements/{session_id}
│   │       └── websocket.py          # WS  /ws/live/{config_id}
│   ├── daq/
│   │   ├── scpi_commands.py          # ★ Semua SCPI string DAQ6510 & DAQ9600
│   │   ├── base_driver.py            # Abstract base class
│   │   ├── daq6510_driver.py         # Driver DAQ6510
│   │   ├── daq9600_driver.py         # Driver DAQ9600
│   │   └── driver_factory.py         # get_driver(equipment_type, ip)
│   └── services/
│       ├── session_manager.py        # Singleton asyncio task manager
│       └── ws_manager.py             # WebSocket connection registry
├── alembic/                          # DB migrations
├── tests/
├── .env.example
├── alembic.ini
└── requirements.txt
```

## Cara Setup

### 1. Buat virtual environment

```bash
python -m venv venv
source venv/bin/activate          # Linux/macOS
venv\Scripts\activate             # Windows
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Konfigurasi environment

```bash
cp .env.example .env
# Edit .env — sesuaikan DATABASE_URL dan DAQ_* timeout
```

### 4. Buat database PostgreSQL

```sql
CREATE DATABASE voltage_monitoring;
```

### 5. Jalankan migrasi (atau biarkan auto-create di dev)

```bash
alembic upgrade head
```

### 6. Jalankan server

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Buka Swagger UI: http://localhost:8000/docs

---

## API Endpoints

| Method | URL | Keterangan |
|--------|-----|-----------|
| GET | `/api/configs` | List semua konfigurasi |
| POST | `/api/configs` | Buat konfigurasi baru |
| PUT | `/api/configs/{id}` | Update konfigurasi |
| DELETE | `/api/configs/{id}` | Hapus konfigurasi |
| POST | `/api/sessions/start` | **Start DAQ** (trigger dari tombol Start Vue) |
| POST | `/api/sessions/stop` | Stop DAQ |
| GET | `/api/sessions/active` | List session yang sedang berjalan |
| GET | `/api/sessions/{config_id}` | Riwayat session per config |
| GET | `/api/measurements/{session_id}` | Data pengukuran per session |
| WS | `/ws/live/{config_id}` | Live stream readings ke Vue frontend |

## Alur Kerja (Start → Stop)

```
Vue: klik Start
  → POST /api/sessions/start  { configuration_id: 3 }
  → session_manager.start(3)
      → buat row sessions (status=running)
      → asyncio.create_task(_daq_loop)
          loop tiap interval_s:
            driver.read_channels()
            INSERT measurements row  ← real-time ke PostgreSQL
            ws_manager.broadcast()   ← push ke Vue /ws/live/3
  ← response: SessionRead { id, status: "running", ... }

Vue: klik Stop
  → POST /api/sessions/stop  { session_id: "uuid..." }
  → session_manager.stop("uuid...")
      → task.cancel()
      → UPDATE sessions SET status="stopped"
```

## File SCPI Commands

`app/daq/scpi_commands.py` adalah **satu-satunya tempat** semua string SCPI.
- `DAQ6510Commands` — semua perintah untuk DAQ6510
- `DAQ9600Commands` — semua perintah untuk DAQ9600
- `VISAAddress` — helper untuk membangun VISA resource string TCP

Jika perlu menambah/mengubah perintah, **cukup edit file ini**.
