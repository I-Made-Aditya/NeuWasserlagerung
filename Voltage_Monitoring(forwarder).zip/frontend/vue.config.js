const { defineConfig } = require('@vue/cli-service')

module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    port: 8080,
    proxy: {
      // Optional convenience proxy for local dev if you prefer calling
      // relative paths ('/api/...') instead of a full VUE_APP_API_BASE_URL.
      '/api': {
        target: process.env.VUE_APP_API_BASE_URL
          ? process.env.VUE_APP_API_BASE_URL.replace(/\/api\/?$/, '')
          : 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
})
