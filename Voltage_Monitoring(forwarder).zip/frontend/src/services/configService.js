import api from './api'

export function fetchConfigs() {
  return api.get('/configs').then(res => res.data)
}

export function fetchConfig(id) {
  return api.get(`/configs/${id}`).then(res => res.data)
}

export function createConfig(payload = {}) {
  return api.post('/configs', payload).then(res => res.data)
}

export function updateConfig(id, payload) {
  return api.put(`/configs/${id}`, payload).then(res => res.data)
}

export function deleteConfig(id) {
  return api.delete(`/configs/${id}`)
}

export function fetchConfigData(id, limit = 300, mode = 'voltage', startDate = '', endDate = '') {
  return api.get(`/configs/${id}/data`, { params: { limit, mode, start_date: startDate || undefined, end_date: endDate || undefined } }).then(res => res.data)
}

export function fetchAlarms(id, statusFilter) {
  return api.get(`/configs/${id}/alarms`, { params: statusFilter ? { status_filter: statusFilter } : {} })
    .then(res => res.data)
}

export function releaseAlarm(configId, alarmId, remark) {
  return api.post(`/configs/${configId}/alarms/${alarmId}/release`, { remark }).then(res => res.data)
}

export function fetchDevices() {
  return api.get('/devices').then(res => res.data)
}

export async function exportCsv(
  configId,
  startDate,
  endDate,
  mode,
  channelGroup
) {
  return await api.get(`/configs/${configId}/export/csv`, {
    params: {
      start_date: startDate,
      end_date: endDate,
      mode,
      channel_group: channelGroup
    },
    responseType: 'blob'
  }
  )
}

export async function exportExcel(
  configId,
  startDate,
  endDate,
  mode,
  channelGroup
) {
  return await api.get(
    `/configs/${configId}/export/excel`,
    {
      params: {
        start_date: startDate,
        end_date: endDate,
        mode,
        channel_group: channelGroup
      },
      responseType: 'blob'
    }
  )
}

// Matches backend route: POST /api/{equipment_type}/{ip_address}/{wire_mode}
export function triggerManualReading(equipmentType, ipAddress, wireMode, channels) {
  const params = {}
  if (channels && channels.length) params.channels = channels.join(',')
  return api.post(`/${equipmentType}/${ipAddress}/${wireMode}`, null, { params }).then(res => res.data)
}
