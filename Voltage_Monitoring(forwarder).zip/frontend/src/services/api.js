import axios from 'axios'

// Base URL is fully configurable via .env (VUE_APP_API_BASE_URL),
// so the same build can point at different backends per environment.
const baseURL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000/api'

const api = axios.create({ baseURL })

// Attach the JWT bearer token (if we have one) to every request.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('vms_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Centralised 401 handling: token expired/invalid -> force logout.
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('vms_token')
      localStorage.removeItem('vms_user')
      // Let the app react to this (App.vue listens for this custom event)
      window.dispatchEvent(new CustomEvent('vms:unauthorized'))
    }
    return Promise.reject(error)
  }
)

export default api
