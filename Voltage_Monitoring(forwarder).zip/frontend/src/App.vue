<template>
  <LoginView v-if="!isAuthenticated" />

  <div v-else class="app-wrapper">
    <header class="app-header">
      <div class="header-inner">
        <div class="brand">
          <div class="brand-icon">
            <ZapIcon />
          </div>
          <div class="brand-text">
            <p class="brand-title">Voltage Monitoring System</p>
            <p class="brand-sub">Wasserlagerung · Industrial DAQ</p>
          </div>
        </div>
        <div class="header-stats">
          <span class="pill">
            <span class="pill-dot" :class="activeCount > 0 ? 'dot-active' : 'dot-inactive'" />
            {{ activeCount }} of {{ configs.length }} active
          </span>
          <div class="header-user">
            <span class="role-badge" :class="`role-badge--${currentUser?.role}`">
              {{ currentUser?.role }}
            </span>
            <span class="header-username">{{ currentUser?.full_name || currentUser?.username }}</span>
            <button class="logout-btn" @click="handleLogout">Logout</button>
          </div>
        </div>
      </div>
    </header>

    <div class="col-headers">
      <span class="col-header col-id">#</span>
      <span class="col-header col-action">Action</span>
      <span class="col-header col-info">Configuration</span>
      <span class="col-header col-view">View</span>
    </div>
    <p v-if="!isAdmin" class="readonly-note">
      Anda login sebagai engineer (read-only) — konfigurasi hanya dapat dilihat, tidak dapat diubah.
    </p>

    <main class="config-list">
      <div v-if="loading" class="loading-state">Memuat konfigurasi…</div>
      <div v-else-if="loadError" class="error-state">
        Gagal memuat data dari server: {{ loadError }}
        <div><button class="btn-small" @click="loadConfigs">Coba lagi</button></div>
      </div>
      <div v-else class="list-inner">
        <ConfigRow
          v-for="config in configs"
          :key="config.id"
          :config="config"
          :is-admin="isAdmin"
          @update="handleUpdate"
          @delete-request="prepareDelete"
        />

        <button v-if="isAdmin" class="add-btn" @click="handleAdd">
          <span class="add-icon-wrap">
            <PlusIcon />
          </span>
          <span class="add-label">Add New Configuration</span>
        </button>
      </div>
    </main>

    <DeleteModal
      v-if="configToDelete"
      @close="configToDelete = null"
      @confirm="finalizeDelete"
    />
  </div>
</template>

<script>
import { ref, computed, watch, onMounted, onUnmounted } from 'vue'
import ConfigRow from './components/ConfigRow.vue'
import DeleteModal from './components/DeleteModal.vue'
import LoginView from './components/LoginView.vue'
import { isAuthenticated, currentUser, isAdmin, logout } from './store/auth'
import { fetchConfigs, createConfig, updateConfig, deleteConfig } from './services/configService'

const ZapIcon = {
  template: `<svg width="16" height="16" fill="none" stroke="white" stroke-width="2.5" viewBox="0 0 24 24">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
  </svg>`
}

const PlusIcon = {
  template: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
  </svg>`
}

const REFRESH_INTERVAL_MS = 5000

export default {
  name: 'App',
  components: { ConfigRow, ZapIcon, PlusIcon, DeleteModal, LoginView },

  setup() {
    const configs = ref([])
    const configToDelete = ref(null)
    const loading = ref(false)
    const loadError = ref('')
    let pollTimer = null

    const activeCount = computed(() => configs.value.filter(c => c.active).length)

    async function loadConfigs({ silent } = {}) {
      if (!isAuthenticated.value) return
      if (!silent) loading.value = true
      loadError.value = ''
      try {
        configs.value = await fetchConfigs()
      } catch (err) {
        loadError.value = err.response?.data?.detail || err.message || 'Unknown error'
      } finally {
        loading.value = false
      }
    }

    function startPolling() {
      stopPolling()
      pollTimer = setInterval(() => loadConfigs({ silent: true }), REFRESH_INTERVAL_MS)
    }

    function stopPolling() {
      if (pollTimer) {
        clearInterval(pollTimer)
        pollTimer = null
      }
    }

    async function handleUpdate(updated) {
      try {
        const saved = await updateConfig(updated.id, updated)
        const idx = configs.value.findIndex(c => c.id === saved.id)
        if (idx !== -1) configs.value[idx] = saved
      } catch (err) {
        alert('Gagal menyimpan konfigurasi: ' + (err.response?.data?.detail || err.message))
      }
    }

    async function handleAdd() {
      try {
        const created = await createConfig({})
        configs.value.push(created)
      } catch (err) {
        alert('Gagal menambah konfigurasi: ' + (err.response?.data?.detail || err.message))
      }
    }

    function prepareDelete(id) {
      configToDelete.value = id
    }

    async function finalizeDelete() {
      if (configToDelete.value === null) return
      try {
        await deleteConfig(configToDelete.value)
        configs.value = configs.value.filter(c => c.id !== configToDelete.value)
      } catch (err) {
        alert('Gagal menghapus konfigurasi: ' + (err.response?.data?.detail || err.message))
      } finally {
        configToDelete.value = null
      }
    }

    function handleLogout() {
      stopPolling()
      logout()
    }

    onMounted(() => {
      if (isAuthenticated.value) {
        loadConfigs()
        startPolling()
      }
    })

    // React to login/logout happening at runtime: as soon as LoginView's
    // login() call flips isAuthenticated to true, start fetching + polling.
    const stopWatchAuth = watch(isAuthenticated, (authed) => {
      if (authed) {
        loadConfigs()
        startPolling()
      } else {
        stopPolling()
        configs.value = []
      }
    })

    onUnmounted(() => {
      stopPolling()
      stopWatchAuth()
    })

    return {
      configs,
      activeCount,
      configToDelete,
      loading,
      loadError,
      isAuthenticated,
      currentUser,
      isAdmin,
      loadConfigs,
      handleUpdate,
      handleAdd,
      prepareDelete,
      finalizeDelete,
      handleLogout,
    }
  }
}
</script>
