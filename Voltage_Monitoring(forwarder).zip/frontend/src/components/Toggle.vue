<template>
  <button
    class="toggle"
    :class="modelValue ? 'toggle--on' : 'toggle--off'"
    @click="$emit('update:modelValue', !modelValue)"
    role="switch"
    :aria-checked="modelValue"
  >
    <span class="toggle-thumb" :class="modelValue ? 'toggle-thumb--on' : 'toggle-thumb--off'" />
  </button>
</template>

<script>
export default {
  name: 'Toggle',
  props: {
    modelValue: { type: Boolean, required: true }
  },
  emits: ['update:modelValue']
}
</script>
