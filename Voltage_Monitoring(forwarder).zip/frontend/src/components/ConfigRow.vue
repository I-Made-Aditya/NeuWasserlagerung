<template>
  <div class="config-row"
    :class="{ 'config-row--inactive': !config.active, 'config-row--alarm': config.active && hasAlarm }">
    <div class="row-id">
      <span class="row-id-text">{{ config.id }}</span>
    </div>

    <div class="card card--settings">
      <div class="settings-group">
        <button v-if="isAdmin" class="delete-trigger-box" @click.stop="askDelete" title="Delete Row">
          <span class="delete-icon"></span>
        </button>

        <button v-if="isAdmin" class="settings-btn" @click="modal = 'settings'">
          <SettingsIcon />
          <span>Settings</span>
        </button>
        <span v-else class="view-only-note">View only</span>
      </div>
    </div>

    <div class="card card--info">
      <div class="main-content-row">
        <div class="fields-row">
          <div class="field-box">
            <!-- <span class="field-label">Status</span> -->
            <div class="led-wrap">
              <span class="led" :class="config.active ? 'led--green' : 'led--red'" />
            </div>
          </div>

          <FieldBox label="Project" :value="config.projectName" width="150px" height="65px" />
          <FieldBox label="LOM-Nr" :value="config.lomNr" width="150px" />
          <FieldBox label="Description" :value="config.description" width="200px" />
          <FieldBox label="Interval [s]" :value="String(config.interval)" width="80px" :mono="true" />
          <FieldBox label="Duration [h]" :value="String(config.duration)" width="85px" :mono="true" />
          <FieldBox label="Min [V]" :value="String(config.minV)" width="60px" :mono="true" />
          <FieldBox label="Max [V]" :value="String(config.maxV)" width="60px" :mono="true" />
          <FieldBox label="Machine" :value="config.machine" width="250px" />
          <FieldBox label="Exp. Finish" :value="config.expectedFinish" width="105px" :mono="true" />
        </div>

        <div class="channels-row-inline">
          <span class="channels-label">Active Monitoring </span>
          <span class="channels-label">{{ activeChannels }}/80</span>
        </div>
      </div>
    </div>

    <div class="card card--actions">
      <ActionBtn v-if="isAdmin && config.active && hasAlarm" label="Review" color="orange" @click="modal = 'release'">
        <ReleaseIcon />
      </ActionBtn>
      <ActionBtn label="Data" color="blue" @click="modal = 'data'">
        <DatabaseIcon />
      </ActionBtn>
      <ActionBtn label="Graph" color="teal" @click="modal = 'graph'">
        <BarChartIcon />
      </ActionBtn>
      <ActionBtn label="Detail" color="blue" @click="showDetails = !showDetails">
        <DetailIcon />
      </ActionBtn>
    </div>
  </div>

  <SettingsModal v-if="modal === 'settings'" :config="config" @close="modal = null" @save="handleSave" />
  <DataModal v-if="modal === 'data'" :config="config" @close="modal = null" />
  <GraphModal v-if="modal === 'graph'" :config="config" @close="modal = null" />
  <ReleaseModal v-if="modal === 'release'" :config="config" :channel="alarmChannel" @close="modal = null"
    @release="handleRelease" />
  <transition name="expand">
    <div v-if="showDetails" class="channel-detail-panel">

      <div v-for="row in 4" :key="row" class="channel-strip">

        <span class="strip-label">
          CH {{ (row - 1) * 20 + 1 }} - {{ row * 20 }}
        </span>

        <div class="channels-leds-detail">

          <div v-for="col in 20" :key="col" class="channel-item">
            <span class="led" :class="[
              config.channels[(row - 1) * 20 + (col - 1)]
                ? 'led--green'
                : 'led--red',

              latchedAlarmChannels.includes(
                (row - 1) * 20 + col
              )
                ? 'led--alarm'
                : ''
            ]" />
            <span class="channel-num">
              {{ (row - 1) * 20 + col }}
            </span>

          </div>

        </div>

        <span class="channels-count">
          {{
            config.channels
              .slice((row - 1) * 20, row * 20)
              .filter(Boolean)
              .length
          }}/20
        </span>

      </div>

    </div>
  </transition>

</template>

<script>
import { watch, ref, computed } from 'vue'
import FieldBox from './FieldBox.vue'
import ActionBtn from './ActionBtn.vue'
import SettingsModal from './SettingsModal.vue'
import DataModal from './DataModal.vue'
import GraphModal from './GraphModal.vue'
import ReleaseModal from './ReleaseModal.vue'

// Icons
const SettingsIcon = {
  template: `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
  </svg>`
}
const DatabaseIcon = {
  template: `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
    <ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>
  </svg>`
}
const DetailIcon = {
  template: `<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
    <path stroke-linecap="round" stroke-linejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/>
    <path stroke-linecap="round" stroke-linejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
  </svg>`
}

const BarChartIcon = {
  template: `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
    <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
  </svg>`
}
const ReleaseIcon = {
  template: `
  <svg
    width="14"
    height="14"
    fill="none"
    stroke="currentColor"
    stroke-width="2"
    viewBox="0 0 24 24"
  >
    <path d="M20 6L9 17L4 12"/>
  </svg>
  `
}
// const TrashIcon = {
//   template: `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
//     <polyline points="3 6 5 6 21 6"></polyline>
//     <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
//     <line x1="10" y1="11" x2="10" y2="17"></line>
//     <line x1="14" y1="11" x2="14" y2="17"></line>
//   </svg>`
// }

export default {
  name: 'ConfigRow',
  components: {
    FieldBox, ActionBtn, SettingsModal, DataModal, GraphModal, ReleaseModal,
    SettingsIcon, DatabaseIcon, BarChartIcon, DetailIcon, ReleaseIcon
  },
  props: {
    config: { type: Object, required: true },
    isAdmin: { type: Boolean, default: false }
  },
  emits: ['update', 'delete-request'],

  setup(props, { emit }) {
    const modal = ref(null)
    const showDetails = ref(false)
    const activeChannels = computed(() => props.config.channels.filter(Boolean).length)
    const latestData = computed(() =>
      props.config.data.at(-1)
    )
    const latchedAlarmChannels = ref([])
    function handleSave(updated) {
      emit('update', updated)
      modal.value = null
    }

    function askDelete() {
      emit('delete-request', props.config.id);
    }

    const alarmLatched = ref(false)
    const hasAlarm = alarmLatched

    const alarmChannel = computed(() => {
      if (!latestData.value)
        return 'No Alarm'
      const idx =
        latestData.value.values.findIndex(v =>
          v < props.config.minV ||
          v > props.config.maxV
        )

      return idx >= 0 ? `CH${idx + 1}` : 'No Alarm'
    })

    function handleRelease() {
      const stillOutSpec =
        latestData.value?.values.some(v =>
          v < props.config.minV ||
          v > props.config.maxV
        )

      if (!stillOutSpec) {
        alarmLatched.value = false
        latchedAlarmChannels.value = []
      }
      modal.value = null
    }

    watch(
      () => props.config.data,
      () => {
        if (!props.config.active) return
        if (!latestData.value) return

        const foundAlarm =
          latestData.value.values.some(v =>
            v < props.config.minV ||
            v > props.config.maxV
          )

        if (foundAlarm) {

          alarmLatched.value = true
          const newChannels =
            latestData.value.values
              .map((v, idx) =>
                v < props.config.minV ||
                  v > props.config.maxV
                  ? idx + 1
                  : null
              )
              .filter(Boolean)
          latchedAlarmChannels.value = [
            ...new Set([
              ...latchedAlarmChannels.value,
              ...newChannels
            ])
          ]

        }

      },

      {
        deep: true,
        immediate: true
      }
    )
    watch(
      () => props.config.active,
      (active) => {

        if (!active) {

          alarmLatched.value = false
          latchedAlarmChannels.value = []
          modal.value = null

        }

      }
    )

    return {
      modal,
      showDetails,
      activeChannels,

      alarmChannel,
      latchedAlarmChannels,

      handleSave,
      askDelete,
      handleRelease,

      hasAlarm
    }
  }
}
</script>
