<template>
  <Teleport to="body">
    <div class="modal-overlay" @click.self="$emit('close')">
      <div class="modal-panel modal-panel--md">
        <!-- Header -->
        <div class="modal-header">
          <div class="modal-title-group">
            <div>
              <p class="modal-title">Configuration Settings</p>
              <p class="modal-subtitle">Slot #{{ config.id }}</p>
            </div>
          </div>
        </div>

        <!-- Body -->
        <div class="modal-body">
          <!-- Status -->
          <Section title="Status">
            <div class="toggle-row">
              <div>
                <p class="toggle-label">Active</p>
                <p class="toggle-sub">Enable or disable this configuration slot</p>
              </div>
              <Toggle v-model="form.active" />
            </div>
          </Section>

          <!-- Channels -->
          <Section title="Channel Enable · Disable">
            <div class="channel-actions">
              <button class="btn-small" @click="enableAllChannels">Enable All</button>
              <button class="btn-small" @click="disableAllChannels">Disable All</button>
            </div>
            <div class="channels-groups">
              <div v-for="group in 4" :key="group" class="channel-group">
                <div class="channel-group-title">
                  CH {{ (group - 1) * 20 + 1 }}
                  -
                  {{ group * 20 }}
                </div>
                <div class="channels-grid">
                  <button v-for="i in 20" :key="i" class="ch-btn" :class="form.channels[(group - 1) * 20 + (i - 1)]
                    ? 'ch-btn--on'
                    : 'ch-btn--off'
                    " @click="toggleChannel((group - 1) * 20 + (i - 1))">
                    <span class="ch-btn-label">
                      CH{{ (group - 1) * 20 + i }}
                    </span>
                    <span class="ch-btn-dot" :class="form.channels[(group - 1) * 20 + (i - 1)]
                      ? 'ch-dot--on'
                      : 'ch-dot--off'
                      " />
                  </button>
                </div>
              </div>
            </div>
          </Section>

          <!-- Project Info -->
          <Section title="Project Information">
            <div class="form-grid form-grid--2">
              <FormField label="Project Name">
                <input class="form-input" v-model="form.projectName" placeholder="e.g. QA" />
              </FormField>
              <FormField label="LOM Nr">
                <input class="form-input" v-model="form.lomNr" placeholder="e.g. Nr 1-10" />
              </FormField>
              <FormField label="Description" class="col-span-2">
                <input class="form-input" v-model="form.description" placeholder="Short description" />
              </FormField>
            </div>
          </Section>

          <!-- Measurement -->
          <Section title="Measurement Parameters">
            <div class="form-grid form-grid--4">
              <FormField label="Interval [s]">
                <input type="number" class="form-input" v-model.number="form.interval" />
              </FormField>
              <FormField label="Duration [h]">
                <input type="number" class="form-input" v-model.number="form.duration" />
              </FormField>
              <FormField label="Min [V]">
                <input type="number" step="0.1" class="form-input" v-model.number="form.minV" />
              </FormField>
              <FormField label="Max [V]">
                <input type="number" step="0.1" class="form-input" v-model.number="form.maxV" />
              </FormField>
            </div>
          </Section>

          <!-- Hardware -->
          <Section title="Hardware · Network">
            <div class="form-grid form-grid--2">
              <FormField label="Machine">
                <select class="form-input" v-model="form.machine">
                  <option>MCEPE11567</option>
                  <option>MCEPE11566</option>
                  <option>MCEPE11561</option>
                </select>
              </FormField>
              <FormField label="Equipment Type">
                <select class="form-input" v-model="form.equipmentType">
                  <option>DAQ9600</option>
                  <option>DAQ6510</option>
                </select>
              </FormField>
              <FormField label="IP Address">
                <input class="form-input" v-model="form.ipAddress" placeholder="192.168.1.100" />
              </FormField>
              <FormField label="Netmask">
                <input class="form-input" v-model="form.netmask" placeholder="255.255.255.0" />
              </FormField>
              <FormField label="Wire Mode">
                <select class="form-input" v-model="form.wireMode">
                  <option value="4-wire">4-Wire</option>
                  <option value="2-wire">2-Wire</option>
                </select>
              </FormField>
            </div>
            <div class="test-connection-row">
              <button class="btn-small" type="button" :disabled="testing" @click="handleTestConnection">
                {{ testing ? 'Testing…' : 'Test Connection' }}
              </button>
              <span v-if="testResult" class="test-connection-result">{{ testResult }}</span>
              <span v-if="testErrorMsg" class="test-connection-result is-error">{{ testErrorMsg }}</span>
            </div>
          </Section>
        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <button class="btn btn--cancel" @click="$emit('close')">Cancel</button>
          <button class="btn btn--save" @click="handleSave">
            <SaveIcon />
            Save
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script>
import { reactive, ref, onMounted, onUnmounted } from 'vue'
import Section from './FormSection.vue'
import FormField from './FormField.vue'
import Toggle from './Toggle.vue'
import { triggerManualReading } from '../services/configService'

export default {
  name: 'SettingsModal',
  components: { Section, FormField, Toggle },
  props: {
    config: { type: Object, required: true }
  },
  emits: ['close', 'save'],

  setup(props, { emit }) {
    const form = reactive({ ...props.config, channels: [...props.config.channels] })
    console.log('channels length =', form.channels.length)

    function toggleChannel(i) {
      form.channels[i] = !form.channels[i]
    }

    function enableAllChannels() {
      form.channels.forEach((_, i) => {
        form.channels[i] = true
      })
    }

    function disableAllChannels() {
      form.channels.forEach((_, i) => {
        form.channels[i] = false
      })
    }
    function handleSave() {
      emit('save', { ...form, channels: [...form.channels] })
    }

    function onKeydown(e) {
      if (e.key === 'Escape') emit('close')
    }
    onMounted(() => window.addEventListener('keydown', onKeydown))
    onUnmounted(() => window.removeEventListener('keydown', onKeydown))

    const testing = ref(false)
    const testResult = ref('')
    const testErrorMsg = ref('')

    async function handleTestConnection() {
      testing.value = true
      testResult.value = ''
      testErrorMsg.value = ''
      try {
        const res = await triggerManualReading(form.equipmentType, form.ipAddress, form.wireMode, [1])
        const mode = res.simulated ? ' (simulated)' : ''
        testResult.value = `OK${mode} · CH1 = ${res.values[0]} V @ ${res.timestamp}`
      } catch (err) {
        testErrorMsg.value = 'Gagal: ' + (err.response?.data?.detail || err.message)
      } finally {
        testing.value = false
      }
    }

    return {
      form, toggleChannel, handleSave, enableAllChannels, disableAllChannels,
      testing, testResult, testErrorMsg, handleTestConnection,
    }
  }
}
</script>
