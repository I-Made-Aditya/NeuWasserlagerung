<template>
  <Teleport to="body">
    <div class="modal-overlay" @click.self="$emit('close')">
      <div class="modal-panel modal-panel--xl">
        <!-- Header -->
        <div class="modal-header">
          <div class="modal-title-group">
            <div>
              <p class="modal-title">Raw Data</p>
              <p class="modal-subtitle">
                #{{ config.id }} · {{ config.projectName }} / {{ config.lomNr }} · {{ config.description }}
              </p>
            </div>
          </div>
          <div class="modal-header-right">
            <div class="channel-selector-wrap">
              <select v-model="selectedGroup" class="channel-selector">
                <option v-for="group in 8" :key="group" :value="group">
                  CH {{ (group - 1) * 10 + 1 }}-{{ group * 10 }}
                </option>
              </select>
            </div>
            <span class="record-badge">{{ config.data.length }} records</span>
          </div>
        </div>

        <!-- Table -->
        <div class="table-scroll">
          <table class="data-table">
            <thead>
              <tr>
                <th class="th th--nr">Nr</th>
                <th class="th th--ts">Timestamp</th>
                <th v-for="channel in visibleChannels" :key="channel" class="th th--ch">
                  CH{{ channel + 1 }}
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="config.data.length === 0">
                <td colspan="12" class="td-empty">No data recorded for this configuration.</td>
              </tr>
              <tr v-else v-for="(row, i) in config.data" :key="i" class="data-row"
                :class="i % 2 === 0 ? 'data-row--even' : 'data-row--odd'">
                <td class="td td--nr">{{ i + 1 }}</td>
                <td class="td td--ts">{{ row.timestamp }}</td>
                <td v-for="channel in visibleChannels" :key="channel" class="td td--val"
                  :class="isOutOfRange(row.values[channel]) ? 'td--oor' : ''">
                  {{ row.values[channel]?.toFixed(4) }}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <p class="data-range-info">
            Range&nbsp;
            <span class="range-lsl">{{ config.minV }} V</span>
            &nbsp;—&nbsp;
            <span class="range-usl">{{ config.maxV }} V</span>
            &nbsp;· Values outside range highlighted
          </p>
          <button class="btn btn--cancel" @click="$emit('close')">Close</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script>
import { ref, computed, onMounted, onUnmounted } from 'vue'

export default {
  name: 'DataModal',
  components: {  },
  props: {
    config: { type: Object, required: true }
  },
  emits: ['close'],

  setup(props, { emit }) {
    function isOutOfRange(v) {
      return v < props.config.minV || v > props.config.maxV
    }

    function onKeydown(e) {
      if (e.key === 'Escape') emit('close')
    }
    onMounted(() => window.addEventListener('keydown', onKeydown))
    onUnmounted(() => window.removeEventListener('keydown', onKeydown))
    const selectedGroup = ref(1)

    const visibleChannels = computed(() => {
      const start = (selectedGroup.value - 1) * 10

      return Array.from(
        { length: 10 },
        (_, i) => start + i
      )
    })

    return { isOutOfRange, selectedGroup, visibleChannels }
  }
}
</script>
