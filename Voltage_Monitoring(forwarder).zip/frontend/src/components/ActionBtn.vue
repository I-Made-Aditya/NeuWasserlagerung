<template>
  <button class="action-btn" :class="`action-btn--${color}`" @click="$emit('click')">
    <slot />
    <span>{{ label }}</span>
  </button>
</template>

<script>
export default {
  name: 'ActionBtn',
  props: {
    label: { type: String, required: true },
    color: { type: String, default: 'blue' } // 'blue' | 'teal'
  },
  emits: ['click']
}
</script>
