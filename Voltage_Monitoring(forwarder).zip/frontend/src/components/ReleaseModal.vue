<template>
  <Teleport to="body">
    <div
      class="modal-overlay"
      @click.self="$emit('close')"
    >
      <div class="release-modal">

        <div class="release-header">
          <h3>Release Alarm</h3>
        </div>

        <div class="release-body">
          <div class="form-group">
            <label>Remark *</label>

            <textarea
              v-model="remark"
              class="form-textarea"
              placeholder="Example: CH7 already solved. Problem found on connector. Connector replaced and retested."
            />
          </div>

        </div>

        <div class="release-footer">

          <button
            class="btn btn--cancel"
            @click="$emit('close')"
          >
            Cancel
          </button>

          <button
            class="btn btn--save"
            @click="handleRelease"
          >
            Release
          </button>

        </div>

      </div>
    </div>
  </Teleport>
</template>

<script>
import { ref } from 'vue'

export default {
  name: 'ReleaseModal',

  props: {
    config: Object,
    channel: String
  },

  emits: ['close', 'release'],

  setup(props, { emit }) {

    const remark = ref('')

    function handleRelease() {

      if (!remark.value.trim()) {
        alert('Remark is required')
        return
      }

      emit('release', {
        channel: props.channel,
        remark: remark.value,
        releasedAt: new Date().toISOString()
      })

      emit('close')
    }

    return {
      remark,
      handleRelease
    }
  }
}
</script>
