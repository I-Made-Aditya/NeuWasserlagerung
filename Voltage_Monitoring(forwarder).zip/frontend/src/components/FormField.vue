<template>
  <div :class="['form-field', className]">
    <label class="form-label">{{ label }}</label>
    <slot />
  </div>
</template>

<script>
export default {
  name: 'FormField',
  props: {
    label: { type: String, required: true },
    className: { type: String, default: '' }
  }
}
</script>
