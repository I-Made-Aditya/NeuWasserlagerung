<template>
  <div class="login-wrapper">
    <div class="login-card">
      <div class="login-brand">
        <div class="brand-icon">
          <ZapIcon />
        </div>
        <div>
          <p class="login-title">Voltage Monitoring System</p>
          <p class="login-sub">Wasserlagerung · Industrial DAQ</p>
        </div>
      </div>

      <form class="login-form" @submit.prevent="handleSubmit">
        <div class="form-field">
          <label class="form-label">Username</label>
          <input
            v-model="username"
            class="form-input"
            type="text"
            autocomplete="username"
            placeholder="admin / engineer"
            required
          />
        </div>
        <div class="form-field">
          <label class="form-label">Password</label>
          <input
            v-model="password"
            class="form-input"
            type="password"
            autocomplete="current-password"
            placeholder="••••••••"
            required
          />
        </div>

        <p v-if="errorMessage" class="login-error">{{ errorMessage }}</p>

        <button type="submit" class="btn btn--save login-submit" :disabled="loading">
          {{ loading ? 'Signing in…' : 'Sign In' }}
        </button>
      </form>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { login } from '../store/auth'

const ZapIcon = {
  template: `<svg width="16" height="16" fill="none" stroke="white" stroke-width="2.5" viewBox="0 0 24 24">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
  </svg>`
}

export default {
  name: 'LoginView',
  components: { ZapIcon },
  emits: ['success'],
  setup(props, { emit }) {
    const username = ref('')
    const password = ref('')
    const loading = ref(false)
    const errorMessage = ref('')

    async function handleSubmit() {
      errorMessage.value = ''
      loading.value = true
      try {
        const user = await login(username.value.trim(), password.value)
        emit('success', user)
      } catch (err) {
        errorMessage.value =
          err.response?.status === 401
            ? 'Username atau password salah.'
            : 'Tidak dapat terhubung ke server. Pastikan backend berjalan.'
      } finally {
        loading.value = false
      }
    }

    return { username, password, loading, errorMessage, handleSubmit }
  }
}
</script>
