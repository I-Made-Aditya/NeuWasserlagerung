<template>
  <div class="form-section">
    <p class="section-title">{{ title }}</p>
    <div class="section-body">
      <slot />
    </div>
  </div>
</template>

<script>
export default {
  name: 'FormSection',
  props: {
    title: { type: String, required: true }
  }
}
</script>
