<template>
  <Teleport to="body">
    <div class="modal-overlay" @click.self="$emit('close')">
      <div class="modal-panel modal-panel--xl">
        <!-- Header -->
        <div class="modal-header">
          <div class="modal-title-group">
            <div>
              <p class="modal-title">Voltage Graph</p>
              <p class="modal-subtitle">
                #{{ config.id }} · {{ config.projectName }} / {{ config.lomNr }} · {{ config.description }}
              </p>
            </div>
          </div>
        </div>

        <!-- Controls toolbar -->
        <div class="graph-toolbar">
          <div class="toolbar-group">
            <span class="toolbar-label">Channel</span>
            <div class="channel-picker">
              <button class="channel-picker-btn" @click="showChannels = !showChannels">
                Select Channels
                ({{ selectedChannels.length }})
              </button>
              <div v-if="showChannels" class="channel-dropdown">
                <label v-for="i in 80" :key="i" class="channel-option">
                  <input type="checkbox" :value="i" v-model="selectedChannels" />
                  CH{{ i }}
                </label>
              </div>
            </div>
          </div>
          <div class="toolbar-group ml-8">
            <LimitChip color="#FF3B30" :label="`USL · ${config.maxV} V`" />
            <LimitChip color="#FF9F0A" :label="`LSL · ${config.minV} V`" />
          </div>
          <div class="toolbar-zoom">
            <span class="zoom-hint">Scroll to zoom · Drag to pan</span>
            <button class="zoom-btn" title="Zoom in" @click="zoomIn">
              <ZoomInIcon />
            </button>
            <button class="zoom-btn" title="Zoom out" @click="zoomOut">
              <ZoomOutIcon />
            </button>
            <button class="zoom-btn" title="Reset zoom" @click="resetZoom">
              <ResetIcon />
            </button>
          </div>
        </div>

        <!-- Chart area -->
        <div class="chart-area">
          <div v-if="config.data.length === 0" class="chart-empty">
            <div class="chart-empty-icon">
              <BarChartIcon size="20" color="#AEAEB2" />
            </div>
            <p class="chart-empty-title">No data recorded</p>
            <p class="chart-empty-sub">Activate this configuration to begin recording.</p>
          </div>
          <canvas v-else ref="canvasRef" />
        </div>

        <!-- Footer -->
        <div class="modal-footer">
          <p class="graph-footer-info">
            {{ config.equipmentType }} · {{ config.machine }} · {{ config.ipAddress }} · {{ config.data.length }}
            samples
          </p>
          <button class="btn btn--cancel" @click="$emit('close')">Close</button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script>
import { ref, watch, onMounted, onUnmounted, nextTick } from 'vue'
import {
  Chart,
  LineController,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import zoomPlugin from 'chartjs-plugin-zoom'

// 1. DAFTARKAN SEMUA KOMPONEN (Hanya satu kali pendaftaran)
Chart.register(
  LineController,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  zoomPlugin
);

// 2. CONSTANTS (Warna & Icons)
const CH_COLORS = [
  '#007AFF', '#30D158', '#FF9F0A', '#BF5AF2',
  '#FF2D55', '#32ADE6', '#A2845E', '#FF6B6B',
  '#5856D6', '#34C759',
]

const ZoomInIcon = {
  template: `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    <line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/>
  </svg>`
}
const ZoomOutIcon = {
  template: `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
    <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
    <line x1="8" y1="11" x2="14" y2="11"/>
  </svg>`
}
const ResetIcon = {
  template: `<svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
    <polyline points="1 4 1 10 7 10"/>
    <path d="M3.51 15a9 9 0 1 0 .49-4.5"/>
  </svg>`
}

const LimitChip = {
  props: { color: String, label: String },
  template: `
    <span class="limit-chip" :style="{ borderColor: color + '44', color, background: color + '0D' }">
      <span class="limit-dash" :style="{ borderColor: color }" />
      {{ label }}
    </span>
  `
}

// 3. EXPORT DEFAULT
export default {
  name: 'GraphModal',
  components: {ZoomInIcon, ZoomOutIcon, ResetIcon, LimitChip },
  props: {
    config: { type: Object, required: true }
  },
  emits: ['close'],

  setup(props, { emit }) {
    const showChannels = ref(false)
    const selectedChannels = ref([])
    const canvasRef = ref(null)
    let chartInstance = null

    function buildDatasets() {

      const sets = []

      selectedChannels.value.forEach(ch => {

        const i = ch - 1

        sets.push({

          label: `CH${ch}`,

          data: props.config.data.map(
            d => d.values[i]
          ),

          borderColor:
            CH_COLORS[i % CH_COLORS.length],

          backgroundColor:
            CH_COLORS[i % CH_COLORS.length] + '18',

          borderWidth: 2,

          pointRadius: 0,

          pointHoverRadius: 5,

          tension: 0.2
        })
      })

      sets.push({
        label: `USL ${props.config.maxV} V`,
        data: Array(props.config.data.length)
          .fill(props.config.maxV),
        borderColor: '#FF3B30',
        borderDash: [7, 4],
        pointRadius: 0
      })

      sets.push({
        label: `LSL ${props.config.minV} V`,
        data: Array(props.config.data.length)
          .fill(props.config.minV),
        borderColor: '#FF9F0A',
        borderDash: [7, 4],
        pointRadius: 0
      })

      return sets
    }

    function getLabels() {
      const labels = props.config.data.map(d => d.timestamp)
      const step = Math.max(1, Math.floor(labels.length / 10))
      return labels.map((l, i) => (i % step === 0 ? l : ''))
    }

    function buildChart() {
      if (!canvasRef.value || props.config.data.length === 0) return
      if (chartInstance) { chartInstance.destroy(); chartInstance = null }

      chartInstance = new Chart(canvasRef.value, {
        type: 'line',
        data: { labels: getLabels(), datasets: buildDatasets() },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 250 },
          interaction: { mode: 'nearest', intersect: false },
          plugins: {
            legend: {
              position: 'top',
              align: 'start',
              labels: {
                font: { size: 14, family: "'IBM Plex Sans', -apple-system, sans-serif" },
                boxWidth: 24, boxHeight: 3, padding: 20,
                color: '#3A3A3C', usePointStyle: false,
              },
            },
            tooltip: {
              position: 'nearest',

              callbacks: {

                title(items) {
                  const idx = items[0].dataIndex
                  return props.config.data[idx].timestamp
                },

                label(ctx) {
                  return `${ctx.dataset.label}: ${ctx.raw.toFixed(4)} V`
                },

                afterBody() {

                  return [
                    '',
                    `USL: ${props.config.maxV.toFixed(4)} V`,
                    `LSL: ${props.config.minV.toFixed(4)} V`
                  ]
                }
              }
            },
            zoom: {
              pan: { enabled: true, mode: 'xy', threshold: 5 },
              zoom: {
                wheel: { enabled: true, speed: 0.08 },
                pinch: { enabled: true },
                mode: 'xy',
              },
              limits: { y: { min: 'original', max: 'original' } },
            },
          },
          scales: {
            x: {
              ticks: {
                font: { size: 14, family: "'IBM Plex Sans', -apple-system, sans-serif" },
                color: '#8E8E93', maxRotation: 30, autoSkip: true, maxTicksLimit: 10,
              },
              grid: { color: 'rgba(0,0,0,0.05)' },
              border: { display: false },
            },
            y: {
              title: {
                display: true, text: 'Voltage  [V]',
                font: { size: 14, family: "'IBM Plex Sans', -apple-system, sans-serif" },
                color: '#8E8E93',
              },
              ticks: {
                font: { size: 14, family: "'IBM Plex Sans', -apple-system, sans-serif" },
                color: '#8E8E93',
              },
              grid: { color: 'rgba(0,0,0,0.05)' },
              border: { display: false },
            },
          },
        },
      })
    }

    watch(selectedChannels, async () => {
      await nextTick()
      if (chartInstance) {
        chartInstance.data.datasets = buildDatasets()
        chartInstance.update()
      }
    })

    onMounted(async () => {
      window.addEventListener('keydown', handleKey)
      await nextTick()
      buildChart()
    })

    onUnmounted(() => {
      window.removeEventListener('keydown', handleKey)
      if (chartInstance) chartInstance.destroy()
    })

    function handleKey(e) { if (e.key === 'Escape') emit('close') }
    function zoomIn() { chartInstance?.zoom(1.3) }
    function zoomOut() { chartInstance?.zoom(0.7) }
    function resetZoom() { chartInstance?.resetZoom() }

    return { selectedChannels, showChannels, canvasRef, zoomIn, zoomOut, resetZoom }
  }
}
</script>
