<template>
  <div class="field-box" :style="{ width: width, height: height }">
    <span class="field-label">{{ label }}</span>
    <div class="field-value-wrap" :title="value">
      <span class="field-value" :class="{ 'font-mono': mono }">
        {{ value }}
      </span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'FieldBox',
  props: {
    label: { type: String, required: true },
    value: { type: String, default: '' },
    width: { type: String, default: 'auto' },
    height: { type: String, default: 'auto' },
    mono: { type: Boolean, default: false }
  }
}
</script>
