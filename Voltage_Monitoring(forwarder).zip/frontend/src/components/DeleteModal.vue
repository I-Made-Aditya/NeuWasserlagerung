<template>
    <div class="modal-overlay" @click.self="$emit('close')">
        <div class="delete-modal">
            <div class="modal-header">
                <h3>Confirm Deletion</h3>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this configuration?!</p>
            </div>
            <div class="modal-footer">
                <button class="btn-no" @click="$emit('close')">No</button>
                <button class="btn-yes" @click="$emit('confirm')">Yes</button>
            </div>
        </div>
    </div>
</template>
