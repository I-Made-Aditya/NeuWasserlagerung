import { reactive, computed } from 'vue'
import api from '../services/api'

function loadUser() {
  try {
    const raw = localStorage.getItem('vms_user')
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

const state = reactive({
  token: localStorage.getItem('vms_token') || null,
  user: loadUser(),
})

export const isAuthenticated = computed(() => !!state.token)
export const currentUser = computed(() => state.user)
export const isAdmin = computed(() => state.user?.role === 'administrator')

export async function login(username, password) {
  const res = await api.post('/auth/login', { username, password })
  const { access_token, user } = res.data
  state.token = access_token
  state.user = user
  localStorage.setItem('vms_token', access_token)
  localStorage.setItem('vms_user', JSON.stringify(user))
  return user
}

export function logout() {
  state.token = null
  state.user = null
  localStorage.removeItem('vms_token')
  localStorage.removeItem('vms_user')
}

// If the API tells us the token is no longer valid, clear local state too.
window.addEventListener('vms:unauthorized', () => {
  logout()
})

export default { state, isAuthenticated, currentUser, isAdmin, login, logout }
