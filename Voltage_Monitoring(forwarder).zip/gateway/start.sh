#!/usr/bin/env bash
set -e

echo "============================================"
echo "  Voltage Monitoring Gateway - Linux Start"
echo "============================================"

cd "$(dirname "$0")"

if [ ! -d venv ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# shellcheck disable=SC1091
source venv/bin/activate

echo "Installing dependencies..."
pip install -r requirements.txt

if [ ! -f .env ]; then
    echo "No .env found - copying .env.example to .env"
    cp .env.example .env
    echo
    echo "IMPORTANT: edit .env now and set TRANSFER_BACKEND_URL to your"
    echo "           Transfer Server address, e.g. http://172.28.10.10:8000"
    echo
    exit 1
fi

echo "Starting gateway on port 8080 ..."
exec uvicorn app.main:app --host 0.0.0.0 --port 8080
