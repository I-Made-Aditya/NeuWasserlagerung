"""
Shared FastAPI dependencies for the gateway.

There is exactly one: access to the long-lived httpx.AsyncClient that is
created once at application startup (app/main.py) and reused for every
proxied request, so we benefit from HTTP connection pooling/keep-alive
towards the Transfer Server instead of opening a new TCP connection per
request.
"""
import httpx
from fastapi import Request


def get_http_client(request: Request) -> httpx.AsyncClient:
    return request.app.state.http_client
