"""
Gateway settings.

The Gateway is intentionally "dumb": it has no database, no business
logic, and no knowledge of DAQ instruments. Its only job is to sit on
the Prod Server and forward every request it receives to the Transfer
Server backend, byte-for-byte.
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ── Upstream backend (Transfer Server) ──────────────────────────────
    # e.g. http://172.28.10.10:8000  (NO trailing slash, NO /api suffix —
    # the gateway forwards the exact path it receives, including /api/...)
    TRANSFER_BACKEND_URL: str = "http://172.28.10.10:8000"

    # ── Gateway's own listening port (used by start.bat/start.sh/Docker) ──
    GATEWAY_PORT: int = 8080

    # ── CORS: origins allowed to call THIS gateway (the office frontend) ──
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"

    # ── Timeouts (seconds) for the gateway -> backend hop ───────────────
    # READ_TIMEOUT is generous by default because CSV/Excel exports over a
    # wide date range, or a DAQ instrument that responds slowly, can take
    # a while — the gateway should not time out before the backend does.
    CONNECT_TIMEOUT_SECONDS: float = 10.0
    READ_TIMEOUT_SECONDS: float = 120.0
    WRITE_TIMEOUT_SECONDS: float = 60.0
    POOL_TIMEOUT_SECONDS: float = 10.0

    # ── Connection pool sizing towards the backend ──────────────────────
    MAX_CONNECTIONS: int = 100
    MAX_KEEPALIVE_CONNECTIONS: int = 20

    LOG_LEVEL: str = "INFO"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def backend_base_url(self) -> str:
        return self.TRANSFER_BACKEND_URL.rstrip("/")


@lru_cache
def get_settings() -> Settings:
    return Settings()
