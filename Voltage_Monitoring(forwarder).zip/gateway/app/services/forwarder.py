"""
Generic, route-agnostic HTTP forwarder.

This module contains ALL the logic needed to transparently proxy a
request to the Transfer Server backend and stream its response back —
no endpoint-specific code lives here or anywhere else in the gateway.
Because it is fully generic, any current OR future backend route
(new export formats, new device endpoints, new DAQ commands, etc.)
is automatically supported by the gateway with zero code changes.

Design notes
------------
* We use `client.send(request, stream=True)` + `response.aiter_raw()`
  (NOT `aiter_bytes()`) so bytes are relayed exactly as received on the
  wire, with no re-encoding/re-compression. This lets us safely forward
  the original `Content-Encoding`/`Content-Length` headers unchanged —
  correct for text, JSON, CSV, and binary XLSX payloads alike.
* Only true "hop-by-hop" headers (RFC 7230 §6.1) are stripped; every
  other header — Authorization (JWT), Content-Type, Content-Disposition,
  custom headers, etc. — passes through untouched in both directions.
* Query string is forwarded as the exact raw string from the incoming
  request (not re-parsed/re-encoded), so special characters, repeated
  keys, and encoding are preserved exactly (important for the date-range
  and export query parameters used by /configs/{id}/export/*).
* Streaming end-to-end: the gateway never buffers the full response body
  in memory, so large CSV/Excel exports or big data-history payloads are
  relayed chunk-by-chunk.
"""
import logging
from typing import AsyncIterator, Iterable, Set

import httpx
from fastapi import Request
from fastapi.responses import JSONResponse, StreamingResponse

from app.config import get_settings

logger = logging.getLogger("gateway.forwarder")
settings = get_settings()

# Headers that must never be forwarded as-is between hops (RFC 7230 §6.1).
HOP_BY_HOP_HEADERS: Set[str] = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailers",
    "transfer-encoding",
    "upgrade",
}

# Additional headers stripped only on the REQUEST side, because httpx
# must recompute them itself based on the exact bytes/target we send.
REQUEST_STRIP_HEADERS: Set[str] = HOP_BY_HOP_HEADERS | {"host", "content-length"}

# On the RESPONSE side we deliberately do NOT strip content-length or
# content-encoding — see module docstring (`aiter_raw` rationale above).
# We DO strip `date` and `server`: the gateway's own ASGI server (uvicorn)
# always injects fresh copies of these, so forwarding the backend's
# versions unchanged would produce duplicate headers in the final
# response sent to the browser.
RESPONSE_STRIP_HEADERS: Set[str] = HOP_BY_HOP_HEADERS | {"date", "server"}


def _filter_headers(headers: Iterable, strip: Set[str]) -> dict:
    return {k: v for k, v in headers.items() if k.lower() not in strip}


def build_target_url(full_path: str, raw_query_string: str) -> str:
    url = f"{settings.backend_base_url}/{full_path}"
    if raw_query_string:
        url = f"{url}?{raw_query_string}"
    return url


async def forward_request(request: Request, full_path: str):
    """
    Forward `request` to `{TRANSFER_BACKEND_URL}/{full_path}` (including
    the original query string), then stream the backend's response back
    to the original caller with status code, headers, and body preserved.
    """
    client: httpx.AsyncClient = request.app.state.http_client
    target_url = build_target_url(full_path, request.url.query)

    body = await request.body()
    forward_headers = _filter_headers(request.headers, REQUEST_STRIP_HEADERS)

    request_id = getattr(request.state, "request_id", None)
    if request_id:
        forward_headers["X-Request-ID"] = request_id

    logger.debug("Forwarding %s %s -> %s", request.method, request.url.path, target_url)

    try:
        upstream_request = client.build_request(
            method=request.method,
            url=target_url,
            headers=forward_headers,
            content=body if body else None,
        )
        upstream_response = await client.send(upstream_request, stream=True)
    except httpx.ConnectTimeout:
        logger.error("Connect timeout reaching backend at %s", target_url)
        return JSONResponse(
            status_code=504,
            content={"detail": "Timed out connecting to the backend server.", "target": target_url},
        )
    except httpx.ReadTimeout:
        logger.error("Read timeout waiting for backend response from %s", target_url)
        return JSONResponse(
            status_code=504,
            content={"detail": "Backend server took too long to respond.", "target": target_url},
        )
    except httpx.ConnectError as exc:
        logger.error("Cannot connect to backend at %s: %s", target_url, exc)
        return JSONResponse(
            status_code=502,
            content={"detail": "Cannot reach the backend server.", "target": target_url, "error": str(exc)},
        )
    except httpx.RequestError as exc:
        logger.error("Error forwarding request to %s: %s", target_url, exc)
        return JSONResponse(
            status_code=502,
            content={"detail": "Error forwarding request to backend.", "target": target_url, "error": str(exc)},
        )

    response_headers = _filter_headers(upstream_response.headers, RESPONSE_STRIP_HEADERS)

    async def stream_upstream_body() -> AsyncIterator[bytes]:
        try:
            async for chunk in upstream_response.aiter_raw():
                yield chunk
        finally:
            await upstream_response.aclose()

    return StreamingResponse(
        stream_upstream_body(),
        status_code=upstream_response.status_code,
        headers=response_headers,
        media_type=upstream_response.headers.get("content-type"),
    )
