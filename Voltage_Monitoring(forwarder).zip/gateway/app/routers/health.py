"""
Gateway's own health endpoints. These are the ONLY two routes that are
handled directly by the gateway instead of being forwarded — everything
else falls through to the generic proxy (app/routers/proxy.py).
"""
import httpx
from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.dependencies import get_http_client

router = APIRouter(tags=["gateway-health"])
settings = get_settings()


@router.get("/health")
async def health():
    """Liveness check for the gateway process itself — does NOT touch the backend."""
    return {"gateway": "ok"}


@router.get("/backend-health")
async def backend_health(client: httpx.AsyncClient = Depends(get_http_client)):
    """
    Connectivity check: gateway calls the Transfer Server backend's own
    /api/health endpoint and reports whether it's reachable.
    """
    target = f"{settings.backend_base_url}/api/health"
    try:
        resp = await client.get(target, timeout=5.0)
        return {
            "gateway": "ok",
            "backend": "ok" if resp.status_code == 200 else "degraded",
            "backend_status_code": resp.status_code,
            "backend_url": settings.TRANSFER_BACKEND_URL,
        }
    except httpx.RequestError as exc:
        return JSONResponse(
            status_code=503,
            content={
                "gateway": "ok",
                "backend": "unreachable",
                "backend_url": settings.TRANSFER_BACKEND_URL,
                "error": str(exc),
            },
        )
