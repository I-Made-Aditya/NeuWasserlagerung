"""
Catch-all proxy router.

This single route matches EVERY path the gateway doesn't explicitly
handle itself (i.e. everything except /health and /backend-health,
which are registered before this router in app/main.py and therefore
take precedence).

Because matching is purely path-based with no knowledge of what the
route "means", any current or future backend endpoint — /api/configs,
/api/auth/login, /api/devices, /api/DAQ6510/{ip}/4-wire,
/api/configs/{id}/export/csv, anything added later — is automatically
supported without touching this file.
"""
from fastapi import APIRouter, Request

from app.services.forwarder import forward_request

router = APIRouter()


@router.api_route(
    "/{full_path:path}",
    methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS", "HEAD"],
    include_in_schema=False,
)
async def proxy_all(full_path: str, request: Request):
    return await forward_request(request, full_path)
