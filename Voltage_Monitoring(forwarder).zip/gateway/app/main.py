"""
Voltage Monitoring Gateway — entrypoint.

Runs on the Prod Server. Its ONLY job is to receive requests from the
office frontend and transparently forward them to the Transfer Server
backend (Voltage Monitoring Backend), then relay the response back
unchanged. It contains no business logic, no database access, and no
DAQ communication — see app/services/forwarder.py for the proxy core.
"""
import logging
import time
import uuid

import httpx
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import get_settings
from app.routers import health, proxy

settings = get_settings()

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
logger = logging.getLogger("gateway")

app = FastAPI(
    title="Voltage Monitoring Gateway",
    description=(
        "Transparent reverse-proxy gateway. Forwards every request from the "
        "office frontend (via the Prod Server) to the Voltage Monitoring "
        "Backend running on the Transfer Server. No business logic lives here."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """
    Tags every request with an X-Request-ID (reused from the caller if
    already present, e.g. set by an upstream nginx) and logs method,
    path, resulting status code, and latency. The same request id is
    also passed on to the backend (see forwarder.py) so log lines from
    both services can be correlated.
    """
    request_id = request.headers.get("x-request-id", str(uuid.uuid4()))
    request.state.request_id = request_id
    start = time.perf_counter()

    try:
        response = await call_next(request)
    except Exception:
        logger.exception(
            "[%s] Unhandled gateway error while proxying %s %s",
            request_id, request.method, request.url.path,
        )
        return JSONResponse(
            status_code=502,
            content={"detail": "Unexpected gateway error while forwarding request.", "request_id": request_id},
        )

    duration_ms = (time.perf_counter() - start) * 1000
    response.headers["X-Request-ID"] = request_id
    logger.info(
        "[%s] %s %s -> %s (%.1f ms)",
        request_id, request.method, request.url.path, response.status_code, duration_ms,
    )
    return response


@app.on_event("startup")
async def on_startup():
    timeout = httpx.Timeout(
        connect=settings.CONNECT_TIMEOUT_SECONDS,
        read=settings.READ_TIMEOUT_SECONDS,
        write=settings.WRITE_TIMEOUT_SECONDS,
        pool=settings.POOL_TIMEOUT_SECONDS,
    )
    limits = httpx.Limits(
        max_connections=settings.MAX_CONNECTIONS,
        max_keepalive_connections=settings.MAX_KEEPALIVE_CONNECTIONS,
    )
    # One shared, connection-pooled client reused for every proxied request.
    app.state.http_client = httpx.AsyncClient(timeout=timeout, limits=limits, follow_redirects=False)
    logger.info(
        "Gateway started. Forwarding all traffic to TRANSFER_BACKEND_URL=%s",
        settings.TRANSFER_BACKEND_URL,
    )


@app.on_event("shutdown")
async def on_shutdown():
    await app.state.http_client.aclose()
    logger.info("Gateway shutting down, HTTP client closed.")


# Registration order matters: /health and /backend-health are matched
# first because they're explicit static paths; everything else falls
# through to the generic catch-all proxy registered last.
app.include_router(health.router)
app.include_router(proxy.router)
