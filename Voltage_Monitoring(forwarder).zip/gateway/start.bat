@echo off
setlocal

echo ============================================
echo   Voltage Monitoring Gateway - Windows Start
echo ============================================

if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)

call venv\Scripts\activate.bat

echo Installing dependencies...
pip install -r requirements.txt

if not exist .env (
    echo No .env found - copying .env.example to .env
    copy .env.example .env
    echo.
    echo IMPORTANT: edit .env now and set TRANSFER_BACKEND_URL to your
    echo            Transfer Server address, e.g. http://172.28.10.10:8000
    echo.
    pause
)

echo Starting gateway on port 8080 ...
uvicorn app.main:app --host 0.0.0.0 --port 8080

endlocal
pause
