# Voltage Monitoring Gateway

Reverse-proxy **Gateway** yang berjalan di **Prod Server**, menjembatani
Frontend (jaringan Office) dengan **Voltage Monitoring Backend** yang
berjalan di **Transfer Server** (yang punya akses langsung ke PostgreSQL
dan perangkat DAQ).

```
Office Users
   │  http://<prod-server>:8080/api/...
   ▼
Frontend (Vue.js)
   ▼
Prod Server  ── GATEWAY (proyek ini) ──┐
   │                                   │  http://<transfer-server>:8000/api/...
   ▼                                   ▼
Transfer Server ── Backend (FastAPI) ──► PostgreSQL + DAQ devices
```

## Prinsip desain

- **Gateway tidak punya business logic sama sekali.** Tidak ada koneksi
  database, tidak ada kode DAQ, tidak ada logika export/konversi resistansi.
  Semua itu tetap 100% di `backend/`.
- **Forwarding generik** — satu route catch-all (`/{full_path:path}`)
  meneruskan APAPUN yang diterima Gateway ke
  `TRANSFER_BACKEND_URL/{full_path}` persis apa adanya: method, header
  (termasuk `Authorization: Bearer <JWT>`), query string, dan body.
  Artinya endpoint backend baru di masa depan **otomatis** ikut ter-proxy
  tanpa perlu mengubah kode Gateway sedikit pun.
- **Streaming penuh** — response (termasuk file CSV/Excel besar) di-relay
  chunk-by-chunk, tidak pernah dibuffer penuh di memori Gateway.
- **Header response transparan** — `Content-Type`, `Content-Disposition`
  (penting untuk nama file download), dsb. diteruskan apa adanya.

## Struktur proyek

```
gateway/
├── app/
│   ├── main.py              # FastAPI app, CORS, logging middleware, lifecycle httpx client
│   ├── config.py              # Settings (.env)
│   ├── dependencies.py         # Dependency ke shared httpx.AsyncClient
│   ├── routers/
│   │   ├── health.py             # GET /health, GET /backend-health (satu-satunya route non-proxy)
│   │   └── proxy.py               # Catch-all forwarder untuk SEMUA route lain
│   └── services/
│       └── forwarder.py            # Logika inti: forward request + stream response
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── start.bat                 # Windows
├── start.sh                  # Linux
└── README.md
```

## Endpoint yang didukung

Karena forwarding-nya generik, **semua** route backend saat ini otomatis
ikut jalan lewat Gateway, contohnya:

```
POST   /api/auth/login
GET    /api/auth/me

GET    /api/configs
POST   /api/configs
GET    /api/configs/{id}
PUT    /api/configs/{id}
DELETE /api/configs/{id}

GET    /api/configs/{id}/data
GET    /api/configs/{id}/alarms
POST   /api/configs/{id}/alarms/{alarm_id}/release

GET    /api/configs/{id}/export/csv        (streaming, Content-Disposition dipertahankan)
GET    /api/configs/{id}/export/excel      (streaming, Content-Disposition dipertahankan)

GET    /api/devices

POST   /api/{equipment_type}/{ip_address}/{wire_mode}   (mis. /api/DAQ6510/192.168.1.101/4-wire)
```

Plus 2 endpoint milik Gateway sendiri:

```
GET /health           -> { "gateway": "ok" }
GET /backend-health    -> cek konektivitas Gateway -> Backend
```

## Setup & menjalankan

### 1. Konfigurasi

```bash
cd gateway
cp .env.example .env
```

Edit `.env`, minimal ubah:

```env
TRANSFER_BACKEND_URL=http://172.28.10.10:8000
CORS_ORIGINS=http://172.16.0.50:5173
```

### 2A. Windows (tanpa Docker)

Cukup double-click **`start.bat`**, atau jalankan dari Command Prompt:

```bat
start.bat
```

Script ini otomatis: membuat virtualenv → install dependencies → copy
`.env.example` ke `.env` jika belum ada → menjalankan `uvicorn` di port 8080.

### 2B. Linux (tanpa Docker)

```bash
chmod +x start.sh
./start.sh
```

Atau manual:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8080
```

### 2C. Docker (Windows maupun Linux)

```bash
docker compose up --build -d
```

Ini menjalankan container `voltage-monitoring-gateway`, expose port
`8080` (atau sesuai `GATEWAY_PORT` di `.env`), dengan healthcheck otomatis
memanggil `GET /health`.

## Uji coba

```bash
# Liveness gateway itu sendiri
curl http://localhost:8080/health

# Konektivitas gateway -> backend
curl http://localhost:8080/backend-health

# Contoh forwarding sungguhan (perlu login dulu untuk dapat token)
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"Admin#12345"}'

curl http://localhost:8080/api/configs \
  -H "Authorization: Bearer <token_dari_login>"

# Download export CSV lewat gateway (harus tetap berupa file valid)
curl -L "http://localhost:8080/api/configs/1/export/csv?start_date=2026-01-01&end_date=2026-01-31&mode=voltage&channel_group=1" \
  -H "Authorization: Bearer <token>" \
  -o test-export.csv
```

## Update Frontend (SATU-SATUNYA perubahan yang dibutuhkan)

Frontend **tidak perlu diubah sama sekali** kecuali base URL API-nya.
Di `frontend/src/services/api.js`, base URL diambil dari environment
variable. Cukup ubah nilainya agar menunjuk ke Gateway (Prod Server),
BUKAN langsung ke backend (Transfer Server) lagi:

```env
# frontend/.env
VITE_API_BASE_URL=http://172.26.x.x:8080/api
```

Ganti `172.26.x.x` dengan IP/hostname Prod Server tempat Gateway ini
berjalan. Tidak ada baris kode frontend lain yang perlu disentuh.

## Reverse proxy / HTTPS di depan Gateway (opsional tapi disarankan)

Gateway berjalan sebagai HTTP polos di port 8080. Untuk production,
disarankan meletakkan **nginx** (atau IIS/Caddy) di depan Gateway pada
Prod Server untuk menangani TLS/HTTPS, sehingga trafik dari Office ke
Prod Server terenkripsi:

```nginx
server {
    listen 443 ssl;
    server_name prod-server.internal;

    ssl_certificate     /etc/ssl/certs/prod-server.crt;
    ssl_certificate_key /etc/ssl/private/prod-server.key;

    location / {
        proxy_pass http://127.0.0.1:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # Penting untuk export CSV/Excel besar & body upload:
        proxy_read_timeout 300s;
        proxy_send_timeout 300s;
        client_max_body_size 50m;
    }
}
```

Catatan: nginx di sini HANYA menangani TLS termination antara Office dan
Prod Server. Koneksi Gateway → Transfer Server tetap HTTP biasa di
jaringan internal TDK Network (kecuali Anda juga ingin mengenkripsi hop
tersebut — cukup ganti `TRANSFER_BACKEND_URL=https://...` dan pastikan
backend juga di-terminate TLS di sisi Transfer Server).

## Troubleshooting

| Gejala | Kemungkinan penyebab | Solusi |
|---|---|---|
| `GET /health` gagal / connection refused | Gateway belum jalan, atau salah port | Cek proses uvicorn/container jalan, cek `GATEWAY_PORT` |
| `GET /backend-health` -> `"backend": "unreachable"` | Prod Server tidak bisa mencapai Transfer Server (firewall/IP salah) | Cek `TRANSFER_BACKEND_URL` di `.env`, coba `curl` manual dari Prod Server ke Transfer Server, cek firewall antar-VLAN |
| Semua request ke `/api/...` balas `502 Cannot reach the backend server` | Sama seperti di atas, backend down atau URL salah | Pastikan backend FastAPI benar-benar berjalan di Transfer Server pada port yang dikonfigurasi |
| Response `504 Timed out connecting` / `504 Backend server took too long` | Backend lambat merespons (mis. baca banyak channel DAQ, export tanggal panjang) | Naikkan `READ_TIMEOUT_SECONDS` di `.env` Gateway (dan juga timeout di reverse-proxy di depannya, jika ada) |
| Browser menunjukkan error CORS | Origin frontend belum diizinkan di Gateway | Tambahkan origin frontend (persis termasuk protokol & port) ke `CORS_ORIGINS` |
| Login (`POST /api/auth/login`) selalu 401 padahal password benar | Body tidak sampai utuh ke backend | Pastikan Content-Type `application/json` dikirim frontend; body diteruskan mentah oleh Gateway jadi masalah biasanya di frontend/backend, bukan Gateway |
| File CSV/Excel hasil download rusak/kosong | Header `Content-Disposition`/`Content-Type` tertukar, atau proxy lain di depan Gateway men-strip header | Uji langsung `curl` ke Gateway (lihat contoh di atas); jika nginx ada di depan, pastikan tidak ada `proxy_hide_header Content-Disposition` |
| Token JWT valid di backend langsung tapi gagal lewat Gateway | Header `Authorization` ter-strip di reverse-proxy depan Gateway | Pastikan reverse-proxy (nginx/IIS) meneruskan semua header, jangan strip `Authorization` |
| Perubahan `.env` tidak berefek | Proses lama masih jalan / gunakan cache | Restart uvicorn/container (`docker compose restart gateway`) |

## Environment variable reference

| Variabel | Default | Keterangan |
|---|---|---|
| `TRANSFER_BACKEND_URL` | `http://172.28.10.10:8000` | Alamat backend FastAPI di Transfer Server (tanpa trailing slash, tanpa `/api`) |
| `GATEWAY_PORT` | `8080` | Port yang dipakai `docker-compose.yml` untuk expose Gateway |
| `CORS_ORIGINS` | `http://localhost:5173,http://127.0.0.1:5173` | Daftar origin frontend yang diizinkan, pisahkan dengan koma |
| `CONNECT_TIMEOUT_SECONDS` | `10` | Timeout membuka koneksi TCP ke backend |
| `READ_TIMEOUT_SECONDS` | `120` | Timeout menunggu response backend (naikkan untuk export besar) |
| `WRITE_TIMEOUT_SECONDS` | `60` | Timeout mengirim body request ke backend |
| `POOL_TIMEOUT_SECONDS` | `10` | Timeout menunggu koneksi tersedia dari connection pool |
| `MAX_CONNECTIONS` | `100` | Maksimum koneksi simultan ke backend |
| `MAX_KEEPALIVE_CONNECTIONS` | `20` | Maksimum koneksi keep-alive yang di-pool |
| `LOG_LEVEL` | `INFO` | Level logging (`DEBUG`, `INFO`, `WARNING`, `ERROR`) |

## Yang SENGAJA tidak ada di Gateway

Sesuai requirement, Gateway ini **tidak** berisi:
- Koneksi/model PostgreSQL apa pun
- Kode komunikasi DAQ (SCPI, dsb.)
- Logika export CSV/Excel
- Logika konversi tegangan→resistansi
- Duplikasi validasi/aturan bisnis apa pun dari backend

Semua di atas murni tanggung jawab `backend/`. Menambah endpoint baru di
backend TIDAK memerlukan perubahan apa pun di Gateway.
