"""
Standalone seeding script — inserts the default administrator & engineer
accounts directly into the database using the same bcrypt hashing the
API uses. Useful when you set up the schema manually via db/schema.sql
and don't want to rely on the FastAPI startup auto-seed.

Usage (from backend/ directory, with your .env already configured):
    python -m scripts.seed_users
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app.database import SessionLocal, engine, Base, SCHEMA  # noqa: E402
from app.models import User, UserRole  # noqa: E402
from app.security import hash_password  # noqa: E402
from app.config import get_settings  # noqa: E402
from sqlalchemy import text  # noqa: E402

settings = get_settings()


def main():
    with engine.connect() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}"'))
        conn.commit()
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        created = []
        if not db.query(User).filter(User.username == settings.DEFAULT_ADMIN_USERNAME).first():
            db.add(User(
                username=settings.DEFAULT_ADMIN_USERNAME,
                full_name="Administrator",
                hashed_password=hash_password(settings.DEFAULT_ADMIN_PASSWORD),
                role=UserRole.administrator,
            ))
            created.append(settings.DEFAULT_ADMIN_USERNAME)

        if not db.query(User).filter(User.username == settings.DEFAULT_ENGINEER_USERNAME).first():
            db.add(User(
                username=settings.DEFAULT_ENGINEER_USERNAME,
                full_name="Engineer",
                hashed_password=hash_password(settings.DEFAULT_ENGINEER_PASSWORD),
                role=UserRole.engineer,
            ))
            created.append(settings.DEFAULT_ENGINEER_USERNAME)

        db.commit()
        if created:
            print(f"Created users: {', '.join(created)}")
        else:
            print("Users already exist, nothing to do.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
