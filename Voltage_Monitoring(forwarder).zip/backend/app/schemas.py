from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from app.models import UserRole, EquipmentType, WireMode, AlarmStatus


# ── Auth ──────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: Optional[str] = None
    role: UserRole
    is_active: bool


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class UserCreate(BaseModel):
    username: str
    password: str
    full_name: Optional[str] = None
    role: UserRole = UserRole.engineer

# ── Devices ───────────────────────────────────────────────────────────
class DeviceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    equipment_type: EquipmentType
    serial_number: str
    calibration_number: str
    ip_address: str
    is_active: bool


class DeviceLookupOut(BaseModel):
    """
    Ringan untuk dropdown frontend.
    """

    model_config = ConfigDict(from_attributes=True)

    id: int
    ip_address: str
    equipment_type: EquipmentType
    serial_number: str
    calibration_number: str
    
# ── Configuration ─────────────────────────────────────────────────────
class ConfigurationBase(BaseModel):
    active: bool = False
    projectName: str = Field("", alias="project_name")
    lomNr: str = Field("", alias="lom_nr")
    description: str = ""
    interval: int = 1
    duration: int = 1000
    minV: float = Field(0, alias="min_v")
    maxV: float = Field(10, alias="max_v")
    minR: float = Field(0, alias="min_r")
    maxR: float = Field(10000, alias="max_r")
    fixedResistor: float = Field(1000, alias="fixed_resistor")
    supplyVoltage: float = Field(5, alias="supply_voltage")
    machine: str = "Machine-1"
    expectedFinish: str = Field("—", alias="expected_finish")
    ipAddress: str = Field("192.168.1.100", alias="ip_address")
    netmask: str = "255.255.255.0"
    equipmentType: EquipmentType = Field(EquipmentType.DAQ9600, alias="equipment_type")
    wireMode: WireMode = Field(WireMode.four_wire, alias="wire_mode")
    channels: List[bool] = Field(default_factory=lambda: [False] * 80)

    model_config = ConfigDict(populate_by_name=True)


class ConfigurationCreate(ConfigurationBase):
    pass


class ConfigurationUpdate(ConfigurationBase):
    pass


class DataPointOut(BaseModel):
    timestamp: str
    values: List[float]


class ConfigurationOut(ConfigurationBase):
    id: int
    data: List[DataPointOut] = Field(default_factory=list)

    model_config = ConfigDict(populate_by_name=True)


# ── Measurement / DAQ trigger ────────────────────────────────────────
class ManualReadingOut(BaseModel):
    equipment_type: EquipmentType
    ip_address: str
    wire_mode: WireMode
    channels_read: List[int]
    values: List[float]
    timestamp: str
    simulated: bool


# ── Alarms ────────────────────────────────────────────────────────────
class AlarmOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    config_id: int
    channel_no: int
    value: Optional[float] = None
    status: AlarmStatus
    remark: Optional[str] = None
    created_at: datetime
    released_at: Optional[datetime] = None


class AlarmReleaseRequest(BaseModel):
    remark: str
