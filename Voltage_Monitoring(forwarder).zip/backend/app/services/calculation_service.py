from typing import List, Optional


def voltage_to_resistance(
    voltage: float,
    fixed_resistor: float,
    supply_voltage: float
) -> Optional[float]:
    """
    Convert measured voltage from a voltage divider
    circuit to NTC resistance.
    Formula:
    Rntc = (Vmeasured * Rfixed)/(Vsupply - Vmeasured)
    """
    if voltage <= 0.0:
        return 0.0

    if voltage < 0:
        return 0.0

    if fixed_resistor < 1:
        return 0.0

    if supply_voltage <= 0:
        return 0.0

    denominator = supply_voltage-voltage

    if abs(denominator) < 1e-9:
        return 0.0

    return round((voltage * fixed_resistor) / denominator, 4)


def convert_values_to_resistance(
    values: List[float],
    fixed_resistor: float,
    supply_voltage: float
) -> List[Optional[float]]:
    return [
        voltage_to_resistance(
            voltage=v,
            fixed_resistor=fixed_resistor,
            supply_voltage=supply_voltage
        )
        for v in values
    ]