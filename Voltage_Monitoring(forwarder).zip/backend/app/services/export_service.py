import csv
from io import StringIO, BytesIO
from openpyxl import Workbook
from openpyxl.styles import Font

def build_export_rows(rows, start_channel: int, end_channel: int):
    result = []
    for row in rows:
        export_row = {
            "Timestamp": row.timestamp.strftime(
                "%d.%m.%y %H:%M"
            )
        }
        for ch in range(start_channel, end_channel + 1):
            export_row[f"CH{ch + 1}"] = (
                row.values[ch]
                if ch < len(row.values)
                else None
            )
        result.append(export_row)
    return result

def create_csv_export(config, rows, measurement_mode: str, channel_group: int, start_channel: int, end_channel: int, start_date: str, end_date: str,):
    export_rows = build_export_rows(rows, start_channel,end_channel)
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(["Project Name", config.project_name])
    writer.writerow(["LOM Nr", config.lom_nr])
    writer.writerow(["Description", config.description])
    writer.writerow([])
    writer.writerow(["Machine", config.machine])
    writer.writerow(["Equipment Type", config.equipment_type])
    writer.writerow(["Wire Mode", config.wire_mode])
    writer.writerow([])
    writer.writerow(["Fixed Resistor", config.fixed_resistor])
    writer.writerow(["Power Supply", config.supply_voltage])
    writer.writerow([])
    writer.writerow(["Measurement Type", measurement_mode])
    writer.writerow(["Channel Group", f"CH Group {channel_group}"])
    writer.writerow(["Start Date", start_date])
    writer.writerow(["End Date", end_date])
    writer.writerow([])
    headers = ["Timestamp"]
    for ch in range(start_channel, end_channel + 1):
        headers.append(f"CH{ch + 1}")
    writer.writerow(headers)
    for row in export_rows:
        writer.writerow([row[h] for h in headers])
    return output.getvalue()

def create_excel_export(
    config,
    rows,
    measurement_mode: str,
    channel_group: int,
    start_channel: int,
    end_channel: int,
    start_date: str,
    end_date: str,
):
    export_rows = build_export_rows(
        rows,
        start_channel,
        end_channel
    )
    wb = Workbook()
    ws = wb.active
    ws.title = "Measurement Data"
    info_rows = [
        ["Project Name", config.project_name],
        ["LOM Nr", config.lom_nr],
        ["Description", config.description],

        [],
        ["Machine", config.machine],
        ["Equipment Type", str(config.equipment_type)],
        ["Wire Mode", str(config.wire_mode)],

        [],
        ["Fixed Resistor (Ohm)", config.fixed_resistor],
        ["Power Supply (V)", config.supply_voltage],

        [],
        ["Measurement Type", measurement_mode],
        ["Channel Group", f"CH Group {channel_group}"],

        ["Start Date", start_date],
        ["End Date", end_date],
    ]
    for row in info_rows:
        ws.append(row)
    ws.append([])
    headers = ["Timestamp"]
    for ch in range(
        start_channel,
        end_channel + 1
    ):
        headers.append(
            f"CH{ch + 1}"
        )

    ws.append(headers)
    # Bold header
    for cell in ws[ws.max_row]:
        cell.font = Font(bold=True)
    # Measurement data
    for row in export_rows:
        ws.append(
            [row[h] for h in headers]
        )
    # Auto width
    for column in ws.columns:
        length = max(
            len(str(cell.value))
            if cell.value is not None
            else 0
            for cell in column
        )
        ws.column_dimensions[
            column[0].column_letter
        ].width = length + 2
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    return output.getvalue()
