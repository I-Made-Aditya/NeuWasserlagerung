"""
In-process background monitoring engine.

For every Configuration whose `active=True`, a loop runs every
`config.interval` seconds, reads all *enabled* channels from the
appropriate DAQ driver (DAQ6510 or DAQ9600, 2-wire or 4-wire as
configured), stores a MeasurementData row, and opens an AlarmEvent
whenever a value falls outside [min_v, max_v].

This is intentionally a lightweight asyncio-task based scheduler
(no external broker needed). For a multi-worker / multi-process
production deployment, replace this with Celery + Redis or APScheduler
backed by the database, but the public interface (start_monitoring /
stop_monitoring) would stay the same.
"""
import asyncio
import logging
from datetime import datetime
from typing import Dict

from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import Configuration, MeasurementData, AlarmEvent, AlarmStatus
from app.daq_drivers.factory import get_driver

logger = logging.getLogger("monitoring_service")

_tasks: Dict[int, asyncio.Task] = {}


def is_running(config_id: int) -> bool:
    task = _tasks.get(config_id)
    return task is not None and not task.done()


async def start_monitoring(config_id: int):
    if is_running(config_id):
        return
    task = asyncio.create_task(_run_loop(config_id))
    _tasks[config_id] = task


async def stop_monitoring(config_id: int):
    task = _tasks.pop(config_id, None)
    if task and not task.done():
        task.cancel()


async def stop_all():
    for config_id in list(_tasks.keys()):
        await stop_monitoring(config_id)


async def _run_loop(config_id: int):
    logger.info("Starting monitoring loop for config %s", config_id)
    try:
        while True:
            db: Session = SessionLocal()
            try:
                cfg = db.query(Configuration).filter(Configuration.id == config_id).first()
                if not cfg or not cfg.active:
                    logger.info("Config %s inactive/deleted, stopping loop", config_id)
                    return

                enabled_channels = [i + 1 for i, on in enumerate(cfg.channels or []) if on]
                if not enabled_channels:
                    enabled_channels = list(range(1, 81))

                driver = get_driver(cfg.equipment_type.value, cfg.ip_address)
                values_read = driver.read_channels(
                    enabled_channels, cfg.wire_mode.value,
                    min_v=float(cfg.min_v), max_v=float(cfg.max_v),
                )

                full_row = [0.0] * 80
                for ch, v in zip(enabled_channels, values_read):
                    full_row[ch - 1] = v

                row = MeasurementData(
                    config_id=cfg.id,
                    timestamp=datetime.utcnow(),
                    values=full_row,
                )
                db.add(row)

                for ch in enabled_channels:
                    v = full_row[ch - 1]
                    if v < float(cfg.min_v) or v > float(cfg.max_v):
                        existing_open = (
                            db.query(AlarmEvent)
                            .filter(
                                AlarmEvent.config_id == cfg.id,
                                AlarmEvent.channel_no == ch,
                                AlarmEvent.status == AlarmStatus.open,
                            )
                            .first()
                        )
                        if not existing_open:
                            db.add(AlarmEvent(config_id=cfg.id, channel_no=ch, value=v, status=AlarmStatus.open))

                db.commit()
                interval = max(1, int(cfg.interval))
            finally:
                db.close()

            await asyncio.sleep(interval)
    except asyncio.CancelledError:
        logger.info("Monitoring loop for config %s cancelled", config_id)
        raise
    except Exception:
        logger.exception("Monitoring loop for config %s crashed", config_id)


async def resume_all_active_configs():
    """Called once on app startup so previously-active configs keep logging after a backend restart."""
    db: Session = SessionLocal()
    try:
        active_ids = [c.id for c in db.query(Configuration).filter(Configuration.active == True).all()]  # noqa: E712
    finally:
        db.close()
    for cid in active_ids:
        await start_monitoring(cid)
