"""
GWInstek DAQ9600 driver.

GWInstek's DAQ/data-acquisition units are also SCPI-over-LAN instruments.
Command mnemonics below follow the general GWInstek DAQ SCPI subsystem
(ROUTe / SENSe / FETCh). Confirm exact syntax against the DAQ9600
programming manual for your firmware revision before production use.
"""
from typing import List

from app.daq_drivers.base import BaseDAQDriver


class Daq9600Driver(BaseDAQDriver):
    equipment_type = "DAQ9600"

    def _configure(self, wire_mode: str):
        self._write("*RST")
        self._write("*CLS")
        if wire_mode == "4-wire":
            self._write("SENS:FUNC 'FRES'")      # 4-wire resistance
        else:
            self._write("SENS:FUNC 'VOLT:DC'")   # 2-wire / DC volts default

    def _scpi_read(self, channel_numbers: List[int], wire_mode: str) -> List[float]:
        chan_list = ",".join(str(c) for c in channel_numbers)
        self._write(f"ROUT:SCAN (@{chan_list})")
        self._write("INIT")
        raw = self._query("FETC?")
        return [float(v) for v in raw.split(",") if v.strip()]
