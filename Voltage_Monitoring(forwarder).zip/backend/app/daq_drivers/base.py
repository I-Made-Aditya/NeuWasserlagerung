"""
Common interface every physical DAQ driver must implement.

Both real instruments in this project (Keithley DAQ6510 and GWInstek DAQ9600)
speak SCPI. The typical transport is "SCPI-over-LAN raw socket" (commonly
TCP port 5025) — this base class implements the shared plumbing
(socket connect/write/query) so each concrete driver only needs to supply
its own SCPI command dialect.

IMPORTANT:
This module intentionally fails soft. If REAL_DAQ_MODE=false (the default,
see .env) or if the socket connection to the instrument fails, the driver
falls back to app.daq_drivers.simulator so the rest of the stack (DB,
alarms, API, UI) can be fully exercised without physical hardware attached.
Replace the `_scpi_*` methods with the exact command set from your
instrument's programming manual when wiring up real hardware.
"""
import abc
import socket
from typing import List

from app.config import get_settings
from app.daq_drivers import simulator

settings = get_settings()


class DAQConnectionError(Exception):
    pass


class BaseDAQDriver(abc.ABC):
    equipment_type: str = "GENERIC"

    def __init__(self, ip_address: str, port: int | None = None, timeout: float | None = None):
        self.ip_address = ip_address
        self.port = port or settings.DAQ_SCPI_PORT
        self.timeout = timeout or settings.DAQ_CONNECT_TIMEOUT_S
        self._sock: socket.socket | None = None

    # ── low level transport ────────────────────────────────────────
    def _connect(self):
        self._sock = socket.create_connection((self.ip_address, self.port), timeout=self.timeout)

    def _write(self, cmd: str):
        assert self._sock is not None
        self._sock.sendall((cmd.strip() + "\n").encode("ascii"))

    def _query(self, cmd: str) -> str:
        self._write(cmd)
        assert self._sock is not None
        data = self._sock.recv(65536)
        return data.decode("ascii", errors="ignore").strip()

    def close(self):
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None

    # ── high level API used by the rest of the app ─────────────────
    def read_channels(self, channel_numbers: List[int], wire_mode: str,
                       min_v: float = 0, max_v: float = 10) -> List[float]:
        """
        Returns one reading (in Volts) per requested channel number (1-based).
        Falls back to the simulator if REAL_DAQ_MODE is off, or if the
        instrument cannot be reached.
        """
        if not settings.REAL_DAQ_MODE:
            return simulator.simulate_reading(channel_numbers, min_v, max_v)

        try:
            self._connect()
            self._configure(wire_mode)
            values = self._scpi_read(channel_numbers, wire_mode)
            return values
        except (OSError, socket.timeout, DAQConnectionError):
            # Hardware unreachable -> fail soft into simulated data so
            # logging/alarm pipeline keeps working; a WARN should be logged
            # by the caller.
            return simulator.simulate_reading(channel_numbers, min_v, max_v)
        finally:
            self.close()

    @abc.abstractmethod
    def _configure(self, wire_mode: str):
        """Send instrument-specific SCPI setup commands (function, range, NPLC, wire mode...)."""

    @abc.abstractmethod
    def _scpi_read(self, channel_numbers: List[int], wire_mode: str) -> List[float]:
        """Trigger a scan/read and parse the SCPI response into a list of floats."""
