from app.daq_drivers.base import BaseDAQDriver
from app.daq_drivers.keithley_daq6510 import Daq6510Driver
from app.daq_drivers.gwinstek_daq9600 import Daq9600Driver

_DRIVERS = {
    "DAQ6510": Daq6510Driver,
    "DAQ9600": Daq9600Driver,
}


def get_driver(equipment_type: str, ip_address: str) -> BaseDAQDriver:
    cls = _DRIVERS.get(equipment_type)
    if cls is None:
        raise ValueError(f"Unsupported equipment_type: {equipment_type}")
    return cls(ip_address=ip_address)
