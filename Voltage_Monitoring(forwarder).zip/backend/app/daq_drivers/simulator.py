"""
Demo-mode signal generator. Used whenever REAL_DAQ_MODE=false, or when a
real instrument can't be reached — keeps the rest of the pipeline
(alarms, DB writes, charts) fully functional without hardware attached.

Logic mirrors the original frontend mock generator (mockData.js):
random values within [minV, maxV * 1.15] so a small fraction of samples
land above the upper spec limit and exercise the alarm path.
"""
import random
from typing import List


def simulate_reading(channel_numbers: List[int], min_v: float, max_v: float) -> List[float]:
    span = max(max_v - min_v, 0.0001)
    return [
        round(min_v + random.random() * span * 1.15, 4)
        for _ in channel_numbers
    ]
