"""
Keithley (Tektronix) DAQ6510 driver.

The DAQ6510 is a SCPI instrument, reachable over LAN (raw socket / VISA
TCPIP::<ip>::5025::SOCKET or via the LXI VXI-11 / HiSLIP interfaces).
Command set below follows the DAQ6500/DAQ6510 SCPI reference for the
7700-series multiplexer scan card. Adjust channel list syntax
("101:110" style, slot 1 channel 01..10) to match your actual card.

This is a working *template* — validate against your real card wiring
and instrument firmware before relying on it in production.
"""
from typing import List

from app.daq_drivers.base import BaseDAQDriver


class Daq6510Driver(BaseDAQDriver):
    equipment_type = "DAQ6510"

    def _configure(self, wire_mode: str):
        self._write("*RST")
        self._write("*CLS")
        if wire_mode == "4-wire":
            self._write('FUNC "FRES"')          # 4-wire resistance
        else:
            self._write('FUNC "VOLT:DC"')        # 2-wire / DC volts default
        self._write("TRAC:CLE")
        self._write("TRAC:POIN 100")

    def _scpi_read(self, channel_numbers: List[int], wire_mode: str) -> List[float]:
        chan_list = ",".join(str(100 + c) for c in channel_numbers)  # e.g. slot 1 -> 101..180
        self._write(f"ROUT:SCAN:CRE (@{chan_list})")
        self._write("ROUT:SCAN:COUN:SCAN 1")
        self._write("INIT")
        self._write("*WAI")
        raw = self._query(f"TRAC:DATA? 1, {len(channel_numbers)}, \"defbuffer1\", READ")
        return [float(v) for v in raw.split(",") if v.strip()]
