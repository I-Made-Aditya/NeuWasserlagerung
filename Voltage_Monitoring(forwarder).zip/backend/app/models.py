import enum
from datetime import datetime

from sqlalchemy import (
    Column, Integer, BigInteger, String, Boolean, Numeric, DateTime,
    ForeignKey, Enum as SAEnum, Text
)

from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.database import Base, SCHEMA


class UserRole(str, enum.Enum):
    administrator = "administrator"
    engineer = "engineer"


class EquipmentType(str, enum.Enum):
    DAQ6510 = "DAQ6510"   # Keithley
    DAQ9600 = "DAQ9600"   # GWInstek


class WireMode(str, enum.Enum):
    two_wire = "2-wire"
    four_wire = "4-wire"


class AlarmStatus(str, enum.Enum):
    open = "open"
    released = "released"
    
# ==========================
# Device Master
# ==========================
class Device(Base):
    __tablename__ = "devices"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True, index=True)

    equipment_type = Column(
        SAEnum(
            EquipmentType,
            name="equipment_type",
            schema=SCHEMA,
            values_callable=lambda x: [e.value for e in x]
        ),
        nullable=False
    )

    serial_number = Column(
        String(100),
        nullable=False,
        unique=True,
        index=True
    )

    calibration_number = Column(
        String(100),
        nullable=False,
        unique=True
    )

    ip_address = Column(
        String(64),
        nullable=False,
        unique=True,
        index=True
    )

    is_active = Column(
        Boolean,
        nullable=False,
        default=True
    )

    created_at = Column(
        DateTime,
        nullable=False,
        default=datetime.utcnow
    )

class User(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, nullable=False, index=True)
    full_name = Column(String(128), nullable=True)
    hashed_password = Column(String(255), nullable=False)
    role = Column(SAEnum(UserRole,name="user_role",schema=SCHEMA,values_callable=lambda x: [e.value for e in x]),nullable=False,default=UserRole.engineer)
    is_active = Column(Boolean, nullable=False, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Configuration(Base):
    """
    Mirrors exactly the fields used by the Vue UI (ConfigRow / SettingsModal).
    `channels` is stored as JSON array of 80 booleans (active/inactive per channel).
    """
    __tablename__ = "configurations"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True, index=True)
    active = Column(Boolean, nullable=False, default=False)

    project_name = Column(String(128), nullable=False, default="")
    lom_nr = Column(String(128), nullable=False, default="")
    description = Column(String(255), nullable=False, default="")

    interval = Column(Integer, nullable=False, default=1)       # seconds between samples
    duration = Column(Integer, nullable=False, default=1000)    # planned duration (hours, per UI label)
    min_v = Column(Numeric(10, 4), nullable=False, default=0)
    max_v = Column(Numeric(10, 4), nullable=False, default=10)
    
    min_r = Column(Numeric(10, 4), nullable=False, default=0)
    max_r = Column(Numeric(10, 4), nullable=False, default=10000)
    
    fixed_resistor = Column(Numeric(10, 4), nullable=False, default=1000)
    supply_voltage = Column(Numeric(10, 4), nullable=False, default=5)

    machine = Column(String(128), nullable=False, default="Machine-1")
    expected_finish = Column(String(32), nullable=False, default="—")

    ip_address = Column(String(64), nullable=False, default="192.168.1.100")
    netmask = Column(String(64), nullable=False, default="255.255.255.0")
    # equipment_type = Column(SAEnum(EquipmentType, name="equipment_type", schema=SCHEMA), nullable=False,
    #                          default=EquipmentType.DAQ9600)
    # wire_mode = Column(SAEnum(WireMode, name="wire_mode", schema=SCHEMA), nullable=False, default=WireMode.four_wire)
    equipment_type = Column(SAEnum(EquipmentType,name="equipment_type", schema=SCHEMA, values_callable=lambda x: [e.value for e in x]),nullable=False,default=EquipmentType.DAQ9600)
    wire_mode = Column(SAEnum(WireMode,name="wire_mode", schema=SCHEMA, values_callable=lambda x: [e.value for e in x]),nullable=False,default=WireMode.four_wire)
    channels = Column(JSONB,nullable=False,default=list)

    created_by = Column(Integer, ForeignKey(f"{SCHEMA}.users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    data_rows = relationship("MeasurementData", back_populates="config", cascade="all, delete-orphan")
    alarms = relationship("AlarmEvent", back_populates="config", cascade="all, delete-orphan")


class MeasurementData(Base):
    """One logged sample row: timestamp + 80 channel values (JSON array)."""
    __tablename__ = "measurement_data"
    __table_args__ = {"schema": SCHEMA}

    id = Column(BigInteger, primary_key=True, index=True)
    config_id = Column(Integer, ForeignKey(f"{SCHEMA}.configurations.id", ondelete="CASCADE"), nullable=False, index=True)
    timestamp = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    values = Column(JSONB, nullable=False)

    config = relationship("Configuration", back_populates="data_rows")


class AlarmEvent(Base):
    __tablename__ = "alarm_events"
    __table_args__ = {"schema": SCHEMA}

    id = Column(Integer, primary_key=True, index=True)
    config_id = Column(Integer, ForeignKey(f"{SCHEMA}.configurations.id", ondelete="CASCADE"), nullable=False, index=True)
    channel_no = Column(Integer, nullable=False)
    value = Column(Numeric(10, 4), nullable=True)
    status = Column(SAEnum(AlarmStatus,name="alarm_status",schema=SCHEMA,values_callable=lambda x: [e.value for e in x]),nullable=False,default=AlarmStatus.open)
    remark = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    released_by = Column(Integer, ForeignKey(f"{SCHEMA}.users.id"), nullable=True)
    released_at = Column(DateTime, nullable=True)

    config = relationship("Configuration", back_populates="alarms")
