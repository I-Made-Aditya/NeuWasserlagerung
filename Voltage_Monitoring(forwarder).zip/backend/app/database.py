"""
SQLAlchemy engine & session.

All application tables live inside a dedicated PostgreSQL schema
(default: "monitoringdaq") instead of "public", because IT only grants
CREATE privileges on a custom schema. See app/models.py where every
table declares `schema=settings.POSTGRES_SCHEMA` via `SCHEMA` constant.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import get_settings

settings = get_settings()

engine = create_engine(
    settings.sqlalchemy_database_url,
    pool_pre_ping=True,
    # make sure the search_path includes our schema so raw/legacy
    # queries without explicit schema prefix still resolve correctly
    connect_args={"options": f"-csearch_path={settings.POSTGRES_SCHEMA},public"},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

SCHEMA = settings.POSTGRES_SCHEMA


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
