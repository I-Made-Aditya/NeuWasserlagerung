from typing import List

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_user
from app.models import Device, User
from app.schemas import DeviceOut


router = APIRouter(
    prefix="/api/devices",
    tags=["devices"]
)


@router.get("", response_model=List[DeviceOut])
def list_devices(
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user)
):
    return (
        db.query(Device)
        .filter(Device.is_active == True)
        .order_by(Device.ip_address)
        .all()
    )