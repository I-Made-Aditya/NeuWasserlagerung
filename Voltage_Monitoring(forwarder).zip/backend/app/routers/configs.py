import asyncio
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import Response
from app.services.export_service import (
    create_csv_export,
    create_excel_export
)

from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_user, require_administrator
from app.models import Configuration, MeasurementData, AlarmEvent, AlarmStatus, User
from app.schemas import (
    ConfigurationCreate, ConfigurationUpdate, ConfigurationOut, DataPointOut,
    AlarmOut, AlarmReleaseRequest,
)
# from app.services import monitoring_service
from app.services import monitoring_service

from app.services.calculation_service import (
    convert_values_to_resistance
)

router = APIRouter(prefix="/api/configs", tags=["configurations"])


def _fmt_ts(dt: datetime) -> str:
    return dt.strftime("%d.%m.%y %H:%M")


def _to_out(cfg: Configuration, include_data: bool = True, data_limit: int = 500) -> ConfigurationOut:
    data = []
    if include_data:
        rows = (
            sorted(cfg.data_rows, key=lambda r: r.timestamp)[-data_limit:]
            if cfg.data_rows else []
        )
        data = [DataPointOut(timestamp=_fmt_ts(r.timestamp), values=r.values) for r in rows]

    return ConfigurationOut(
        id=cfg.id,
        active=cfg.active,
        project_name=cfg.project_name,
        lom_nr=cfg.lom_nr,
        description=cfg.description,
        interval=cfg.interval,
        duration=cfg.duration,
        min_v=float(cfg.min_v),
        max_v=float(cfg.max_v),
        min_r=float(cfg.min_r),
        max_r=float(cfg.max_r),
        fixed_resistor=float(cfg.fixed_resistor),
        supply_voltage=float(cfg.supply_voltage),
        machine=cfg.machine,
        expected_finish=cfg.expected_finish,
        ip_address=cfg.ip_address,
        netmask=cfg.netmask,
        equipment_type=cfg.equipment_type,
        wire_mode=cfg.wire_mode,
        channels=cfg.channels or [False] * 80,
        data=data,
    )


@router.get("", response_model=List[ConfigurationOut])
def list_configs(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    configs = db.query(Configuration).order_by(Configuration.id).all()
    return [_to_out(c) for c in configs]


@router.get("/{config_id}", response_model=ConfigurationOut)
def get_config(config_id: int, db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    cfg = db.query(Configuration).filter(Configuration.id == config_id).first()
    if not cfg:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Configuration not found")
    return _to_out(cfg)


@router.post("", response_model=ConfigurationOut, status_code=status.HTTP_201_CREATED)
def create_config(payload: ConfigurationCreate, db: Session = Depends(get_db),
                   admin: User = Depends(require_administrator)):
    
    if payload.fixedResistor < 1:
        raise HTTPException(
            status_code=400,
            detail="Fixed resistor must be >= 1 ohm"
        )
    if payload.supplyVoltage <= 0:
        raise HTTPException(
            status_code=400,
            detail="Supply voltage must be > 0"
        )
    cfg = Configuration(
        active=payload.active,
        project_name=payload.projectName,
        lom_nr=payload.lomNr,
        description=payload.description,
        interval=payload.interval,
        duration=payload.duration,
        min_v=payload.minV,
        max_v=payload.maxV,
        min_r=payload.minR,
        max_r=payload.maxR,
        fixed_resistor=payload.fixedResistor,
        supply_voltage=payload.supplyVoltage,
        machine=payload.machine,
        expected_finish=payload.expectedFinish,
        ip_address=payload.ipAddress,
        netmask=payload.netmask,
        equipment_type=payload.equipmentType,
        wire_mode=payload.wireMode,
        channels=payload.channels or [False] * 80,
        created_by=admin.id,
    )
    db.add(cfg)
    db.commit()
    db.refresh(cfg)
    return _to_out(cfg)


@router.put("/{config_id}", response_model=ConfigurationOut)
async def update_config(config_id: int, payload: ConfigurationUpdate, db: Session = Depends(get_db),
                         admin: User = Depends(require_administrator)):
    cfg = db.query(Configuration).filter(Configuration.id == config_id).first()
    if not cfg:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Configuration not found")

    if payload.fixedResistor < 1:
        raise HTTPException(
            status_code=400,
            detail="Fixed resistor must be >= 1 ohm"
        )
    if payload.supplyVoltage <= 0:
        raise HTTPException(
            status_code=400,
            detail="Supply voltage must be > 0"
        )
    was_active = cfg.active
    cfg.active = payload.active
    cfg.project_name = payload.projectName
    cfg.lom_nr = payload.lomNr
    cfg.description = payload.description
    cfg.interval = payload.interval
    cfg.duration = payload.duration
    cfg.min_v = payload.minV
    cfg.max_v = payload.maxV
    cfg.min_r = payload.minR
    cfg.max_r = payload.maxR
    cfg.fixed_resistor = payload.fixedResistor
    cfg.supply_voltage = payload.supplyVoltage
    cfg.machine = payload.machine
    cfg.expected_finish = payload.expectedFinish
    cfg.ip_address = payload.ipAddress
    cfg.netmask = payload.netmask
    cfg.equipment_type = payload.equipmentType
    cfg.wire_mode = payload.wireMode
    cfg.channels = payload.channels
    cfg.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(cfg)

    # Auto start/stop the background measurement loop when `active` flips.
    if cfg.active and not was_active:
        await monitoring_service.start_monitoring(cfg.id)
    elif not cfg.active and was_active:
        await monitoring_service.stop_monitoring(cfg.id)

    return _to_out(cfg)


@router.delete("/{config_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_config(config_id: int, db: Session = Depends(get_db),
                         admin: User = Depends(require_administrator)):
    cfg = db.query(Configuration).filter(Configuration.id == config_id).first()
    if not cfg:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Configuration not found")
    await monitoring_service.stop_monitoring(config_id)
    db.delete(cfg)
    db.commit()
    return None


@router.get("/{config_id}/data", response_model=List[DataPointOut])
def get_config_data(config_id: int, limit: int = 300, mode: str = "voltage", 
                start_date: str | None = None, end_date: str | None = None,
                db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    cfg = db.query(Configuration).filter(Configuration.id == config_id).first()
    if not cfg:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Configuration not found")
    # rows = (
    #     db.query(MeasurementData)
    #     .filter(MeasurementData.config_id == config_id)
    #     .order_by(MeasurementData.timestamp.desc())
    #     .limit(limit)
    #     .all()
    # )
    
    # print("CONFIG ID =", config_id)
    # print("ROWS FOUND =", len(rows))
    query = (
    db.query(MeasurementData).filter(
        MeasurementData.config_id == config_id
        )
    )
    if start_date and end_date:
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
        end = end.replace(hour=23, minute=59, second=59)
        rows = (query.filter(MeasurementData.timestamp >= start,MeasurementData.timestamp <= end)
                .order_by(MeasurementData.timestamp.asc()).all())
    else:
        rows = (query.order_by(MeasurementData.timestamp.desc()).limit(limit).all())
        
    rows.reverse()
    data = []
    for row in rows:
        values = row.values
        if (mode.lower() == "resistance" and cfg.wire_mode == "2-wire"):
            values = convert_values_to_resistance(
                values=row.values,
                fixed_resistor=float(cfg.fixed_resistor),
                supply_voltage=float(cfg.supply_voltage)
            )
        data.append(
            DataPointOut(
                timestamp=_fmt_ts(row.timestamp),
                values=values
            )
        )
    return data

@router.get("/{config_id}/export/csv")
def export_csv(config_id: int, start_date: str, end_date: str, mode: str, channel_group: int, db: Session = Depends(get_db),
                admin: User = Depends(require_administrator)):
    cfg = ( db.query(Configuration) .filter(Configuration.id == config_id).first())
    if not cfg:
        raise HTTPException(
            status_code=404,
            detail="Configuration not found"
        )

    start = datetime.strptime(
        start_date,
        "%Y-%m-%d"
    )
    end = datetime.strptime(
        end_date,
        "%Y-%m-%d"
    ).replace(hour=23,minute=59, second=59)
    rows = (
        db.query(MeasurementData)
        .filter(
            MeasurementData.config_id == config_id,
            MeasurementData.timestamp >= start,
            MeasurementData.timestamp <= end
        ).order_by(MeasurementData.timestamp.asc()).all()
    )
    start_channel = (channel_group - 1) * 10
    end_channel = start_channel + 9
    if(mode.lower() == "resistance" and cfg.wire_mode == "2-wire"):
        for row in rows:
            row.values = ( convert_values_to_resistance(
                    values=row.values,
                    fixed_resistor=float(cfg.fixed_resistor),
                    supply_voltage=float(cfg.supply_voltage)
                )
            )
    csv_content = create_csv_export(
        config=cfg,
        rows=rows,
        measurement_mode=mode,
        channel_group=channel_group,
        start_channel=start_channel,
        end_channel=end_channel,
        start_date=start_date,
        end_date=end_date
    )
    filename = (
        f"{cfg.project_name}"
        f"_CH{start_channel+1}"
        f"-{end_channel+1}"
        f"_{mode}.csv"
    )
    return Response(
        content=csv_content,
        media_type="text/csv",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"'
        }
    )

@router.get("/{config_id}/export/excel")
def export_excel(
    config_id: int,
    start_date: str,
    end_date: str,
    mode: str,
    channel_group: int,
    db: Session = Depends(get_db),
    admin: User = Depends(require_administrator)
):

    cfg = (
        db.query(Configuration)
        .filter(Configuration.id == config_id)
        .first()
    )

    if not cfg:
        raise HTTPException(
            status_code=404,
            detail="Configuration not found"
        )

    start = datetime.strptime(
        start_date,
        "%Y-%m-%d"
    )

    end = datetime.strptime(
        end_date,
        "%Y-%m-%d"
    ).replace(
        hour=23,
        minute=59,
        second=59
    )

    rows = (
        db.query(MeasurementData)
        .filter(
            MeasurementData.config_id == config_id,
            MeasurementData.timestamp >= start,
            MeasurementData.timestamp <= end
        )
        .order_by(
            MeasurementData.timestamp.asc()
        )
        .all()
    )

    start_channel = (channel_group - 1) * 10
    end_channel = start_channel + 9

    if (
        mode.lower() == "resistance"
        and cfg.wire_mode == "2-wire"
    ):
        for row in rows:
            row.values = convert_values_to_resistance(
                values=row.values,
                fixed_resistor=float(cfg.fixed_resistor),
                supply_voltage=float(cfg.supply_voltage)
            )

    excel_content = create_excel_export(
        config=cfg,
        rows=rows,
        measurement_mode=mode,
        channel_group=channel_group,
        start_channel=start_channel,
        end_channel=end_channel,
        start_date=start_date,
        end_date=end_date
    )

    filename = (
        f"{cfg.project_name}"
        f"_CH{start_channel+1}"
        f"-{end_channel+1}"
        f"_{mode}.xlsx"
    )

    return Response(
        content=excel_content,
        media_type=
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={
            "Content-Disposition":
            f'attachment; filename="{filename}"'
        }
    )
    
@router.get("/{config_id}/alarms", response_model=List[AlarmOut])
def list_alarms(config_id: int, status_filter: Optional[str] = None, db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    q = db.query(AlarmEvent).filter(AlarmEvent.config_id == config_id)
    if status_filter:
        q = q.filter(AlarmEvent.status == status_filter)
    alarms = q.order_by(AlarmEvent.created_at.desc()).all()
    return [AlarmOut.model_validate(a) for a in alarms]


@router.post("/{config_id}/alarms/{alarm_id}/release", response_model=AlarmOut)
def release_alarm(config_id: int, alarm_id: int, payload: AlarmReleaseRequest,
                   db: Session = Depends(get_db), admin: User = Depends(require_administrator)):
    alarm = (
        db.query(AlarmEvent)
        .filter(AlarmEvent.id == alarm_id, AlarmEvent.config_id == config_id)
        .first()
    )
    if not alarm:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Alarm not found")
    alarm.status = AlarmStatus.released
    alarm.remark = payload.remark
    alarm.released_by = admin.id
    alarm.released_at = datetime.utcnow()
    db.commit()
    db.refresh(alarm)
    return AlarmOut.model_validate(alarm)
