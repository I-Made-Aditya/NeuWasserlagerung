"""
Direct DAQ trigger endpoints, matching the shape requested:

    POST /api/DAQ6510/192.168.1.101/4-wire
    POST /api/DAQ9600/192.168.1.102/2-wire

Used for one-shot "Test Connection / Read Now" actions from the UI
(e.g. a button inside the Settings modal). Continuous logging tied to a
saved Configuration is handled separately by app/services/monitoring_service.py
and is started/stopped automatically whenever a configuration's
`active` flag is toggled via PUT /api/configs/{id}.
"""
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.config import get_settings
from app.deps import require_administrator
from app.models import User, EquipmentType, WireMode
from app.schemas import ManualReadingOut
from app.daq_drivers.factory import get_driver

router = APIRouter(prefix="/api", tags=["daq"])
settings = get_settings()


@router.post("/{equipment_type}/{ip_address}/{wire_mode}", response_model=ManualReadingOut)
def trigger_measurement(
    equipment_type: EquipmentType,
    ip_address: str,
    wire_mode: WireMode,
    channels: Optional[str] = Query(
        None, description="Comma-separated 1-based channel numbers, e.g. '1,2,3'. Defaults to channel 1."
    ),
    min_v: float = Query(0, description="Lower spec limit, only used by the simulator fallback"),
    max_v: float = Query(10, description="Upper spec limit, only used by the simulator fallback"),
    admin: User = Depends(require_administrator),
):
    """
    Perform ONE immediate measurement on the given instrument
    (2-Wire or 4-Wire) and return the readings. Administrator only.
    """
    try:
        channel_numbers: List[int] = (
            [int(c) for c in channels.split(",") if c.strip()] if channels else [1]
        )
    except ValueError:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid `channels` query parameter")

    driver = get_driver(equipment_type.value, ip_address)
    values = driver.read_channels(channel_numbers, wire_mode.value, min_v=min_v, max_v=max_v)

    return ManualReadingOut(
        equipment_type=equipment_type,
        ip_address=ip_address,
        wire_mode=wire_mode,
        channels_read=channel_numbers,
        values=values,
        timestamp=datetime.utcnow().isoformat(),
        simulated=not settings.REAL_DAQ_MODE,
    )
