"""
Central application settings.
Everything is read from environment variables / .env file so the
whole deployment can be reconfigured without touching source code.
"""
from functools import lru_cache
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # ── Database ──
    POSTGRES_HOST: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_DB: str = "voltage_monitoring"
    POSTGRES_USER: str = "voltage_app"
    POSTGRES_PASSWORD: str = "change_me"
    POSTGRES_SCHEMA: str = "monitoringdaq"
    DATABASE_URL: str = ""  # if set, overrides the fields above

    # ── Auth ──
    JWT_SECRET_KEY: str = "insecure-dev-secret-change-me"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 480

    DEFAULT_ADMIN_USERNAME: str = "aditya"
    DEFAULT_ADMIN_PASSWORD: str = "123"
    DEFAULT_ENGINEER_USERNAME: str = "Engineer"
    DEFAULT_ENGINEER_PASSWORD: str = "123"

    # ── CORS ──
    # CORS_ORIGINS: str = "http://localhost:8080"
    CORS_ORIGINS: str = "http://localhost:5173,http://127.0.0.1:5173"

    # ── DAQ ──
    REAL_DAQ_MODE: bool = False
    DAQ_SCPI_PORT: int = 5025
    DAQ_CONNECT_TIMEOUT_S: int = 3

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def sqlalchemy_database_url(self) -> str:
        if self.DATABASE_URL:
            return self.DATABASE_URL
        return (
            f"postgresql+psycopg2://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
