import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from app.config import get_settings
from app.database import engine, Base, SessionLocal, SCHEMA
from app.models import User, UserRole
from app.security import hash_password
from app.routers import auth, configs, daq, devices
from app.services import monitoring_service

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("main")

settings = get_settings()

app = FastAPI(
    title="Voltage Monitoring System API",
    description="Voltage Monitoring for DAQ6510 & GWInstek9600.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(configs.router)
app.include_router(daq.router)
app.include_router(devices.router)

def _ensure_schema_and_tables():
    with engine.connect() as conn:
        conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{SCHEMA}"'))
        conn.commit()
    Base.metadata.create_all(bind=engine)


def _seed_default_users():
    db = SessionLocal()
    try:
        if db.query(User).count() > 0:
            return
        db.add(User(
            username=settings.DEFAULT_ADMIN_USERNAME,
            full_name="Administrator",
            hashed_password=hash_password(settings.DEFAULT_ADMIN_PASSWORD),
            role=UserRole.administrator,
        ))
        db.add(User(
            username=settings.DEFAULT_ENGINEER_USERNAME,
            full_name="Engineer",
            hashed_password=hash_password(settings.DEFAULT_ENGINEER_PASSWORD),
            role=UserRole.engineer,
        ))
        db.commit()
        logger.info("Seeded default users: %s (administrator), %s (engineer)",
                    settings.DEFAULT_ADMIN_USERNAME, settings.DEFAULT_ENGINEER_USERNAME)
    finally:
        db.close()


@app.on_event("startup")
async def on_startup():
    _ensure_schema_and_tables()
    _seed_default_users()
    await monitoring_service.resume_all_active_configs()


@app.on_event("shutdown")
async def on_shutdown():
    await monitoring_service.stop_all()


@app.get("/api/health", tags=["health"])
def health():
    return {"status": "ok"}
