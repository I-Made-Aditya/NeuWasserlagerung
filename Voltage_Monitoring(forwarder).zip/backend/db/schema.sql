-- =============================================================================
-- Voltage Monitoring System — PostgreSQL schema
-- Semua object dibuat di dalam schema "monitoringdaq" (BUKAN "public"),
-- sesuai batasan IT yang hanya mengizinkan pembuatan schema baru.
--
-- Cara pakai:
--   psql "postgresql://<user>:<password>@<host>:5432/<db>" -f db/schema.sql
--
-- Catatan: jika Anda menjalankan backend FastAPI langsung (uvicorn), schema
-- dan tabel-tabel di bawah ini akan otomatis dibuat juga saat startup
-- (lihat app/main.py -> _ensure_schema_and_tables). Script ini disediakan
-- untuk kasus di mana Anda ingin/harus menyiapkan database secara manual
-- terlebih dahulu (mis. akun aplikasi tidak punya hak CREATE SCHEMA).
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS monitoringdaq;

-- ── ENUM types ────────────────────────────────────────────────────────────
DO $$ BEGIN
    CREATE TYPE monitoringdaq.user_role AS ENUM ('administrator', 'engineer');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE monitoringdaq.equipment_type AS ENUM ('DAQ6510', 'DAQ9600');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE monitoringdaq.wire_mode AS ENUM ('2-wire', '4-wire');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
    CREATE TYPE monitoringdaq.alarm_status AS ENUM ('open', 'released');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ── devices ──────────────────────────────────────────────────────────────
-- Master data instrumen DAQ (dropdown IP/serial/kalibrasi di frontend)
CREATE TABLE IF NOT EXISTS monitoringdaq.devices (
    id                   SERIAL PRIMARY KEY,
    equipment_type       monitoringdaq.equipment_type NOT NULL,
    serial_number        VARCHAR(100) NOT NULL UNIQUE,
    calibration_number   VARCHAR(100) NOT NULL UNIQUE,
    ip_address           VARCHAR(64)  NOT NULL UNIQUE,
    is_active            BOOLEAN NOT NULL DEFAULT TRUE,
    created_at           TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ── users ────────────────────────────────────────────────────────────────
-- role = 'administrator' -> dapat CRUD configuration, start/stop DAQ, release alarm
-- role = 'engineer'      -> hanya boleh melihat (read-only) semua data
CREATE TABLE IF NOT EXISTS monitoringdaq.users (
    id               SERIAL PRIMARY KEY,
    username         VARCHAR(64)  NOT NULL UNIQUE,
    full_name        VARCHAR(128),
    hashed_password  VARCHAR(255) NOT NULL,
    role             monitoringdaq.user_role NOT NULL DEFAULT 'engineer',
    is_active        BOOLEAN NOT NULL DEFAULT TRUE,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ── configurations ───────────────────────────────────────────────────────
-- 1 baris = 1 baris "slot" konfigurasi seperti pada UI (ConfigRow / SettingsModal)
CREATE TABLE IF NOT EXISTS monitoringdaq.configurations (
    id               SERIAL PRIMARY KEY,
    active           BOOLEAN NOT NULL DEFAULT FALSE,

    project_name     VARCHAR(128) NOT NULL DEFAULT '',
    lom_nr           VARCHAR(128) NOT NULL DEFAULT '',
    description      VARCHAR(255) NOT NULL DEFAULT '',

    interval         INTEGER NOT NULL DEFAULT 1,      -- detik antar sampel
    duration         INTEGER NOT NULL DEFAULT 1000,   -- durasi rencana (jam, sesuai label UI)
    min_v            NUMERIC(10,4) NOT NULL DEFAULT 0,
    max_v            NUMERIC(10,4) NOT NULL DEFAULT 10,
    min_r            NUMERIC(10,4) NOT NULL DEFAULT 0,
    max_r            NUMERIC(10,4) NOT NULL DEFAULT 10000,
    fixed_resistor   NUMERIC(10,4) NOT NULL DEFAULT 1000,   -- Ohm, dipakai untuk konversi V->R pada 2-Wire
    supply_voltage   NUMERIC(10,4) NOT NULL DEFAULT 5,      -- Volt, dipakai untuk konversi V->R pada 2-Wire

    machine          VARCHAR(128) NOT NULL DEFAULT 'Machine-1',
    expected_finish  VARCHAR(32)  NOT NULL DEFAULT '—',

    ip_address       VARCHAR(64)  NOT NULL DEFAULT '192.168.1.100',
    netmask          VARCHAR(64)  NOT NULL DEFAULT '255.255.255.0',
    equipment_type   monitoringdaq.equipment_type NOT NULL DEFAULT 'DAQ9600',
    wire_mode        monitoringdaq.wire_mode NOT NULL DEFAULT '4-wire',

    channels         JSONB NOT NULL DEFAULT '[]',     -- array of 80 booleans

    created_by       INTEGER REFERENCES monitoringdaq.users(id),
    created_at       TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

-- ── measurement_data ─────────────────────────────────────────────────────
-- 1 baris = 1 sampel waktu, berisi array 80 nilai channel (Volt)
CREATE TABLE IF NOT EXISTS monitoringdaq.measurement_data (
    id          BIGSERIAL PRIMARY KEY,
    config_id   INTEGER NOT NULL REFERENCES monitoringdaq.configurations(id) ON DELETE CASCADE,
    "timestamp" TIMESTAMP NOT NULL DEFAULT NOW(),
    values      JSONB NOT NULL   -- array of 80 floats
);

CREATE INDEX IF NOT EXISTS idx_measurement_data_config_ts
    ON monitoringdaq.measurement_data (config_id, "timestamp");

-- ── alarm_events ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS monitoringdaq.alarm_events (
    id            SERIAL PRIMARY KEY,
    config_id     INTEGER NOT NULL REFERENCES monitoringdaq.configurations(id) ON DELETE CASCADE,
    channel_no    INTEGER NOT NULL,
    value         NUMERIC(10,4),
    status        monitoringdaq.alarm_status NOT NULL DEFAULT 'open',
    remark        TEXT,
    created_at    TIMESTAMP NOT NULL DEFAULT NOW(),
    released_by   INTEGER REFERENCES monitoringdaq.users(id),
    released_at   TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_alarm_events_config_status
    ON monitoringdaq.alarm_events (config_id, status);

-- ── (opsional) grant ke role aplikasi tertentu ───────────────────────────
-- Uncomment & sesuaikan nama role bila akun aplikasi berbeda dengan pemilik schema:
-- GRANT USAGE ON SCHEMA monitoringdaq TO voltage_app;
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA monitoringdaq TO voltage_app;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA monitoringdaq TO voltage_app;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA monitoringdaq GRANT ALL ON TABLES TO voltage_app;
-- ALTER DEFAULT PRIVILEGES IN SCHEMA monitoringdaq GRANT ALL ON SEQUENCES TO voltage_app;
