# Voltage Monitoring System — Backend (FastAPI)

Backend untuk aplikasi DAQ voltage logging (Keithley **DAQ6510** & GWInstek **DAQ9600**),
mendukung pengukuran **2-Wire** dan **4-Wire**, autentikasi berbasis role
(**administrator** vs **engineer**), dan menyimpan seluruh data ke PostgreSQL
pada schema khusus `monitoringdaq`.

## 1. Persiapan Database

### Opsi A — otomatis (paling mudah)
Cukup pastikan `.env` sudah berisi kredensial database yang benar
(lihat `.env.example`), lalu jalankan backend (lihat langkah 3).
Saat start-up, backend akan:
1. `CREATE SCHEMA IF NOT EXISTS monitoringdaq`
2. Membuat seluruh tabel (users, configurations, measurement_data, alarm_events)
3. Membuat 2 user default: `admin` (administrator) & `engineer` (engineer)

Ini mengasumsikan akun database Anda punya hak `CREATE SCHEMA` pada database tsb.

### Opsi B — manual via script SQL
Jika akun aplikasi Anda **tidak** boleh membuat schema sendiri (hanya IT yang
membuatkan schema `monitoringdaq` untuk Anda), jalankan langsung:

```bash
psql "postgresql://<user>:<password>@<host>:5432/<db_name>" -f db/schema.sql
```

Lalu buat user default (admin/engineer) dengan:

```bash
python -m scripts.seed_users
```

## 2. Konfigurasi

```bash
cp .env.example .env
# edit .env: kredensial DB, JWT secret, default users, CORS origin frontend, dsb.
```

## 3. Menjalankan (tanpa Docker)

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Dokumentasi interaktif (Swagger UI): **http://localhost:8000/docs**
ReDoc: **http://localhost:8000/redoc**

## 4. Menjalankan dengan Docker Compose

Dari root project (folder yang berisi `docker-compose.yml`):

```bash
docker compose up --build
```

Ini akan menjalankan PostgreSQL + backend FastAPI sekaligus.

## 5. Login default

| Username   | Password         | Role          | Akses                                   |
|------------|------------------|---------------|-------------------------------------------|
| `admin`    | `Admin#12345`    | administrator | Full CRUD, ubah setting DAQ, start/stop, release alarm |
| `engineer` | `Engineer#12345` | engineer      | Read-only — bisa lihat semua data, tidak bisa mengubah konfigurasi |

**Ganti password default ini sebelum production!** (via endpoint yang bisa Anda
tambahkan, atau langsung update kolom `hashed_password` menggunakan
`app.security.hash_password`).

## 6. Struktur endpoint utama

```
POST   /api/auth/login                                  Login -> JWT token
GET    /api/auth/me                                      Info user yang sedang login

GET    /api/configs                                       List semua konfigurasi (semua role)
POST   /api/configs                                        Buat konfigurasi baru (admin only)
GET    /api/configs/{id}                                   Detail 1 konfigurasi
PUT    /api/configs/{id}                                    Update / save Settings (admin only)
                                                            -> otomatis start/stop monitoring loop
                                                               saat field `active` berubah
DELETE /api/configs/{id}                                    Hapus konfigurasi (admin only)

GET    /api/configs/{id}/data                               Ambil histori data (untuk tabel Data / Graph)
GET    /api/configs/{id}/alarms                             List alarm (open/released)
POST   /api/configs/{id}/alarms/{alarm_id}/release          Release alarm (admin only)

POST   /api/{equipment_type}/{ip_address}/{wire_mode}       Trigger 1x pembacaan manual, contoh:
                                                              POST /api/DAQ6510/192.168.1.101/4-wire
                                                              POST /api/DAQ9600/192.168.1.102/2-wire
                                                              (admin only)
```

## 7. Integrasi hardware nyata

Secara default `REAL_DAQ_MODE=false` di `.env` → backend memakai **simulator**
(`app/daq_drivers/simulator.py`) sehingga seluruh alur (alarm, DB, UI) bisa
dites tanpa alat fisik.

Untuk hardware asli:
1. Set `REAL_DAQ_MODE=true` di `.env`.
2. Sesuaikan perintah SCPI di:
   - `app/daq_drivers/keithley_daq6510.py`
   - `app/daq_drivers/gwinstek_daq9600.py`

   dengan manual programming instrumen Anda (nomor slot/channel, `FUNC`,
   `ROUT:SCAN`, format respons `FETC?`/`TRAC:DATA?`, dll — ini SANGAT
   tergantung kartu multiplexer & firmware yang terpasang).
3. Pastikan port SCPI-over-LAN (default 5025) bisa diakses dari server backend.

Jika koneksi ke instrumen gagal (network down, IP salah, dll), driver akan
otomatis fallback ke simulator supaya sistem monitoring tidak crash — cek log
backend untuk peringatan koneksi.

## 8. Struktur folder

```
backend/
├── app/
│   ├── main.py                 # FastAPI app, startup (schema+seed), CORS
│   ├── config.py                # Settings (.env)
│   ├── database.py              # SQLAlchemy engine/session (schema monitoringdaq)
│   ├── models.py                 # ORM models
│   ├── schemas.py                 # Pydantic request/response models
│   ├── security.py                 # bcrypt + JWT
│   ├── deps.py                      # auth dependencies (get_current_user, require_administrator)
│   ├── routers/
│   │   ├── auth.py                    # /api/auth/*
│   │   ├── configs.py                  # /api/configs/*
│   │   └── daq.py                       # /api/{equipment}/{ip}/{wire_mode}
│   ├── daq_drivers/
│   │   ├── base.py                       # abstract driver + fail-soft to simulator
│   │   ├── keithley_daq6510.py            # SCPI driver template - Keithley
│   │   ├── gwinstek_daq9600.py             # SCPI driver template - GWInstek
│   │   ├── simulator.py                     # demo-mode signal generator
│   │   └── factory.py                        # equipment_type -> driver instance
│   └── services/
│       └── monitoring_service.py              # background per-config logging loop
├── db/
│   └── schema.sql               # manual SQL setup (schema monitoringdaq)
├── scripts/
│   └── seed_users.py            # standalone user seeding
├── requirements.txt
├── .env.example
└── Dockerfile
```
