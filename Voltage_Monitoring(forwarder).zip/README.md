# Voltage Monitoring System — Full Stack (3-Tier)

Sistem monitoring & logging tegangan DC untuk instrumen **Keithley DAQ6510**
dan **GWInstek DAQ9600** (mode **2-Wire** / **4-Wire**), dengan konversi
resistansi, export CSV/Excel, dan role-based access (administrator vs
engineer).

```
Voltage_Monitoring/
├── frontend/          Vue 3 app — hanya bicara ke Gateway
├── backend/           FastAPI + PostgreSQL + DAQ drivers — jalan di Transfer Server
└── gateway/           Reverse-proxy transparan — jalan di Prod Server
```

## Arsitektur jaringan

```
Office Users
   │  http://<prod-server>:8080/api/...
   ▼
Frontend (Vue.js)
   ▼
Prod Server   ── gateway/ ──────────────┐
   │  (172.26.x.x)                      │  http://<transfer-server>:8000/api/...
   ▼                                    ▼
Transfer Server ── backend/ (FastAPI) ──► PostgreSQL + DAQ devices
   (172.28.10.x)                           (172.28.x.x)
```

**Gateway tidak berisi business logic apa pun** — ia hanya meneruskan
setiap request dari Frontend ke Backend apa adanya (method, header, JWT,
query string, body, dan response termasuk file CSV/Excel), sehingga
seluruh logika DAQ, database, export, dan konversi resistansi tetap
100% berada di `backend/`. Detail lengkap ada di `gateway/README.md`.

## Quick start

### 1. Backend + Database (Transfer Server)

```bash
cd Voltage_Monitoring
cp backend/.env.example backend/.env
docker compose up --build
```

Lihat `backend/README.md` untuk detail (login default, struktur endpoint,
cara mengganti driver DAQ ke hardware asli, dll).

### 2. Gateway (Prod Server)

```bash
cd gateway
cp .env.example .env
# edit .env: set TRANSFER_BACKEND_URL ke alamat Transfer Server di atas
docker compose up --build -d
```

Windows tanpa Docker: jalankan `gateway\start.bat`.
Linux tanpa Docker: jalankan `./gateway/start.sh`.

Lihat `gateway/README.md` untuk troubleshooting, reverse-proxy/HTTPS,
dan referensi environment variable lengkap.

### 3. Frontend

```bash
cd frontend
npm install
```

Set base URL API di `.env` agar menunjuk ke **Gateway** (bukan langsung ke
backend lagi):

```env
VITE_API_BASE_URL=http://<prod-server>:8080/api
```

```bash
npm run dev      # atau: npm run serve, tergantung tooling yang dipakai
```

## Ringkasan komponen

| Folder | Berjalan di | Tanggung jawab |
|---|---|---|
| `frontend/` | Browser office | UI Vue 3, login, dashboard konfigurasi, grafik, export |
| `gateway/` | Prod Server | Reverse-proxy transparan, satu-satunya yang boleh diakses Office |
| `backend/` | Transfer Server | Auth JWT, PostgreSQL, DAQ drivers, monitoring loop, export, konversi resistansi |

Detail masing-masing ada di README di dalam folder tersebut:
`backend/README.md` dan `gateway/README.md`.
