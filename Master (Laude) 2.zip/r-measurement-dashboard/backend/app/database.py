from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from .config import settings

# All raw SQL in this project explicitly qualifies table names with this
# schema (e.g. "monitoringmeasurement.measurements") instead of relying on
# search_path, because the target Postgres instance does not grant write
# access on the "public" schema.
SCHEMA = settings.DB_SCHEMA

engine = create_engine(settings.DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
