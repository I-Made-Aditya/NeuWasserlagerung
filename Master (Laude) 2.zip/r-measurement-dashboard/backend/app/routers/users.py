from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..auth import hash_password
from ..database import SCHEMA, get_db
from ..deps import get_current_user, require_role
from ..schemas import UserCreate, UserPatch

router = APIRouter(prefix="/api/users", tags=["users"])


@router.get("")
def list_users(
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    rows = db.execute(
        text(f"""
            SELECT u.id, u.username, u.role, u.active, u.operator_id,
                   o.name AS operator_name, u.created_at
            FROM {SCHEMA}.users u
            LEFT JOIN {SCHEMA}.operators o ON o.id = u.operator_id
            ORDER BY u.created_at DESC
        """)
    ).mappings().all()
    return list(rows)


@router.post("", status_code=201)
def create_user(
    payload: UserCreate,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    if payload.role not in ("engineer", "operator"):
        raise HTTPException(status_code=400, detail="role must be 'engineer' or 'operator'")
    if payload.role == "operator" and not payload.operator_id:
        raise HTTPException(status_code=400, detail="operator_id is required when role is operator")

    try:
        row = db.execute(
            text(f"""
                INSERT INTO {SCHEMA}.users (username, password_hash, role, operator_id, created_by)
                VALUES (:username, :password_hash, :role, :operator_id, :created_by)
                RETURNING id, username, role, operator_id, active, created_at
            """),
            {
                "username": payload.username,
                "password_hash": hash_password(payload.password),
                "role": payload.role,
                "operator_id": payload.operator_id if payload.role == "operator" else None,
                "created_by": user["id"],
            },
        ).mappings().first()
        db.commit()
        return row
    except IntegrityError as err:
        db.rollback()
        if "unique" in str(err.orig).lower():
            raise HTTPException(status_code=409, detail="Username already exists")
        raise HTTPException(status_code=500, detail="Failed to create user")


@router.patch("/{user_id}")
def patch_user(
    user_id: int,
    payload: UserPatch,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    sets = []
    params = {"id": user_id}

    if payload.active is not None:
        sets.append("active = :active")
        params["active"] = payload.active
    if payload.role:
        sets.append("role = :role")
        params["role"] = payload.role
    if payload.operator_id is not None:
        sets.append("operator_id = :operator_id")
        params["operator_id"] = payload.operator_id
    if payload.password:
        sets.append("password_hash = :password_hash")
        params["password_hash"] = hash_password(payload.password)

    if not sets:
        raise HTTPException(status_code=400, detail="Nothing to update")

    row = db.execute(
        text(f"""
            UPDATE {SCHEMA}.users SET {', '.join(sets)}
            WHERE id = :id
            RETURNING id, username, role, operator_id, active
        """),
        params,
    ).mappings().first()

    if not row:
        db.rollback()
        raise HTTPException(status_code=404, detail="Not found")

    db.commit()
    return row
