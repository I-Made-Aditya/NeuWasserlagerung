from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import bindparam, text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from ..database import SCHEMA, get_db
from ..deps import get_current_user, require_role
from ..schemas import (
    BulkUpdate,
    DuplicateRequest,
    MeasurementCreate,
    MeasurementUpdate,
    PriorityUpdate,
    StatusUpdate,
)

router = APIRouter(prefix="/api/measurements", tags=["measurements"])

STATUSES = ["Measurement Yet", "Ongoing", "Finished Measurement"]
TEMP_FIELDS = ["t1_temp", "t2_temp", "t3_temp", "t4_temp", "t5_temp", "t6_temp", "t7_temp"]


def _is_unique_violation(err: IntegrityError) -> bool:
    return getattr(getattr(err, "orig", None), "pgcode", None) == "23505"


# ---------------------------------------------------------------
# GET /api/measurements
# Primary mode: ?year=2026&month=8 -> ALL rows in that month
# (List Measurement page loads one month at a time, can be 200-500 rows)
# Filters: status, operator_id, search
# ---------------------------------------------------------------
@router.get("")
def list_measurements(
    year: Optional[int] = None,
    month: Optional[int] = None,
    status: Optional[str] = None,
    operator_id: Optional[int] = None,
    search: Optional[str] = None,
    page: int = 1,
    limit: int = 1000,
    db: Session = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    conditions = []
    params = {}

    if year and month:
        conditions.append("EXTRACT(YEAR FROM m.date_in) = :year")
        conditions.append("EXTRACT(MONTH FROM m.date_in) = :month")
        params["year"] = year
        params["month"] = month
    if status:
        conditions.append("m.status = :status")
        params["status"] = status
    if operator_id:
        conditions.append("m.operator_id = :operator_id")
        params["operator_id"] = operator_id
    if search:
        conditions.append(
            "(m.project_nr ILIKE :search OR m.lom_nr ILIKE :search "
            "OR m.part_description ILIKE :search OR m.remark ILIKE :search)"
        )
        params["search"] = f"%{search}%"

    where = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    total = db.execute(
        text(f"SELECT COUNT(*) FROM {SCHEMA}.measurements m {where}"), params
    ).scalar()

    offset = (page - 1) * limit
    rows = db.execute(
        text(f"""
            SELECT m.*, o.name AS operator_name
            FROM {SCHEMA}.measurements m
            LEFT JOIN {SCHEMA}.operators o ON o.id = m.operator_id
            {where}
            ORDER BY m.date_in ASC, m.id ASC
            LIMIT :limit OFFSET :offset
        """),
        {**params, "limit": limit, "offset": offset},
    ).mappings().all()

    date_range = db.execute(
        text(f"SELECT MIN(date_in) AS min_date, MAX(date_in) AS max_date FROM {SCHEMA}.measurements")
    ).mappings().first()

    return {"data": list(rows), "total": total, "range": dict(date_range) if date_range else None}


@router.get("/{measurement_id}")
def get_measurement(
    measurement_id: int,
    db: Session = Depends(get_db),
    user: dict = Depends(get_current_user),
):
    row = db.execute(
        text(f"""
            SELECT m.*, o.name AS operator_name FROM {SCHEMA}.measurements m
            LEFT JOIN {SCHEMA}.operators o ON o.id = m.operator_id WHERE m.id = :id
        """),
        {"id": measurement_id},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="Not found")
    return row


def _build_write_params(b, user_id: int) -> dict:
    params = {
        "date_in": b.date_in, "project_nr": b.project_nr, "lom_nr": b.lom_nr,
        "part_description": b.part_description, "type": b.type, "qty": b.qty or 0,
        "test_stage": b.test_stage, "reliability": b.reliability,
        "status": b.status if b.status in STATUSES else "Measurement Yet",
        "planning_start": b.planning_start, "planning_end": b.planning_end,
        "actual_start": b.actual_start, "actual_end": b.actual_end,
        "operator_id": b.operator_id, "remark": b.remark, "priority": b.priority,
        "user_id": user_id,
    }
    for f in TEMP_FIELDS:
        val = getattr(b, f)
        params[f] = val.strip() if val else None
    return params


# ---------------------------------------------------------------
# POST /api/measurements (Engineer only)
# ---------------------------------------------------------------
@router.post("", status_code=201)
def create_measurement(
    payload: MeasurementCreate,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    params = _build_write_params(payload, user["id"])
    try:
        row = db.execute(
            text(f"""
                INSERT INTO {SCHEMA}.measurements
                    (date_in, project_nr, lom_nr, part_description, type, qty, test_stage,
                     reliability, status, planning_start, planning_end, actual_start, actual_end,
                     t1_temp, t2_temp, t3_temp, t4_temp, t5_temp, t6_temp, t7_temp,
                     operator_id, remark, priority, created_by, updated_by)
                VALUES
                    (:date_in, :project_nr, :lom_nr, :part_description, :type, :qty, :test_stage,
                     :reliability, :status, :planning_start, :planning_end, :actual_start, :actual_end,
                     :t1_temp, :t2_temp, :t3_temp, :t4_temp, :t5_temp, :t6_temp, :t7_temp,
                     :operator_id, :remark, :priority, :user_id, :user_id)
                RETURNING *
            """),
            params,
        ).mappings().first()
        db.commit()
        return row
    except IntegrityError as err:
        db.rollback()
        if _is_unique_violation(err):
            raise HTTPException(status_code=409, detail="Priority number already used")
        raise HTTPException(status_code=500, detail="Failed to create measurement")


# ---------------------------------------------------------------
# PUT /api/measurements/{id} (Engineer only - full update)
# ---------------------------------------------------------------
@router.put("/{measurement_id}")
def update_measurement(
    measurement_id: int,
    payload: MeasurementUpdate,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    params = _build_write_params(payload, user["id"])
    params["id"] = measurement_id
    try:
        row = db.execute(
            text(f"""
                UPDATE {SCHEMA}.measurements SET
                    date_in=:date_in, project_nr=:project_nr, lom_nr=:lom_nr,
                    part_description=:part_description, type=:type, qty=:qty,
                    test_stage=:test_stage, reliability=:reliability, status=:status,
                    planning_start=:planning_start, planning_end=:planning_end,
                    actual_start=:actual_start, actual_end=:actual_end,
                    t1_temp=:t1_temp, t2_temp=:t2_temp, t3_temp=:t3_temp, t4_temp=:t4_temp,
                    t5_temp=:t5_temp, t6_temp=:t6_temp, t7_temp=:t7_temp,
                    operator_id=:operator_id, remark=:remark, priority=:priority,
                    updated_by=:user_id
                WHERE id=:id RETURNING *
            """),
            params,
        ).mappings().first()
        if not row:
            db.rollback()
            raise HTTPException(status_code=404, detail="Not found")
        db.commit()
        return row
    except IntegrityError as err:
        db.rollback()
        if _is_unique_violation(err):
            raise HTTPException(status_code=409, detail="Priority number already used")
        raise HTTPException(status_code=500, detail="Failed to update measurement")


# ---------------------------------------------------------------
# PATCH /api/measurements/{id}/status
# Operator role: may only change status + operator_id + actual dates
# (so they can log when they actually started/finished the work).
# ---------------------------------------------------------------
@router.patch("/{measurement_id}/status")
def update_status(
    measurement_id: int,
    payload: StatusUpdate,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer", "operator")),
):
    if payload.status and payload.status not in STATUSES:
        raise HTTPException(status_code=400, detail=f"status must be one of: {', '.join(STATUSES)}")

    row = db.execute(
        text(f"""
            UPDATE {SCHEMA}.measurements SET
                status = COALESCE(:status, status),
                operator_id = COALESCE(:operator_id, operator_id),
                actual_start = COALESCE(:actual_start, actual_start),
                actual_end = COALESCE(:actual_end, actual_end),
                updated_by = :user_id
            WHERE id = :id RETURNING *
        """),
        {
            "status": payload.status, "operator_id": payload.operator_id,
            "actual_start": payload.actual_start, "actual_end": payload.actual_end,
            "user_id": user["id"], "id": measurement_id,
        },
    ).mappings().first()

    if not row:
        db.rollback()
        raise HTTPException(status_code=404, detail="Not found")
    db.commit()
    return row


# ---------------------------------------------------------------
# PATCH /api/measurements/{id}/priority (Engineer only)
# ---------------------------------------------------------------
@router.patch("/{measurement_id}/priority")
def update_priority(
    measurement_id: int,
    payload: PriorityUpdate,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    try:
        row = db.execute(
            text(f"""
                UPDATE {SCHEMA}.measurements SET priority = :priority, updated_by = :user_id
                WHERE id = :id RETURNING *
            """),
            {"priority": payload.priority, "user_id": user["id"], "id": measurement_id},
        ).mappings().first()
        if not row:
            db.rollback()
            raise HTTPException(status_code=404, detail="Not found")
        db.commit()
        return row
    except IntegrityError as err:
        db.rollback()
        if _is_unique_violation(err):
            raise HTTPException(status_code=409, detail="Priority number already used, choose another (1-10)")
        raise HTTPException(status_code=500, detail="Failed to update priority")


# ---------------------------------------------------------------
# PATCH /api/measurements/bulk
# Applies the same partial set of field values to many selected rows
# (the "Mode Edit -> select rows -> Edit" action in List Measurement).
#   - engineer: may set any field in ENGINEER_BULK_FIELDS
#   - operator: may only set status / operator_id / actual_start / actual_end
# Priority is intentionally not bulk-editable (it is unique per row).
# ---------------------------------------------------------------
OPERATOR_BULK_FIELDS = {"status", "operator_id", "actual_start", "actual_end"}
ENGINEER_BULK_FIELDS = OPERATOR_BULK_FIELDS | {
    "reliability", "test_stage", "remark", "planning_start", "planning_end",
}


@router.patch("/bulk")
def bulk_update(
    payload: BulkUpdate,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer", "operator")),
):
    if not payload.ids:
        raise HTTPException(status_code=400, detail="ids must not be empty")
    if payload.status and payload.status not in STATUSES:
        raise HTTPException(status_code=400, detail=f"status must be one of: {', '.join(STATUSES)}")

    allowed = ENGINEER_BULK_FIELDS if user["role"] == "engineer" else OPERATOR_BULK_FIELDS
    data = payload.model_dump(exclude={"ids"}, exclude_none=True)

    disallowed = set(data.keys()) - allowed
    if disallowed:
        raise HTTPException(
            status_code=403,
            detail=f"Your role cannot bulk-edit: {', '.join(sorted(disallowed))}",
        )
    if not data:
        raise HTTPException(status_code=400, detail="No fields to update")

    # Column names come from the fixed whitelist above (never from user input),
    # values are bound parameters.
    set_clause = ", ".join(f"{field} = :{field}" for field in data)
    stmt = text(f"""
        UPDATE {SCHEMA}.measurements
        SET {set_clause}, updated_by = :user_id
        WHERE id IN :ids
        RETURNING *
    """).bindparams(bindparam("ids", expanding=True))

    rows = db.execute(stmt, {**data, "user_id": user["id"], "ids": payload.ids}).mappings().all()
    db.commit()
    return {"updated": len(rows), "data": list(rows)}


# ---------------------------------------------------------------
# POST /api/measurements/duplicate (Engineer only)
# Creates a copy of each selected row: same field values, status reset to
# "Measurement Yet", actual dates cleared, priority not copied (unique).
# ---------------------------------------------------------------
@router.post("/duplicate", status_code=201)
def duplicate_measurements(
    payload: DuplicateRequest,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    if not payload.ids:
        raise HTTPException(status_code=400, detail="ids must not be empty")

    created = []
    for source_id in payload.ids:
        row = db.execute(
            text(f"""
                INSERT INTO {SCHEMA}.measurements
                    (date_in, project_nr, lom_nr, part_description, type, qty, test_stage,
                     reliability, status, planning_start, planning_end, actual_start, actual_end,
                     t1_temp, t2_temp, t3_temp, t4_temp, t5_temp, t6_temp, t7_temp,
                     operator_id, remark, created_by, updated_by)
                SELECT
                    date_in, project_nr, lom_nr, part_description, type, qty, test_stage,
                    reliability, 'Measurement Yet', planning_start, planning_end, NULL, NULL,
                    t1_temp, t2_temp, t3_temp, t4_temp, t5_temp, t6_temp, t7_temp,
                    operator_id, remark, :user_id, :user_id
                FROM {SCHEMA}.measurements WHERE id = :source_id
                RETURNING *
            """),
            {"source_id": source_id, "user_id": user["id"]},
        ).mappings().first()
        if row:
            created.append(row)

    db.commit()
    return {"created": len(created), "data": created}


# ---------------------------------------------------------------
# DELETE /api/measurements/{id} (Engineer only)
# ---------------------------------------------------------------
@router.delete("/{measurement_id}", status_code=204)
def delete_measurement(
    measurement_id: int,
    db: Session = Depends(get_db),
    user: dict = Depends(require_role("engineer")),
):
    result = db.execute(
        text(f"DELETE FROM {SCHEMA}.measurements WHERE id = :id"), {"id": measurement_id}
    )
    if result.rowcount == 0:
        db.rollback()
        raise HTTPException(status_code=404, detail="Not found")
    db.commit()
    return None
