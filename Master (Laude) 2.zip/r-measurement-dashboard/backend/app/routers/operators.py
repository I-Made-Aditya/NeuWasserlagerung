from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..database import SCHEMA, get_db
from ..deps import get_current_user

router = APIRouter(prefix="/api/operators", tags=["operators"])


@router.get("")
def list_operators(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    rows = db.execute(
        text(f"SELECT id, name FROM {SCHEMA}.operators WHERE active = TRUE ORDER BY name")
    ).mappings().all()
    return list(rows)
