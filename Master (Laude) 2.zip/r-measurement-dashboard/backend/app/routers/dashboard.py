from typing import Optional

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..database import SCHEMA, get_db
from ..utils.period import PERIOD_TRUNC, current_period_range, validate_period

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])

STATUSES = ["Measurement Yet", "Ongoing", "Finished Measurement"]

# NOTE: the dashboard is publicly viewable (no login required) per requirement -
# only the "List Measurement" page and its write endpoints need auth.


@router.get("/summary")
def summary(period: Optional[str] = None, db: Session = Depends(get_db)):
    p = validate_period(period)
    start, end = current_period_range(p)

    row = db.execute(
        text(f"""
            SELECT
                COUNT(DISTINCT project_nr) AS project_count,
                COALESCE(SUM(temp_slot) FILTER (WHERE status = 'Measurement Yet'), 0) AS measurement_yet,
                COALESCE(SUM(temp_slot) FILTER (WHERE status = 'Ongoing'), 0) AS ongoing,
                COALESCE(SUM(temp_slot) FILTER (WHERE status = 'Finished Measurement'), 0) AS finished,
                COALESCE(SUM(temp_slot), 0) AS temp_slot_total
            FROM {SCHEMA}.measurements
            WHERE date_in >= :start AND date_in < :end
        """),
        {"start": start, "end": end},
    ).mappings().first()

    return {"period": p, "range": {"start": start, "end": end}, **row}


@router.get("/trend")
def trend(period: Optional[str] = None, buckets: int = 12, db: Session = Depends(get_db)):
    p = validate_period(period)
    trunc = PERIOD_TRUNC[p]
    buckets = min(buckets, 52)

    rows = db.execute(
        text(f"""
            SELECT date_trunc(:trunc, date_in) AS bucket,
                   COALESCE(SUM(temp_slot), 0) AS temp_slot_total,
                   COALESCE(SUM(qty), 0) AS qty_total
            FROM {SCHEMA}.measurements
            WHERE date_in >= (CURRENT_DATE - (:buckets || ' ' || :trunc || 's')::interval)
            GROUP BY bucket
            ORDER BY bucket
        """),
        {"trunc": trunc, "buckets": buckets},
    ).mappings().all()

    return {"period": p, "series": list(rows)}


@router.get("/workload-temperature")
def workload_temperature(status: Optional[str] = None, db: Session = Depends(get_db)):
    status = status if status in STATUSES else "Measurement Yet"

    union_parts = []
    for i in range(1, 8):
        union_parts.append(
            f"SELECT project_nr, qty, t{i}_temp AS temp FROM {SCHEMA}.measurements "
            f"WHERE status = :status AND t{i}_temp IS NOT NULL AND t{i}_temp <> ''"
        )
    query = " UNION ALL ".join(union_parts)

    rows = db.execute(text(query), {"status": status}).mappings().all()

    temp_map: dict = {}
    project_totals: dict = {}
    for r in rows:
        t = r["temp"]
        qty = float(r["qty"] or 0)
        temp_map.setdefault(t, {})
        temp_map[t][r["project_nr"]] = temp_map[t].get(r["project_nr"], 0) + qty
        project_totals[r["project_nr"]] = project_totals.get(r["project_nr"], 0) + qty

    def temp_sort_key(t):
        try:
            return float("".join(ch for ch in t if ch.isdigit() or ch in "-."))
        except ValueError:
            return 0

    temperatures = sorted(temp_map.keys(), key=temp_sort_key)

    top_n = 12
    top_projects = [p for p, _ in sorted(project_totals.items(), key=lambda x: -x[1])[:top_n]]

    series = []
    for proj in top_projects:
        series.append({"project": proj, "values": [temp_map[t].get(proj, 0) for t in temperatures]})

    others_values = []
    for t in temperatures:
        total = sum(v for p, v in temp_map[t].items() if p not in top_projects)
        others_values.append(total)
    if any(v > 0 for v in others_values):
        series.append({"project": "Others", "values": others_values})

    return {"status": status, "temperatures": temperatures, "series": series}


@router.get("/top-project-load")
def top_project_load(period: Optional[str] = None, limit: int = 10, db: Session = Depends(get_db)):
    p = validate_period(period)
    start, end = current_period_range(p)
    limit = min(limit, 50)

    rows = db.execute(
        text(f"""
            SELECT project_nr, SUM(qty) AS qty, SUM(temp_slot) AS temp_slot
            FROM {SCHEMA}.measurements
            WHERE date_in >= :start AND date_in < :end
            GROUP BY project_nr
            ORDER BY qty DESC
            LIMIT :limit
        """),
        {"start": start, "end": end, "limit": limit},
    ).mappings().all()

    return {"period": p, "data": list(rows)}


@router.get("/backlog-aging-trend")
def backlog_aging_trend(weeks: int = 12, db: Session = Depends(get_db)):
    weeks = min(weeks, 52)
    rows = db.execute(
        text(f"""
            SELECT date_trunc('week', date_in) AS week_start,
                   COALESCE(SUM(qty), 0) AS qty,
                   COUNT(*) AS lines
            FROM {SCHEMA}.measurements
            WHERE status IN ('Measurement Yet', 'Ongoing')
              AND date_in >= (CURRENT_DATE - (:weeks || ' weeks')::interval)
            GROUP BY week_start
            ORDER BY week_start
        """),
        {"weeks": weeks},
    ).mappings().all()
    return {"data": list(rows)}


@router.get("/operator-load-trend")
def operator_load_trend(weeks: int = 12, db: Session = Depends(get_db)):
    weeks = min(weeks, 52)
    rows = db.execute(
        text(f"""
            SELECT o.name AS operator_name,
                   date_trunc('week', m.date_in) AS week_start,
                   COALESCE(SUM(m.temp_slot), 0) AS temp_slot
            FROM {SCHEMA}.operators o
            LEFT JOIN {SCHEMA}.measurements m
                ON m.operator_id = o.id
                AND m.status != 'Finished Measurement'
                AND m.date_in >= (CURRENT_DATE - (:weeks || ' weeks')::interval)
            WHERE o.active = TRUE
            GROUP BY o.name, week_start
            ORDER BY week_start
        """),
        {"weeks": weeks},
    ).mappings().all()
    return {"data": list(rows)}


@router.get("/top-priority")
def top_priority(db: Session = Depends(get_db)):
    rows = db.execute(
        text(f"""
            SELECT priority AS nr, project_nr, part_description AS desc, remark
            FROM {SCHEMA}.measurements
            WHERE priority IS NOT NULL
            ORDER BY priority ASC
            LIMIT 10
        """)
    ).mappings().all()
    return {"data": list(rows)}
