from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..auth import create_access_token, verify_password
from ..database import SCHEMA, get_db
from ..deps import get_current_user
from ..schemas import LoginRequest

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/login")
def login(payload: LoginRequest, db: Session = Depends(get_db)):
    row = db.execute(
        text(f"""
            SELECT u.id, u.username, u.password_hash, u.role, u.operator_id, u.active,
                   o.name AS operator_name
            FROM {SCHEMA}.users u
            LEFT JOIN {SCHEMA}.operators o ON o.id = u.operator_id
            WHERE u.username = :username
        """),
        {"username": payload.username},
    ).mappings().first()

    if not row:
        raise HTTPException(status_code=401, detail="Invalid username or password")
    if not row["active"]:
        raise HTTPException(status_code=403, detail="Account is inactive, contact your engineer/admin")
    if not verify_password(payload.password, row["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid username or password")

    token_payload = {
        "id": row["id"],
        "username": row["username"],
        "role": row["role"],
        "operatorId": row["operator_id"],
    }
    token = create_access_token(token_payload)

    return {
        "token": token,
        "user": {**token_payload, "operatorName": row["operator_name"]},
    }


@router.get("/me")
def me(user: dict = Depends(get_current_user)):
    return {"user": user}
