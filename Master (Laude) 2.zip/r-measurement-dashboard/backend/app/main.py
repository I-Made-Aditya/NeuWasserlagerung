from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .routers import auth, dashboard, measurements, operators, users

app = FastAPI(title="R-Measurement API", version="3.0.0")

origins = ["*"] if settings.CORS_ORIGIN == "*" else [settings.CORS_ORIGIN]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health():
    return {"ok": True}


app.include_router(auth.router)
app.include_router(operators.router)
app.include_router(measurements.router)
app.include_router(dashboard.router)
app.include_router(users.router)
