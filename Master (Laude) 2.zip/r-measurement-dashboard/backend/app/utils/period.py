from datetime import date, timedelta
from typing import Optional, Tuple

PERIOD_TRUNC = {
    "day": "day",
    "week": "week",
    "month": "month",
    "year": "year",
}


def validate_period(period: Optional[str]) -> str:
    p = (period or "week").lower()
    return p if p in PERIOD_TRUNC else "week"


def current_period_range(period: str, ref_date: Optional[date] = None) -> Tuple[str, str]:
    """Returns (start, end) ISO date strings covering the CURRENT period
    (e.g. current ISO week, current month) anchored on ref_date (default: today)."""
    p = validate_period(period)
    ref = ref_date or date.today()

    if p == "day":
        start = ref
    elif p == "week":
        start = ref - timedelta(days=ref.weekday())  # Monday = 0
    elif p == "month":
        start = ref.replace(day=1)
    else:  # year
        start = ref.replace(month=1, day=1)

    if p == "day":
        end = start + timedelta(days=1)
    elif p == "week":
        end = start + timedelta(days=7)
    elif p == "month":
        end = (start.replace(day=28) + timedelta(days=4)).replace(day=1)
    else:  # year
        end = start.replace(year=start.year + 1)

    return start.isoformat(), end.isoformat()
