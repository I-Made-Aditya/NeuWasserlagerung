"""
Generate a bcrypt hash for a password.

Usage (run from the backend/ folder):
    python -m app.utils.hash_password "yourpassword"

Copy the printed hash into database/seed.sql.

This tool is intentionally standalone: it does NOT import app.config, so it
works BEFORE you have created the backend/.env file (the first-time setup
needs hashes for seed.sql before the .env exists).
"""
import sys

from passlib.context import CryptContext

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def main():
    if len(sys.argv) != 2:
        print('Usage: python -m app.utils.hash_password "yourpassword"')
        sys.exit(1)
    print(pwd_context.hash(sys.argv[1]))


if __name__ == "__main__":
    main()
