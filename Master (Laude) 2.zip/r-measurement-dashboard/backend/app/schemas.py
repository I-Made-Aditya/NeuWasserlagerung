from datetime import date
from typing import List, Optional

from pydantic import BaseModel


class LoginRequest(BaseModel):
    username: str
    password: str


class MeasurementCreate(BaseModel):
    date_in: date
    project_nr: str
    lom_nr: Optional[str] = None
    part_description: Optional[str] = None
    type: Optional[str] = None
    qty: int = 0
    test_stage: Optional[str] = None
    reliability: Optional[str] = None
    status: Optional[str] = "Measurement Yet"
    planning_start: Optional[date] = None
    planning_end: Optional[date] = None
    actual_start: Optional[date] = None
    actual_end: Optional[date] = None
    t1_temp: Optional[str] = None
    t2_temp: Optional[str] = None
    t3_temp: Optional[str] = None
    t4_temp: Optional[str] = None
    t5_temp: Optional[str] = None
    t6_temp: Optional[str] = None
    t7_temp: Optional[str] = None
    operator_id: Optional[int] = None
    remark: Optional[str] = None
    priority: Optional[int] = None


class MeasurementUpdate(MeasurementCreate):
    pass


class StatusUpdate(BaseModel):
    status: Optional[str] = None
    operator_id: Optional[int] = None
    actual_start: Optional[date] = None
    actual_end: Optional[date] = None


class PriorityUpdate(BaseModel):
    priority: Optional[int] = None


class BulkUpdate(BaseModel):
    """Applies the same (partial) set of field values to many rows at once.
    Used by the List Measurement "Mode Edit -> select rows -> Edit" action.
    Fields left as None are left untouched. Priority is intentionally excluded
    (it is unique per row, so it cannot be mass-assigned)."""
    ids: List[int]
    status: Optional[str] = None
    operator_id: Optional[int] = None
    reliability: Optional[str] = None
    test_stage: Optional[str] = None
    remark: Optional[str] = None
    planning_start: Optional[date] = None
    planning_end: Optional[date] = None
    actual_start: Optional[date] = None
    actual_end: Optional[date] = None


class DuplicateRequest(BaseModel):
    ids: List[int]


class UserCreate(BaseModel):
    username: str
    password: str
    role: str
    operator_id: Optional[int] = None


class UserPatch(BaseModel):
    active: Optional[bool] = None
    role: Optional[str] = None
    operator_id: Optional[int] = None
    password: Optional[str] = None
