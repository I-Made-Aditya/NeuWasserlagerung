import { computed, reactive } from 'vue';
import http from '../api/http';

export const state = reactive({
  user: JSON.parse(localStorage.getItem('rm_user') || 'null'),
  token: localStorage.getItem('rm_token') || null,
});

export async function login(username, password) {
  const { data } = await http.post('/auth/login', { username, password });
  state.token = data.token;
  state.user = data.user;
  localStorage.setItem('rm_token', data.token);
  localStorage.setItem('rm_user', JSON.stringify(data.user));
  return data.user;
}

export function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('rm_token');
  localStorage.removeItem('rm_user');
}

export const isLoggedIn = computed(() => !!state.token);
export const isEngineer = computed(() => !!state.user && state.user.role === 'engineer');

export default { state, login, logout, isLoggedIn, isEngineer };
