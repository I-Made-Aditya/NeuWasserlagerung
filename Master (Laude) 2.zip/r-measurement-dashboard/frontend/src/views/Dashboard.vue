<template>
  <div class="app-shell">
    <div class="topbar">
      <div class="brand">
        <span class="brand-dot"></span>
        <h1>R-Measurement Dashboard</h1>
      </div>
      <div class="nav-links">
        <router-link to="/measurement-list" target="_blank">List Measurement</router-link>
        <router-link v-if="!isLoggedIn" to="/login">Login</router-link>
        <a v-else href="#" @click.prevent="handleLogout">Logout ({{ userName }})</a>
      </div>
    </div>

    <div class="page">
      <div class="toolbar">
        <div class="period-select">
          <label>Summary per</label>
          <select v-model="period" @change="loadAll">
            <option value="day">Day</option>
            <option value="week">Week</option>
            <option value="month">Month</option>
            <option value="year">Year</option>
          </select>
        </div>
      </div>

      <!-- 1. SUMMARY CARDS -->
      <div class="card-row">
        <StatCard label="Project" :value="summary.project_count" icon="📁" />
        <StatCard label="Measurement Yet" :value="summary.measurement_yet" variant="yet" icon="⏳" />
        <StatCard label="Ongoing" :value="summary.ongoing" variant="ongoing" icon="⚙️" />
        <StatCard label="Finished" :value="summary.finished" variant="finished" icon="✅" />
        <StatCard label="Temp Slot" :value="summary.temp_slot_total" icon="🌡️" />
      </div>

      <!-- 2. TREND (combo bar+line) -->
      <div class="panel">
        <h3>Tren R-Measurement (Temp Slot) per {{ periodLabel }}</h3>
        <ComboChart :labels="trend.labels" :data="trend.values" label="Temp Slot" />
      </div>

      <!-- 3. TOP PRIORITY -->
      <div class="panel">
        <div class="panel-header">
          <h3>🔥 Top List High Priority</h3>
        </div>
        <table>
          <thead><tr><th style="width:60px;">Nr</th><th>Project / Desc</th><th>Remark</th></tr></thead>
          <tbody>
            <tr v-for="row in topPriority" :key="row.nr">
              <td><span class="priority-badge">{{ row.nr }}</span></td>
              <td><strong>{{ row.project_nr }}</strong> <span class="muted">— {{ row.desc }}</span></td>
              <td>{{ row.remark || '-' }}</td>
            </tr>
            <tr v-if="!topPriority.length"><td colspan="3" class="empty-row">Belum ada project priority</td></tr>
          </tbody>
        </table>
      </div>

      <!-- 4. WORKLOAD TEMP + TOP PROJECT LOAD -->
      <div class="panel-row">
        <div class="panel">
          <div class="panel-header">
            <h3>Workload Temperature</h3>
            <select v-model="workloadStatus" @change="loadWorkloadTemp">
              <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
            </select>
          </div>
          <StackedBarChart :labels="workloadTemp.labels" :series="workloadTemp.series" />
        </div>
        <div class="panel">
          <h3>Top Project Load</h3>
          <BarChart :labels="topProject.labels" :data="topProject.values" label="Qty" horizontal color="#2563eb" />
        </div>
      </div>

      <!-- 5. BACKLOG AGING + OPERATOR LOAD (fixed to CW) -->
      <div class="panel-row">
        <div class="panel">
          <h3>Backlog Aging <span class="muted-sm">(belum Finished, per CW)</span></h3>
          <BarChart :labels="backlogTrend.labels" :data="backlogTrend.values" label="Qty" color="#e0554f" />
        </div>
        <div class="panel">
          <h3>Operator Load <span class="muted-sm">(open work, per CW)</span></h3>
          <MultiLineChart :labels="operatorTrend.labels" :series="operatorTrend.series" />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import http from '../api/http';
import { isLoggedIn, logout, state } from '../store/auth';
import { formatBucketLabel, toCWLabel } from '../utils/cw';

import BarChart from '../components/BarChart.vue';
import ComboChart from '../components/ComboChart.vue';
import MultiLineChart from '../components/MultiLineChart.vue';
import StackedBarChart from '../components/StackedBarChart.vue';
import StatCard from '../components/StatCard.vue';

const STATUSES = ['Measurement Yet', 'Ongoing', 'Finished Measurement'];
const router = useRouter();

const period = ref('week');
const workloadStatus = ref('Measurement Yet');

const summary = ref({ project_count: 0, measurement_yet: 0, ongoing: 0, finished: 0, temp_slot_total: 0 });
const trend = ref({ labels: [], values: [] });
const workloadTemp = ref({ labels: [], series: [] });
const topProject = ref({ labels: [], values: [] });
const backlogTrend = ref({ labels: [], values: [] });
const operatorTrend = ref({ labels: [], series: [] });
const topPriority = ref([]);

const userName = computed(() => (state.user ? state.user.username : ''));
const periodLabel = computed(() => ({ day: 'day', week: 'week (CW)', month: 'month', year: 'year' }[period.value]));

function handleLogout() {
  logout();
  router.push('/');
}

async function loadSummary() {
  const { data } = await http.get('/dashboard/summary', { params: { period: period.value } });
  summary.value = data;
}

async function loadTrend() {
  const { data } = await http.get('/dashboard/trend', { params: { period: period.value } });
  trend.value = {
    labels: data.series.map((r) => formatBucketLabel(r.bucket, period.value)),
    values: data.series.map((r) => Number(r.temp_slot_total)),
  };
}

async function loadWorkloadTemp() {
  const { data } = await http.get('/dashboard/workload-temperature', { params: { status: workloadStatus.value } });
  workloadTemp.value = { labels: data.temperatures, series: data.series };
}

async function loadTopProject() {
  const { data } = await http.get('/dashboard/top-project-load', { params: { period: period.value, limit: 10 } });
  topProject.value = {
    labels: data.data.map((r) => r.project_nr),
    values: data.data.map((r) => Number(r.qty)),
  };
}

async function loadBacklogTrend() {
  const { data } = await http.get('/dashboard/backlog-aging-trend', { params: { weeks: 12 } });
  backlogTrend.value = {
    labels: data.data.map((r) => toCWLabel(r.week_start)),
    values: data.data.map((r) => Number(r.qty)),
  };
}

async function loadOperatorTrend() {
  const { data } = await http.get('/dashboard/operator-load-trend', { params: { weeks: 12 } });
  const valid = data.data.filter((r) => r.week_start);
  const weekSet = [...new Set(valid.map((r) => r.week_start))].sort();
  const labels = weekSet.map((w) => toCWLabel(w));
  const operatorNames = [...new Set(valid.map((r) => r.operator_name))];
  const series = operatorNames.map((name) => ({
    name,
    values: weekSet.map((w) => {
      const match = valid.find((r) => r.operator_name === name && r.week_start === w);
      return match ? Number(match.temp_slot) : 0;
    }),
  }));
  operatorTrend.value = { labels, series };
}

async function loadTopPriority() {
  const { data } = await http.get('/dashboard/top-priority');
  topPriority.value = data.data;
}

async function loadAll() {
  await Promise.all([
    loadSummary(), loadTrend(), loadWorkloadTemp(),
    loadTopProject(), loadBacklogTrend(), loadOperatorTrend(),
    loadTopPriority(),
  ]);
}

onMounted(loadAll);
</script>
