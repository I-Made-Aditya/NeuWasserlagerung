<template>
  <div class="login-wrapper">
    <div class="login-card">
      <div class="login-brand">
        <img src="../assets/login-logo.png" alt="Logo" class="login-image" />
      </div>

      <form class="login-form" @submit.prevent="handleSubmit">
        <div class="form-field">
          <label class="form-label">Username</label>
          <input
            v-model="username"
            class="form-input"
            type="text"
            autocomplete="username"
            placeholder="Enter your username"
            required
          />
        </div>
        <div class="form-field">
          <label class="form-label">Password</label>
          <input
            v-model="password"
            class="form-input"
            type="password"
            autocomplete="current-password"
            placeholder="********"
            required
          />
        </div>

        <p v-if="errorMessage" class="login-error">{{ errorMessage }}</p>

        <button type="submit" class="btn btn--save login-submit" :disabled="loading">
          {{ loading ? 'Signing in…' : 'Sign In' }}
        </button>
      </form>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue';
import { useRoute, useRouter } from 'vue-router';
import { login } from '../store/auth';

const ZapIcon = {
  template: `<svg width="16" height="16" fill="none" stroke="white" stroke-width="2.5" viewBox="0 0 24 24">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
  </svg>`,
};

const PlusIcon = {
  template: `<svg width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24">
    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
  </svg>`,
};

export default {
  name: 'LoginView',
  components: { ZapIcon, PlusIcon },
  emits: ['success'],
  setup(props, { emit }) {
    const router = useRouter();
    const route = useRoute();

    const username = ref('');
    const password = ref('');
    const loading = ref(false);
    const errorMessage = ref('');

    async function handleSubmit() {
      errorMessage.value = '';
      loading.value = true;
      try {
        const user = await login(username.value.trim(), password.value);
        emit('success', user);
        const redirect = route.query.redirect || '/measurement-list';
        router.push(redirect);
      } catch (err) {
        if (err.response?.status === 401) {
          errorMessage.value = 'Wrong username or password!';
        } else if (err.response?.status === 403) {
          errorMessage.value = 'Your account is inactive. Please contact your Engineer/Administrator.';
        } else {
          errorMessage.value = 'Something went wrong, please contact administrator.';
        }
      } finally {
        loading.value = false;
      }
    }

    return { username, password, loading, errorMessage, handleSubmit };
  },
};
</script>
