<template>
  <div class="app-shell">
    <div class="topbar">
      <div class="brand">
        <span class="brand-dot"></span>
        <h1>List Measurement</h1>
      </div>
      <div class="nav-links">
        <router-link to="/">Dashboard</router-link>
        <router-link v-if="isEngineer" to="/users">Kelola User</router-link>
        <a href="#" @click.prevent="handleLogout">Logout ({{ userName }})</a>
      </div>
    </div>

    <div class="page">
      <div class="list-toolbar">
        <div class="month-nav">
          <button @click="changeMonth(-1)" title="Bulan sebelumnya">&lsaquo;</button>
          <span class="month-label">{{ monthLabel }}</span>
          <button @click="changeMonth(1)" title="Bulan berikutnya">&rsaquo;</button>
        </div>

        <div class="toolbar-actions">
          <ActionBtn v-if="isEngineer" label="Tambah Data" color="blue" @click="openAddModal">
            <span aria-hidden="true">＋</span>
          </ActionBtn>
          <ActionBtn v-if="!selectMode" label="Edit" color="blue" outline @click="enterSelectMode">
            <span aria-hidden="true">✎</span>
          </ActionBtn>
        </div>
      </div>

      <!-- Selection action bar: shown only after the user clicks "Edit" -->
      <Transition name="fade-slide">
        <div v-if="selectMode" class="selection-bar">
          <span class="selection-count">
            {{ selectedIds.size }} baris dipilih
            <span class="selection-hint" v-if="!selectedIds.size">— centang baris di sebelah kiri</span>
          </span>
          <div class="selection-actions">
            <template v-if="isEngineer">
              <ActionBtn label="Duplikasi" color="teal" :disabled="!selectedIds.size" @click="duplicateSelected" />
              <ActionBtn label="Edit" color="blue" :disabled="!selectedIds.size" @click="openEditModal" />
            </template>
            <template v-else>
              <ActionBtn label="Finish Measurement" color="green" :disabled="!selectedIds.size" @click="finishSelected" />
              <ActionBtn label="Edit Status / Tanggal" color="blue" :disabled="!selectedIds.size" @click="openEditModal" />
            </template>
            <ActionBtn label="Batal" color="dark" outline @click="exitSelectMode" />
          </div>
        </div>
      </Transition>

      <div class="list-card">
        <div class="list-card-header">
          <div class="entries-info">
            <template v-if="filteredRows.length">Showing {{ startIdx + 1 }} to {{ endIdx }} of {{ filteredRows.length }} items</template>
            <template v-else>Showing 0 items</template>
            <span v-if="loading"> · memuat...</span>
          </div>
          <div class="search-box">
            <input v-model="search" placeholder="Search..." />
          </div>
        </div>

        <div class="table-scroll">
          <table class="data-table">
            <thead>
              <tr>
                <th v-if="selectMode" class="select-col">
                  <input type="checkbox" :checked="allSelectedOnPage" @change="toggleSelectAllOnPage" title="Pilih semua di halaman ini" />
                </th>
                <th v-for="col in columns" :key="col.key" :class="{ sorted: sortKey === col.key }" @click="sortBy(col.key)">
                  {{ col.label }} <span class="sort-arrow">{{ arrowFor(col.key) }}</span>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr
                v-for="row in pagedRows"
                :key="row.id"
                :class="{ 'row-selected': selectedIds.has(row.id), 'row-clickable': selectMode }"
                @click="selectMode && toggleRowSelect(row.id)"
              >
                <td v-if="selectMode" class="select-col" @click.stop>
                  <input type="checkbox" :checked="selectedIds.has(row.id)" @change="toggleRowSelect(row.id)" />
                </td>
                <td>{{ formatDate(row.date_in) }}</td>
                <td class="link-cell">{{ row.project_nr }}</td>
                <td class="link-cell">{{ row.lom_nr }}</td>
                <td class="cell-clip" :title="row.part_description">{{ row.part_description }}</td>
                <td>{{ row.type }}</td>
                <td>{{ row.qty }}</td>
                <td>{{ row.test_stage }}</td>
                <td v-for="n in 7" :key="n">{{ row['t' + n + '_temp'] || '-' }}</td>
                <td>{{ row.reliability }}</td>
                <td><span class="badge" :class="statusClass(row.status)">{{ row.status }}</span></td>
                <td>{{ row.operator_name || '-' }}</td>
                <td>
                  <span v-if="row.priority" class="priority-badge">{{ row.priority }}</span>
                  <span v-else>-</span>
                </td>
                <td class="cell-clip" :title="row.remark">{{ row.remark }}</td>
                <td>{{ formatDate(row.planning_start) }}</td>
                <td>{{ formatDate(row.planning_end) }}</td>
                <td>{{ formatDate(row.actual_start) }}</td>
                <td>{{ formatDate(row.actual_end) }}</td>
              </tr>
              <tr v-if="!pagedRows.length">
                <td :colspan="columns.length + (selectMode ? 1 : 0)" class="empty-row">Tidak ada data untuk bulan ini</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="pagination-bar">
          <div class="per-page">
            Show
            <select v-model.number="perPage">
              <option v-for="n in PER_PAGE_OPTIONS" :key="n" :value="n">{{ n }}</option>
            </select>
            entries
          </div>
          <div class="pagination-controls">
            <button :disabled="page <= 1" @click="page--">Previous</button>
            <button v-for="p in totalPages" :key="p" :class="{ active: p === page }" @click="page = p">{{ p }}</button>
            <button :disabled="page >= totalPages" @click="page++">Next</button>
          </div>
        </div>
      </div>
    </div>

    <!-- ============ ADD (popup, engineer only) ============ -->
    <ModalDialog v-if="addModalOpen" title="Tambah Data Baru" max-width="860px" @close="closeAddModal">
      <form @submit.prevent="submitAdd">
        <FormSection title="Informasi Project">
          <FormField label="Date In"><input v-model="addForm.date_in" type="date" required /></FormField>
          <FormField label="Project Nr"><input v-model="addForm.project_nr" required /></FormField>
          <FormField label="LOM Nr"><input v-model="addForm.lom_nr" /></FormField>
          <FormField label="Part Description" class-name="ff--span2"><input v-model="addForm.part_description" /></FormField>
          <FormField label="Type"><input v-model="addForm.type" /></FormField>
          <FormField label="Qty"><input v-model.number="addForm.qty" type="number" min="0" /></FormField>
        </FormSection>

        <FormSection title="Test & Temperature">
          <FormField label="Bf / Af Test"><input v-model="addForm.test_stage" /></FormField>
          <FormField label="Reliability"><input v-model="addForm.reliability" /></FormField>
          <FormField label="Status">
            <select v-model="addForm.status">
              <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
            </select>
          </FormField>
          <FormField v-for="n in 7" :key="n" :label="`T${n} (°C)`">
            <input v-model="addForm['t' + n + '_temp']" placeholder="mis. R25" />
          </FormField>
        </FormSection>

        <FormSection title="Assignment & Jadwal">
          <FormField label="Operator">
            <select v-model="addForm.operator_id">
              <option :value="null">-</option>
              <option v-for="o in operators" :key="o.id" :value="o.id">{{ o.name }}</option>
            </select>
          </FormField>
          <FormField label="Priority (1-10)">
            <select v-model="addForm.priority">
              <option :value="null">-</option>
              <option v-for="n in 10" :key="n" :value="n">{{ n }}</option>
            </select>
          </FormField>
          <FormField label="Remark"><input v-model="addForm.remark" /></FormField>
          <FormField label="Plan Start"><input v-model="addForm.planning_start" type="date" /></FormField>
          <FormField label="Plan End"><input v-model="addForm.planning_end" type="date" /></FormField>
        </FormSection>
        <button type="submit" hidden></button>
      </form>
      <p v-if="addError" class="error-text">{{ addError }}</p>

      <template #footer>
        <ActionBtn label="Batal" color="dark" outline @click="closeAddModal" />
        <ActionBtn label="Simpan" color="blue" :disabled="saving" @click="submitAdd" />
      </template>
    </ModalDialog>

    <!-- ============ EDIT 1 ROW (popup, engineer) ============ -->
    <ModalDialog v-if="editModalOpen && editMode === 'single'" title="Edit Data" max-width="860px" @close="closeEditModal">
      <form @submit.prevent="submitSingleEdit">
        <FormSection title="Informasi Project">
          <FormField label="Date In"><input v-model="editForm.date_in" type="date" required /></FormField>
          <FormField label="Project Nr"><input v-model="editForm.project_nr" required /></FormField>
          <FormField label="LOM Nr"><input v-model="editForm.lom_nr" /></FormField>
          <FormField label="Part Description" class-name="ff--span2"><input v-model="editForm.part_description" /></FormField>
          <FormField label="Type"><input v-model="editForm.type" /></FormField>
          <FormField label="Qty"><input v-model.number="editForm.qty" type="number" min="0" /></FormField>
        </FormSection>

        <FormSection title="Test & Temperature">
          <FormField label="Bf / Af Test"><input v-model="editForm.test_stage" /></FormField>
          <FormField label="Reliability"><input v-model="editForm.reliability" /></FormField>
          <FormField label="Status">
            <select v-model="editForm.status">
              <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
            </select>
          </FormField>
          <FormField v-for="n in 7" :key="n" :label="`T${n} (°C)`">
            <input v-model="editForm['t' + n + '_temp']" placeholder="mis. R25" />
          </FormField>
        </FormSection>

        <FormSection title="Assignment & Jadwal">
          <FormField label="Operator">
            <select v-model="editForm.operator_id">
              <option :value="null">-</option>
              <option v-for="o in operators" :key="o.id" :value="o.id">{{ o.name }}</option>
            </select>
          </FormField>
          <FormField label="Priority (1-10)">
            <select v-model="editForm.priority">
              <option :value="null">-</option>
              <option v-for="n in 10" :key="n" :value="n">{{ n }}</option>
            </select>
          </FormField>
          <FormField label="Remark"><input v-model="editForm.remark" /></FormField>
          <FormField label="Plan Start"><input v-model="editForm.planning_start" type="date" /></FormField>
          <FormField label="Plan End"><input v-model="editForm.planning_end" type="date" /></FormField>
          <FormField label="Actual Start"><input v-model="editForm.actual_start" type="date" /></FormField>
          <FormField label="Actual End"><input v-model="editForm.actual_end" type="date" /></FormField>
        </FormSection>
        <button type="submit" hidden></button>
      </form>
      <p v-if="editError" class="error-text">{{ editError }}</p>

      <template #footer>
        <ActionBtn label="Batal" color="dark" outline @click="closeEditModal" />
        <ActionBtn label="Simpan Perubahan" color="blue" :disabled="saving" @click="submitSingleEdit" />
      </template>
    </ModalDialog>

    <!-- ============ EDIT MANY ROWS (engineer multi-select, or operator) ============ -->
    <ModalDialog
      v-if="editModalOpen && editMode === 'bulk'"
      :title="`Edit ${selectedIds.size} Data Terpilih`"
      max-width="620px"
      @close="closeEditModal"
    >
      <p class="bulk-hint">Hanya field yang diisi yang akan diterapkan ke semua baris terpilih. Field yang dibiarkan kosong / "jangan ubah" tidak akan diubah.</p>
      <form @submit.prevent="submitBulkEdit">
        <FormSection title="Status & Assignment">
          <FormField label="Status">
            <select v-model="bulkForm.status">
              <option :value="null">— jangan ubah —</option>
              <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
            </select>
          </FormField>
          <FormField label="Operator">
            <select v-model="bulkForm.operator_id">
              <option :value="null">— jangan ubah —</option>
              <option v-for="o in operators" :key="o.id" :value="o.id">{{ o.name }}</option>
            </select>
          </FormField>
        </FormSection>

        <FormSection v-if="isEngineer" title="Test Info & Catatan">
          <FormField label="Reliability"><input v-model="bulkForm.reliability" placeholder="(jangan ubah)" /></FormField>
          <FormField label="Bf / Af Test"><input v-model="bulkForm.test_stage" placeholder="(jangan ubah)" /></FormField>
          <FormField label="Remark"><input v-model="bulkForm.remark" placeholder="(jangan ubah)" /></FormField>
        </FormSection>

        <FormSection title="Jadwal">
          <FormField v-if="isEngineer" label="Plan Start"><input v-model="bulkForm.planning_start" type="date" /></FormField>
          <FormField v-if="isEngineer" label="Plan End"><input v-model="bulkForm.planning_end" type="date" /></FormField>
          <FormField label="Actual Start"><input v-model="bulkForm.actual_start" type="date" /></FormField>
          <FormField label="Actual End"><input v-model="bulkForm.actual_end" type="date" /></FormField>
        </FormSection>
        <button type="submit" hidden></button>
      </form>
      <p v-if="editError" class="error-text">{{ editError }}</p>

      <template #footer>
        <ActionBtn label="Batal" color="dark" outline @click="closeEditModal" />
        <ActionBtn label="Terapkan ke Semua" color="blue" :disabled="saving" @click="submitBulkEdit" />
      </template>
    </ModalDialog>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref, watch } from 'vue';
import { useRouter } from 'vue-router';
import http from '../api/http';
import { isEngineer, logout, state } from '../store/auth';

import ActionBtn from '../components/ActionBtn.vue';
import FormField from '../components/FormField.vue';
import FormSection from '../components/FormSection.vue';
import ModalDialog from '../components/ModalDialog.vue';

const STATUSES = ['Measurement Yet', 'Ongoing', 'Finished Measurement'];
const MONTH_NAMES = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const PER_PAGE_OPTIONS = [50, 100, 150, 200, 300];

const COLUMNS = [
  { key: 'date_in', label: 'Date In' },
  { key: 'project_nr', label: 'Project Nr' },
  { key: 'lom_nr', label: 'LOM Nr' },
  { key: 'part_description', label: 'Part Description' },
  { key: 'type', label: 'Type' },
  { key: 'qty', label: 'Qty' },
  { key: 'test_stage', label: 'Bf Test / Af Test' },
  { key: 't1_temp', label: 'T1 (°C)' },
  { key: 't2_temp', label: 'T2 (°C)' },
  { key: 't3_temp', label: 'T3 (°C)' },
  { key: 't4_temp', label: 'T4 (°C)' },
  { key: 't5_temp', label: 'T5 (°C)' },
  { key: 't6_temp', label: 'T6 (°C)' },
  { key: 't7_temp', label: 'T7 (°C)' },
  { key: 'reliability', label: 'Reliability' },
  { key: 'status', label: 'Status' },
  { key: 'operator_name', label: 'Operator' },
  { key: 'priority', label: 'Priority' },
  { key: 'remark', label: 'Remark' },
  { key: 'planning_start', label: 'Plan Start' },
  { key: 'planning_end', label: 'Plan End' },
  { key: 'actual_start', label: 'Actual Start' },
  { key: 'actual_end', label: 'Actual End' },
];

const router = useRouter();

function emptyForm() {
  const f = {
    date_in: '', project_nr: '', lom_nr: '', part_description: '', type: '',
    qty: 0, test_stage: '', reliability: '', status: 'Measurement Yet',
    operator_id: null, remark: '', priority: null,
    planning_start: '', planning_end: '', actual_start: '', actual_end: '',
  };
  for (let n = 1; n <= 7; n++) f[`t${n}_temp`] = '';
  return f;
}

function emptyBulkForm() {
  return {
    status: null, operator_id: null, reliability: null, test_stage: null,
    remark: null, planning_start: null, planning_end: null, actual_start: null, actual_end: null,
  };
}

// The API expects real nulls: an empty date input gives '' (-> 422) and a cleared
// number input gives '' as well, so normalise before sending.
function cleanPayload(obj) {
  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    out[k] = typeof v === 'string' && v.trim() === '' ? null : v;
  }
  if ('qty' in out && (out.qty === null || Number.isNaN(Number(out.qty)))) out.qty = 0;
  return out;
}

// FastAPI returns `detail` as a string for our own errors but as an array of
// objects for validation (422) errors.
function errorText(err, fallback) {
  const d = err.response?.data?.detail;
  if (typeof d === 'string') return d;
  if (Array.isArray(d)) return d.map((e) => `${(e.loc || []).slice(1).join('.')}: ${e.msg}`).join('; ');
  return fallback;
}

const now = new Date();
const columns = COLUMNS;
const rows = ref([]);
const operators = ref([]);
const loading = ref(false);
const saving = ref(false);
const year = ref(now.getFullYear());
const month = ref(now.getMonth() + 1);
const search = ref('');
const sortKey = ref('date_in');
const sortDir = ref('asc');
const page = ref(1);
const perPage = ref(50);

// selection ("Edit") state
const selectMode = ref(false);
const selectedIds = reactive(new Set());

// modals
const addModalOpen = ref(false);
const addForm = reactive(emptyForm());
const addError = ref('');

const editModalOpen = ref(false);
const editMode = ref('single'); // 'single' | 'bulk'
const editingId = ref(null);
const editForm = reactive(emptyForm());
const bulkForm = reactive(emptyBulkForm());
const editError = ref('');

const userName = computed(() => (state.user ? state.user.username : ''));
const monthLabel = computed(() => `${MONTH_NAMES[month.value - 1]} ${year.value}`);

const filteredRows = computed(() => {
  let list = rows.value;
  if (search.value) {
    const q = search.value.toLowerCase();
    list = list.filter((r) => COLUMNS.some((c) => String(r[c.key] ?? '').toLowerCase().includes(q)));
  }
  const key = sortKey.value;
  const dir = sortDir.value === 'asc' ? 1 : -1;
  return [...list].sort((a, b) => {
    const av = a[key]; const bv = b[key];
    if (av == null && bv == null) return 0;
    if (av == null) return 1;
    if (bv == null) return -1;
    if (!isNaN(av) && !isNaN(bv)) return (Number(av) - Number(bv)) * dir;
    return String(av).localeCompare(String(bv)) * dir;
  });
});

const totalPages = computed(() => Math.max(1, Math.ceil(filteredRows.value.length / perPage.value)));
const startIdx = computed(() => (page.value - 1) * perPage.value);
const endIdx = computed(() => Math.min(startIdx.value + perPage.value, filteredRows.value.length));
const pagedRows = computed(() => filteredRows.value.slice(startIdx.value, endIdx.value));
const allSelectedOnPage = computed(() => pagedRows.value.length > 0 && pagedRows.value.every((r) => selectedIds.has(r.id)));

watch(search, () => {
  page.value = 1;
  // avoid acting on rows the user can no longer see
  selectedIds.clear();
});
watch(perPage, () => { page.value = 1; });

// Dates arrive as "YYYY-MM-DD". Format by splitting so the browser time zone can never shift the day.
function formatDate(d) {
  if (!d) return '-';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(d));
  return m ? `${m[3]}/${m[2]}/${m[1]}` : String(d);
}
function statusClass(s) {
  if (s === 'Ongoing') return 'ongoing';
  if (s === 'Finished Measurement') return 'finished';
  return 'yet';
}
function handleLogout() { logout(); router.push('/'); }

function changeMonth(delta) {
  let m = month.value + delta;
  let y = year.value;
  if (m > 12) { m = 1; y++; }
  if (m < 1) { m = 12; y--; }
  month.value = m; year.value = y;
  page.value = 1;
  selectedIds.clear();
  fetchData();
}

function sortBy(key) {
  if (sortKey.value === key) {
    sortDir.value = sortDir.value === 'asc' ? 'desc' : 'asc';
  } else {
    sortKey.value = key; sortDir.value = 'asc';
  }
}
function arrowFor(key) {
  if (sortKey.value !== key) return '↕';
  return sortDir.value === 'asc' ? '↑' : '↓';
}

// ---------------- selection ("Edit" mode) ----------------
function enterSelectMode() { selectMode.value = true; }
function exitSelectMode() {
  selectMode.value = false;
  selectedIds.clear();
}
function toggleRowSelect(id) {
  if (selectedIds.has(id)) selectedIds.delete(id);
  else selectedIds.add(id);
}
function toggleSelectAllOnPage() {
  if (allSelectedOnPage.value) pagedRows.value.forEach((r) => selectedIds.delete(r.id));
  else pagedRows.value.forEach((r) => selectedIds.add(r.id));
}

// ---------------- data ----------------
async function fetchOperators() {
  const { data } = await http.get('/operators');
  operators.value = data;
}

async function fetchData() {
  loading.value = true;
  try {
    const { data } = await http.get('/measurements', { params: { year: year.value, month: month.value } });
    rows.value = data.data;
  } finally {
    loading.value = false;
  }
}

// ---------------- Add ----------------
function openAddModal() {
  Object.assign(addForm, emptyForm());
  addError.value = '';
  addModalOpen.value = true;
}
function closeAddModal() { addModalOpen.value = false; }

async function submitAdd() {
  addError.value = '';
  saving.value = true;
  try {
    const payload = cleanPayload({ ...addForm });
    await http.post('/measurements', payload);
    // jump to the month of the new row so the engineer sees it immediately
    const m = /^(\d{4})-(\d{2})/.exec(payload.date_in || '');
    if (m) { year.value = Number(m[1]); month.value = Number(m[2]); page.value = 1; }
    closeAddModal();
    await fetchData();
  } catch (err) {
    addError.value = errorText(err, 'Gagal menyimpan');
  } finally {
    saving.value = false;
  }
}

// ---------------- Edit (1 row for engineer, otherwise bulk) ----------------
function openEditModal() {
  if (!selectedIds.size) return;
  editError.value = '';

  if (isEngineer.value && selectedIds.size === 1) {
    const id = [...selectedIds][0];
    const row = rows.value.find((r) => r.id === id);
    if (!row) return;
    editMode.value = 'single';
    editingId.value = id;
    Object.assign(editForm, emptyForm(), {
      date_in: row.date_in, project_nr: row.project_nr, lom_nr: row.lom_nr,
      part_description: row.part_description, type: row.type, qty: row.qty,
      test_stage: row.test_stage, reliability: row.reliability, status: row.status,
      t1_temp: row.t1_temp, t2_temp: row.t2_temp, t3_temp: row.t3_temp, t4_temp: row.t4_temp,
      t5_temp: row.t5_temp, t6_temp: row.t6_temp, t7_temp: row.t7_temp,
      operator_id: row.operator_id, remark: row.remark, priority: row.priority,
      planning_start: row.planning_start, planning_end: row.planning_end,
      actual_start: row.actual_start, actual_end: row.actual_end,
    });
  } else {
    editMode.value = 'bulk';
    Object.assign(bulkForm, emptyBulkForm());
  }
  editModalOpen.value = true;
}
function closeEditModal() { editModalOpen.value = false; }

async function submitSingleEdit() {
  editError.value = '';
  saving.value = true;
  try {
    await http.put(`/measurements/${editingId.value}`, cleanPayload({ ...editForm }));
    closeEditModal();
    exitSelectMode();
    await fetchData();
  } catch (err) {
    editError.value = errorText(err, 'Gagal menyimpan perubahan');
  } finally {
    saving.value = false;
  }
}

async function submitBulkEdit() {
  editError.value = '';
  const fields = cleanPayload({ ...bulkForm });
  if (!Object.values(fields).some((v) => v !== null)) {
    editError.value = 'Isi minimal satu field yang ingin diubah.';
    return;
  }
  saving.value = true;
  try {
    await http.patch('/measurements/bulk', { ids: [...selectedIds], ...fields });
    closeEditModal();
    exitSelectMode();
    await fetchData();
  } catch (err) {
    editError.value = errorText(err, 'Gagal menyimpan perubahan');
  } finally {
    saving.value = false;
  }
}

// ---------------- quick mass actions ----------------
async function duplicateSelected() {
  if (!selectedIds.size) return;
  if (!confirm(`Duplikasi ${selectedIds.size} data terpilih?\n\nHasil duplikasi berstatus "Measurement Yet" dan tanggal Actual dikosongkan.`)) return;
  try {
    await http.post('/measurements/duplicate', { ids: [...selectedIds] });
    exitSelectMode();
    await fetchData();
  } catch (err) {
    alert(errorText(err, 'Gagal menduplikasi data'));
  }
}

async function finishSelected() {
  if (!selectedIds.size) return;
  if (!confirm(`Tandai ${selectedIds.size} data sebagai "Finished Measurement"?`)) return;
  try {
    await http.patch('/measurements/bulk', { ids: [...selectedIds], status: 'Finished Measurement' });
    exitSelectMode();
    await fetchData();
  } catch (err) {
    alert(errorText(err, 'Gagal update status'));
  }
}

onMounted(() => {
  fetchOperators();
  fetchData();
});
</script>
