import { createRouter, createWebHistory } from 'vue-router';
import { isEngineer, isLoggedIn } from '../store/auth';

import Dashboard from '../views/Dashboard.vue';
import Login from '../views/Login.vue';
import MeasurementList from '../views/MeasurementList.vue';
import UsersAdmin from '../views/UsersAdmin.vue';

const routes = [
  { path: '/', name: 'Dashboard', component: Dashboard }, // public, per requirement
  { path: '/login', name: 'Login', component: Login },
  {
    path: '/measurement-list',
    name: 'MeasurementList',
    component: MeasurementList,
    meta: { requiresAuth: true },
  },
  {
    path: '/users',
    name: 'UsersAdmin',
    component: UsersAdmin,
    meta: { requiresAuth: true, requiresEngineer: true },
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

router.beforeEach((to) => {
  if (to.meta.requiresAuth && !isLoggedIn.value) {
    return { name: 'Login', query: { redirect: to.fullPath } };
  }
  if (to.meta.requiresEngineer && !isEngineer.value) {
    return { name: 'MeasurementList' };
  }
  return true;
});

export default router;
