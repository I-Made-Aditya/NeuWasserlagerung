<template>
  <button
    type="button"
    class="action-btn"
    :class="[`action-btn--${color}`, { 'action-btn--outline': outline }]"
    :disabled="disabled"
    @click="$emit('click')"
  >
    <slot />
    <span>{{ label }}</span>
  </button>
</template>

<script setup>
defineProps({
  label: { type: String, required: true },
  color: { type: String, default: 'blue' }, // blue | teal | orange | green | red | dark
  outline: { type: Boolean, default: false },
  disabled: { type: Boolean, default: false },
});
defineEmits(['click']);
</script>

<style>
.action-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 14px;
  border-radius: var(--radius-full);
  color: white;
  font-size: 13px;
  font-weight: 600;
  transition: background var(--transition-fast), transform var(--transition-fast), opacity var(--transition-fast);
  white-space: nowrap;
}
.action-btn:active { transform: scale(0.97); }
.action-btn:disabled { opacity: 0.45; cursor: not-allowed; }

.action-btn--blue { background: var(--color-blue); }
.action-btn--blue:hover:not(:disabled) { background: var(--color-blue-hover); }

.action-btn--teal { background: var(--color-teal); }
.action-btn--teal:hover:not(:disabled) { background: #2A9DD4; }

.action-btn--orange { background: var(--color-orange); }
.action-btn--orange:hover:not(:disabled) { background: #ffaa33; }

.action-btn--green { background: var(--color-green); }
.action-btn--green:hover:not(:disabled) { background: #28bf4d; }

.action-btn--red { background: var(--color-red); }
.action-btn--red:hover:not(:disabled) { background: #e6392e; }

.action-btn--dark { background: var(--color-dark); }
.action-btn--dark:hover:not(:disabled) { background: #3A3A3C; }

.action-btn--outline {
  background: transparent;
  border: 1.5px solid var(--color-border-light);
  color: var(--color-text-secondary);
}
.action-btn--dark.action-btn--outline {
  background: transparent;
  color: #E5E5EA;
  border-color: rgba(255, 255, 255, 0.3);
}
.action-btn--outline:hover:not(:disabled) { background: rgba(142, 142, 147, 0.15); }
</style>
