<template>
  <div style="position: relative; height: 320px;">
    <canvas ref="canvasRef"></canvas>
  </div>
</template>

<script setup>
import Chart from 'chart.js/auto';
import { onBeforeUnmount, onMounted, ref, watch } from 'vue';

const props = defineProps({
  labels: { type: Array, default: () => [] },       // x-axis categories (temperatures)
  series: { type: Array, default: () => [] },        // [{ project: 'T130-000151', values: [..] }]
  yLabel: { type: String, default: 'Qty' },
});

const PALETTE = [
  '#0f4c75', '#2563eb', '#3b9797', '#f5a623', '#e0554f',
  '#8b5cf6', '#16a34a', '#d97706', '#0891b2', '#be185d',
  '#6366f1', '#059669', '#9ca3af',
];

const canvasRef = ref(null);
let chart = null;

function render() {
  if (chart) chart.destroy();
  if (!canvasRef.value) return;

  const datasets = props.series.map((s, idx) => ({
    label: s.project,
    data: s.values,
    backgroundColor: s.project === 'Others' ? '#cbd2d9' : PALETTE[idx % PALETTE.length],
    stack: 'stack1',
    borderRadius: 3,
    maxBarThickness: 60,
  }));

  chart = new Chart(canvasRef.value, {
    type: 'bar',
    data: { labels: props.labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'right', labels: { boxWidth: 10, font: { size: 11 } } },
        tooltip: {
          callbacks: {
            footer: (items) => {
              const total = items.reduce((sum, it) => sum + it.parsed.y, 0);
              return `Total: ${total.toLocaleString('id-ID')}`;
            },
          },
        },
      },
      scales: {
        x: { stacked: true, title: { display: true, text: 'Temperature (°C)' }, grid: { display: false } },
        y: { stacked: true, title: { display: true, text: props.yLabel }, grid: { color: '#eef1f4' }, beginAtZero: true },
      },
    },
  });
}

onMounted(render);
onBeforeUnmount(() => { if (chart) chart.destroy(); });
watch(() => [props.labels, props.series], render, { deep: true });
</script>
