<template>
  <div style="position: relative; height: 260px;">
    <canvas ref="canvasRef"></canvas>
  </div>
</template>

<script setup>
import Chart from 'chart.js/auto';
import { onBeforeUnmount, onMounted, ref, watch } from 'vue';

const props = defineProps({
  labels: { type: Array, default: () => [] },
  data: { type: Array, default: () => [] },
  label: { type: String, default: 'Value' },
  horizontal: { type: Boolean, default: false },
  color: { type: String, default: '#0f4c75' },
});

const canvasRef = ref(null);
let chart = null;

function render() {
  if (chart) chart.destroy();
  if (!canvasRef.value) return;
  chart = new Chart(canvasRef.value, {
    type: 'bar',
    data: {
      labels: props.labels,
      datasets: [{
        label: props.label,
        data: props.data,
        backgroundColor: props.color,
        borderRadius: 4,
      }],
    },
    options: {
      indexAxis: props.horizontal ? 'y' : 'x',
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: { grid: { display: false } },
    },
  });
}

onMounted(render);
onBeforeUnmount(() => { if (chart) chart.destroy(); });
watch(() => [props.labels, props.data], render, { deep: true });
</script>
