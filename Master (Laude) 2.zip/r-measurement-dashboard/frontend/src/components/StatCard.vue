<template>
  <div class="stat-card" :class="variant">
    <div class="stat-icon">{{ icon }}</div>
    <div class="stat-body">
      <div class="label">{{ label }}</div>
      <div class="value">{{ formattedValue }}</div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({
  label: { type: String, required: true },
  value: { type: [Number, String], default: 0 },
  variant: { type: String, default: '' },
  icon: { type: String, default: '' },
});

const formattedValue = computed(() => {
  const n = Number(props.value);
  return isNaN(n) ? props.value : n.toLocaleString('id-ID');
});
</script>
