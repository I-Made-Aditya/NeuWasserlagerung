<template>
  <div class="form-section">
    <p class="section-title">{{ title }}</p>
    <div class="section-body">
      <slot />
    </div>
  </div>
</template>

<script setup>
defineProps({
  title: { type: String, required: true },
});
</script>

<style>
.form-section + .form-section { margin-top: 16px; }

.section-title {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.1em;
  color: var(--color-text-quaternary);
  margin-bottom: 8px;
}

.section-body {
  background: var(--color-surface);
  border-radius: var(--radius-md);
  padding: 14px;
  border: 1px solid var(--color-border);
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

@media (max-width: 640px) {
  .section-body { grid-template-columns: repeat(2, 1fr); }
}
</style>
