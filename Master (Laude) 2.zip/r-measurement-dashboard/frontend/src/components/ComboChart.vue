<template>
  <div style="position: relative; height: 300px;">
    <canvas ref="canvasRef"></canvas>
  </div>
</template>

<script setup>
import Chart from 'chart.js/auto';
import { onBeforeUnmount, onMounted, ref, watch } from 'vue';

const props = defineProps({
  labels: { type: Array, default: () => [] },
  data: { type: Array, default: () => [] },
  label: { type: String, default: 'Value' },
});

const canvasRef = ref(null);
let chart = null;

function render() {
  if (chart) chart.destroy();
  if (!canvasRef.value) return;
  const ctx = canvasRef.value.getContext('2d');
  const gradient = ctx.createLinearGradient(0, 0, 0, 280);
  gradient.addColorStop(0, 'rgba(37, 99, 235, 0.35)');
  gradient.addColorStop(1, 'rgba(37, 99, 235, 0.02)');

  chart = new Chart(canvasRef.value, {
    data: {
      labels: props.labels,
      datasets: [
        {
          type: 'bar',
          label: props.label,
          data: props.data,
          backgroundColor: gradient,
          borderRadius: 6,
          maxBarThickness: 42,
          order: 2,
        },
        {
          type: 'line',
          label: `Trend ${props.label}`,
          data: props.data,
          borderColor: '#f5a623',
          backgroundColor: '#f5a623',
          borderWidth: 3,
          tension: 0.35,
          pointRadius: 4,
          pointBackgroundColor: '#fff',
          pointBorderColor: '#f5a623',
          pointBorderWidth: 2,
          fill: false,
          order: 1,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { display: true, position: 'top', labels: { boxWidth: 12, font: { size: 12 } } },
      },
      scales: {
        x: { grid: { display: false } },
        y: { grid: { color: '#eef1f4' }, beginAtZero: true },
      },
    },
  });
}

onMounted(render);
onBeforeUnmount(() => { if (chart) chart.destroy(); });
watch(() => [props.labels, props.data], render, { deep: true });
</script>
