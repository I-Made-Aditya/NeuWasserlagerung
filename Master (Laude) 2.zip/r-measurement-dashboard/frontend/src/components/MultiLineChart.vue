<template>
  <div style="position: relative; height: 300px;">
    <canvas ref="canvasRef"></canvas>
  </div>
</template>

<script setup>
import Chart from 'chart.js/auto';
import { onBeforeUnmount, onMounted, ref, watch } from 'vue';

const props = defineProps({
  labels: { type: Array, default: () => [] },   // CW labels
  series: { type: Array, default: () => [] },    // [{ name: 'Kenya', values: [..] }]
  yLabel: { type: String, default: 'Temp Slot' },
});

const COLORS = ['#0f4c75', '#f5a623', '#e0554f', '#16a34a', '#8b5cf6', '#0891b2'];

const canvasRef = ref(null);
let chart = null;

function render() {
  if (chart) chart.destroy();
  if (!canvasRef.value) return;

  const datasets = props.series.map((s, idx) => ({
    label: s.name,
    data: s.values,
    borderColor: COLORS[idx % COLORS.length],
    backgroundColor: COLORS[idx % COLORS.length],
    tension: 0.3,
    pointRadius: 4,
    pointHoverRadius: 6,
    borderWidth: 2.5,
    fill: false,
  }));

  chart = new Chart(canvasRef.value, {
    type: 'line',
    data: { labels: props.labels, datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      plugins: {
        legend: { position: 'top', labels: { boxWidth: 12, font: { size: 12 } } },
      },
      scales: {
        x: { title: { display: true, text: 'Calendar Week' }, grid: { display: false } },
        y: { title: { display: true, text: props.yLabel }, grid: { color: '#eef1f4' }, beginAtZero: true },
      },
    },
  });
}

onMounted(render);
onBeforeUnmount(() => { if (chart) chart.destroy(); });
watch(() => [props.labels, props.series], render, { deep: true });
</script>
