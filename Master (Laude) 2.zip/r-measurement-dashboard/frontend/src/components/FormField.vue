<template>
  <div class="ff" :class="className">
    <label class="ff-label">{{ label }}</label>
    <slot />
  </div>
</template>

<script setup>
// Class names are prefixed "ff" on purpose: the Login page already uses
// ".form-field" / ".form-label", and these styles must not leak into it.
defineProps({
  label: { type: String, required: true },
  className: { type: String, default: '' },
});
</script>

<style>
.ff { display: flex; flex-direction: column; gap: 4px; min-width: 0; }

.ff .ff-label {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--color-text-tertiary);
}

.ff input,
.ff select,
.ff textarea {
  width: 100%;
  padding: 8px 10px;
  border: 1.5px solid var(--color-border-light);
  border-radius: var(--radius-sm);
  background: var(--color-white);
  font-size: 13px;
  color: var(--color-text-primary);
}
.ff input:focus,
.ff select:focus,
.ff textarea:focus {
  outline: none;
  border-color: var(--color-blue);
}

.ff--span2 { grid-column: span 2; }
.ff--span3 { grid-column: span 3; }
</style>
