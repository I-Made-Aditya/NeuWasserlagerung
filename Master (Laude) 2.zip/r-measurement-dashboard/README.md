# R-Measurement Dashboard (v4)

Sistem digitalisasi tracking measurement untuk station **R-Measurement**.

**Stack v3:**
- **Database:** PostgreSQL, semua tabel berada di schema **`monitoringmeasurement`** (bukan `public`)
- **Backend:** **Python + FastAPI**, dijalankan dengan `uvicorn`
- **Frontend:** **Vue 3 + Vite**, dijalankan dengan `npm run dev`

---

## 1. Struktur Folder

```
r-measurement-dashboard/
├── database/
│   ├── schema.sql          # DDL: schema monitoringmeasurement + tabel operators, users, measurements
│   ├── seed.sql            # seed operator (Kenya, Septy, Niki) + user pertama (engineer)
│   └── import_excel.py     # migrasi bertahap dari file Excel lama (Python)
├── backend/                # FastAPI app
│   ├── requirements.txt
│   ├── .env.example
│   └── app/
│       ├── main.py         # entrypoint FastAPI
│       ├── config.py       # baca .env (DATABASE_URL, DB_SCHEMA, JWT_SECRET, ...)
│       ├── database.py     # koneksi SQLAlchemy + konstanta SCHEMA
│       ├── auth.py         # hashing password (bcrypt) + JWT
│       ├── deps.py         # dependency injection (get_current_user, require_role)
│       ├── schemas.py      # Pydantic request/response models
│       ├── routers/
│       │   ├── auth.py         # POST /api/auth/login, GET /api/auth/me
│       │   ├── operators.py    # GET /api/operators (login wajib)
│       │   ├── measurements.py # CRUD List Measurement (login wajib)
│       │   ├── dashboard.py    # semua chart dashboard (PUBLIK, tanpa login)
│       │   └── users.py        # kelola akun operator/engineer (engineer only)
│       └── utils/
│           ├── period.py       # helper Day/Week/Month/Year
│           └── hash_password.py# CLI untuk generate hash password
└── frontend/                # Vue 3 + Vite app
    ├── package.json
    ├── vite.config.js
    ├── index.html
    ├── .env.example
    └── src/
        ├── main.js
        ├── App.vue
        ├── router/index.js      # Vue Router 4
        ├── store/auth.js        # state login (Composition API, reactive)
        ├── api/http.js          # axios instance + interceptor JWT
        ├── utils/cw.js          # helper Calendar Week (CW1, CW2, ...)
        ├── assets/main.css      # semua styling (tanpa framework CSS)
        ├── assets/login-logo.png# logo placeholder halaman login (ganti dengan logo asli)
        ├── components/          # StatCard, ComboChart, BarChart, StackedBarChart, MultiLineChart
        └── views/
            ├── Login.vue         # halaman login (publik)
            ├── Dashboard.vue     # halaman utama "/" (publik, tanpa login)
            ├── MeasurementList.vue # "/measurement-list" (wajib login)
            └── UsersAdmin.vue    # "/users" (wajib login + role engineer)
```

---

## 2. Prasyarat

Pastikan sudah terpasang di komputer Anda:

| Software | Versi minimal | Cek dengan |
|---|---|---|
| PostgreSQL | 13+ | `psql --version` |
| Python | 3.10+ | `python3 --version` |
| Node.js | 18+ | `node --version` |
| npm | 9+ | `npm --version` |

---

## 3. Setup Database (schema `monitoringmeasurement`)

> **Kenapa bukan `public`?** Karena tim IT tidak memberikan akses tulis ke schema `public` pada instance PostgreSQL trial/production mereka. Semua tabel, tipe data, index, dan trigger pada proyek ini secara eksplisit dibuat di dalam schema `monitoringmeasurement`, dan seluruh query di backend juga secara eksplisit menyebut `monitoringmeasurement.<nama_tabel>` — jadi tidak bergantung pada `search_path` default.

### 3.1 Buat database (jika belum ada)

```bash
createdb r_measurement
```

Jika database sudah disediakan oleh tim IT (misalnya di server test mereka), lewati langkah ini dan langsung gunakan connection string yang mereka berikan.

### 3.2 Jalankan schema

```bash
psql -d r_measurement -f database/schema.sql
```

Perintah ini akan:
1. Membuat schema `monitoringmeasurement` (jika belum ada)
2. Membuat tabel `operators`, `users`, `measurements` di dalam schema tersebut
3. Membuat tipe `measurement_status`, index, trigger `updated_at`, dan kolom generated `temp_slot`

> Jika role/user database Anda tidak diizinkan menjalankan `CREATE SCHEMA`, minta tim IT untuk membuatkan schema `monitoringmeasurement` terlebih dahulu dan memberikan hak `USAGE, CREATE` pada schema tersebut ke role aplikasi Anda, baru jalankan ulang `schema.sql`.

### 3.3 Generate password hash untuk user pertama

Password di database disimpan dalam bentuk **bcrypt hash**, tidak pernah plain text. Gunakan script bawaan backend:

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

python -m app.utils.hash_password "passwordEngineerAnda"
# contoh output: $2b$12$abcdefghijklmnopqrstuv...
```

> Script ini **tidak membutuhkan file `.env`**, jadi bisa dijalankan sebelum langkah 4. `requirements.txt` memakai `psycopg2-binary 2.9.10` agar kompatibel dengan Python 3.13 (juga jalan di 3.10-3.12).

Jalankan sekali lagi untuk masing-masing user operator (Kenya, Septy, Niki) jika ingin langsung diisi lewat `seed.sql`. Jika tidak, akun operator bisa dibuat belakangan lewat halaman **Kelola User** di aplikasi (lihat langkah 6).

### 3.4 Edit & jalankan seed.sql

Buka `database/seed.sql`, ganti setiap `REPLACE_WITH_REAL_HASH` dengan hash yang dihasilkan di atas, lalu:

```bash
psql -d r_measurement -f ../database/seed.sql
```

Ini akan membuat 3 operator (Kenya, Septy, Niki) dan 1 akun engineer pertama (`engineer1` secara default, bisa Anda ubah usernamenya langsung di file sebelum dijalankan).

### 3.5 (Opsional) Migrasi data Excel lama, bertahap per sheet/bulan

```bash
cd database
pip install pandas openpyxl psycopg2-binary python-dotenv
cp ../backend/.env .env      # pastikan DATABASE_URL & DB_SCHEMA tersedia di sini juga

python import_excel.py "/path/ke/R-Measurement_Status.xlsx" "March, 2026"
python import_excel.py "/path/ke/R-Measurement_Status.xlsx" "April, 2026"
# ulangi untuk sheet/bulan lain kapan pun Anda siap
```

Baris dengan status **"Cancel"** otomatis dilewati (tidak dimigrasikan).

---

## 4. Menjalankan Backend (FastAPI)

```bash
cd backend
python3 -m venv venv            # lewati jika venv sudah dibuat di langkah 3.3
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
```

Edit file `.env` sesuai environment Anda:

```ini
DATABASE_URL=postgresql+psycopg2://<user>:<password>@<host>:5432/r_measurement
DB_SCHEMA=monitoringmeasurement
JWT_SECRET=ganti_dengan_string_acak_yang_panjang
JWT_ALGORITHM=HS256
JWT_EXPIRES_MINUTES=480
CORS_ORIGIN=http://localhost:5173
```

Jalankan server:

```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

- API akan aktif di `http://localhost:8000`
- Dokumentasi interaktif (Swagger UI) otomatis tersedia di `http://localhost:8000/docs` — berguna untuk tim IT/QA melakukan pengecekan endpoint tanpa perlu frontend
- Health check: `GET http://localhost:8000/api/health` → `{"ok": true}`

---

## 5. Menjalankan Frontend (Vue 3 + Vite)

Buka terminal baru (biarkan backend tetap berjalan):

```bash
cd frontend
npm install

cp .env.example .env
```

Edit `.env` jika alamat backend Anda berbeda:

```ini
VITE_API_URL=http://localhost:8000/api
```

Jalankan dev server:

```bash
npm run dev
```

- Frontend aktif di `http://localhost:5173` (port default Vite)
- Build untuk production: `npm run build` → menghasilkan folder `dist/` (static files, siap diserahkan ke tim infra/Docker Anda)
- Preview hasil build: `npm run preview`

---

## 6. Alur Pemakaian Aplikasi

1. Buka `http://localhost:5173/` → langsung tampil **Dashboard**, **tanpa perlu login** (bisa dilihat siapa saja)
2. Pilih ringkasan per **Day / Week / Month / Year** lewat dropdown di atas
3. Klik menu **"List Measurement"** di navbar → membuka tab baru ke `/measurement-list`
   - Jika belum login, otomatis diarahkan ke halaman **Login**
   - **Role `engineer`**: akses penuh — tambah project baru, edit semua kolom, atur Priority 1-10, dan kelola user lain lewat menu **"Kelola User"**
   - **Role `operator`**: hanya bisa mengubah **Status**, **Operator**, dan tanggal **Actual Start/End** (lihat 6.1)
4. Data pada List Measurement dimuat **per bulan** — gunakan tombol `‹` / `›` di atas tabel untuk berpindah bulan (bisa menampung 200-500+ baris per bulan)
5. Engineer bisa membuat akun baru (operator/engineer) lewat halaman **Kelola User** (`/users`) tanpa perlu akses langsung ke database

### 6.1 Cara kerja List Measurement (tabel satu baris per data)

Tabel default **hanya-baca**. Untuk mengubah data, klik tombol **Edit** (di sebelah **+ Tambah Data**); kolom checkbox muncul di kiri dan bar aksi tampil. Baris bisa dipilih dengan klik checkbox atau klik barisnya. **Batal** keluar dari mode edit.

| Aksi | Engineer | Operator |
|---|---|---|
| **+ Tambah Data** | Membuka **popup** form (Informasi Project, Test & Temperature T1-T7, Assignment & Jadwal) | Tidak tersedia |
| **Edit** (1 baris dipilih) | Popup edit lengkap (termasuk Priority) | Popup Status / Operator / Actual dates |
| **Edit** (banyak baris) | Popup edit massal: Status, Operator, Reliability, Test Stage, Remark, Plan dates, Actual dates | Popup edit massal: Status, Operator, Actual Start/End |
| **Duplikasi** | Menyalin baris terpilih; status direset ke *Measurement Yet*, actual dates dikosongkan, Priority tidak disalin | Tidak tersedia |
| **Finish Measurement** | - | Menandai semua baris terpilih *Finished Measurement* sekaligus |

Catatan:
- Priority (1-10, unik) hanya diatur lewat edit **satu baris** oleh engineer.
- Jumlah baris per halaman: 50 (default), 100, 150, 200, 300.
- Hak akses ditegakkan di backend: operator yang mengirim field terlarang mendapat `403`.

### 6.2 Endpoint terkait

| Method & path | Fungsi | Role |
|---|---|---|
| `PATCH /api/measurements/bulk` | Update banyak baris (`ids` + field) | operator (status, operator, actual dates) / engineer (semua) |
| `POST /api/measurements/duplicate` | Duplikasi baris (`ids`) | engineer |
| `PATCH /api/measurements/{id}/status` | Status + `actual_start`/`actual_end` satu baris | operator, engineer |

---

## 7. Ringkasan Keputusan Desain

| Topik | Keputusan |
|---|---|
| Schema database | `monitoringmeasurement`, bukan `public` (keterbatasan akses IT) |
| Backend | Python + FastAPI (bukan Node.js), dijalankan via `uvicorn` |
| Frontend | Vue 3 + Vite (bukan Vue 2 CLI), dijalankan via `npm run dev` |
| Login | Hanya wajib untuk akses **List Measurement**; Dashboard tetap publik |
| Temperature | 7 kolom terpisah `t1_temp` ... `t7_temp` (bukan array) |
| Penomoran minggu | "CW1, CW2, ..." (ISO calendar week), dipakai di Trend chart (mode Week), Backlog Aging, dan Operator Load |
| Backlog Aging & Operator Load | Selalu berbasis mingguan (CW), tidak mengikuti dropdown Summary per |
| List Measurement | Dimuat per bulan (bisa ratusan baris), navigasi ‹ Bulan Sebelumnya/Berikutnya › |
| Kelola user | Lewat halaman `/users` (role engineer), tidak perlu akses database langsung |
| Export Excel/PDF | Tidak dibuat (sesuai keputusan Anda) |
| Notifikasi priority | Tidak dibuat (akan didiskusikan nanti) |

---

## 8. Deployment (Docker)

Karena tim infra Anda men-deploy lewat Docker, source code ini sudah didesain agar mudah di-container-kan:

- **Backend**: image Python standar (`python:3.11-slim`), install `requirements.txt`, jalankan
  `uvicorn app.main:app --host 0.0.0.0 --port 8000` (tanpa `--reload` di production)
- **Frontend**: build dulu (`npm run build`) menghasilkan folder `dist/` berisi static files murni (HTML/CSS/JS) — bisa disajikan lewat nginx, Caddy, atau image `node` sederhana dengan `vite preview`, tanpa dependensi Node saat runtime jika disajikan lewat nginx

Beri tahu saya jika Anda ingin saya siapkan contoh `Dockerfile` untuk backend & frontend, plus `docker-compose.yml` yang menyatukan keduanya dengan PostgreSQL — supaya tim infra tinggal `docker compose up`.

---

## 9. Troubleshooting Umum

| Gejala | Kemungkinan Penyebab | Solusi |
|---|---|---|
| `psql: permission denied for schema public` saat `schema.sql` | Role DB tidak punya akses `public` — pastikan Anda menjalankan file `schema.sql` versi terbaru ini | Cek ulang isi `database/schema.sql`, pastikan semua `CREATE TABLE` diawali `monitoringmeasurement.` |
| `relation "monitoringmeasurement.measurements" does not exist` | `schema.sql` belum dijalankan, atau dijalankan ke database yang salah | Jalankan ulang `psql -d r_measurement -f database/schema.sql` dan pastikan `DATABASE_URL` di `.env` mengarah ke database yang sama |
| Login selalu gagal walau password benar | Hash password di `seed.sql` belum diganti dari placeholder `REPLACE_WITH_REAL_HASH` | Generate hash dengan `python -m app.utils.hash_password "password"`, update `seed.sql`, jalankan ulang |
| Dashboard blank / gagal fetch data | Backend belum jalan, atau `VITE_API_URL` di frontend `.env` salah | Pastikan `uvicorn` berjalan di port 8000 dan `VITE_API_URL=http://localhost:8000/api` |
| Error CORS di browser console | `CORS_ORIGIN` di backend `.env` tidak cocok dengan alamat frontend | Set `CORS_ORIGIN=http://localhost:5173` (atau domain frontend Anda yang sebenarnya) |
| `ModuleNotFoundError` saat `uvicorn` dijalankan | Virtual environment belum diaktifkan, atau `pip install -r requirements.txt` belum dijalankan | `source venv/bin/activate` lalu `pip install -r requirements.txt` |

---

## 10. Yang Masih Terbuka untuk Didiskusikan

1. Threshold final **Backlog Aging** (belum ditentukan)
2. Apakah perlu contoh `Dockerfile` + `docker-compose.yml`
3. Logo asli untuk halaman login (saat ini masih placeholder di `frontend/src/assets/login-logo.png`)
4. Apakah kolom Plan/Actual Start-End perlu bisa diedit langsung dari tabel List Measurement
