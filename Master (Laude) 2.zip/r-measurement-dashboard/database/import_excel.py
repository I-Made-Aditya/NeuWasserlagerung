"""
Import existing "R-Measurement" Excel sheets into PostgreSQL
(schema: monitoringmeasurement).

Usage:
    python import_excel.py <path-to-file.xlsx> "<Sheet Name>"

Example (import month by month, gradually):
    python import_excel.py ./R-Measurement_Status.xlsx "March, 2026"
    python import_excel.py ./R-Measurement_Status.xlsx "April, 2026"

Requires: pandas, openpyxl, psycopg2-binary, python-dotenv
    pip install pandas openpyxl psycopg2-binary python-dotenv

Notes:
 - Rows with Status = "Cancel" are SKIPPED (not migrated).
 - Status text is normalized to the 3 canonical values.
 - Operator names are normalized against the operators table (case-insensitive).
 - T1..T7 (°C) columns are copied 1:1 into t1_temp..t7_temp.
"""

import os
import sys
import pandas as pd
import psycopg2
from dotenv import load_dotenv

load_dotenv()

SCHEMA = os.getenv("DB_SCHEMA", "monitoringmeasurement")
DATABASE_URL = os.getenv("DATABASE_URL")

STATUS_MAP = {
    "measurement yet": "Measurement Yet",
    "ongoing": "Ongoing",
    "finished measurement": "Finished Measurement",
}


def to_date_or_none(value):
    if pd.isna(value) or value is None or value == "":
        return None
    ts = pd.to_datetime(value, errors="coerce")
    if pd.isna(ts):
        return None
    return ts.date().isoformat()


def get_operator_map(cur):
    cur.execute(f"SELECT id, name FROM {SCHEMA}.operators")
    return {name.strip().lower(): op_id for op_id, name in cur.fetchall()}


def main():
    if len(sys.argv) != 3:
        print('Usage: python import_excel.py <file.xlsx> "<Sheet Name>"')
        sys.exit(1)

    file_path, sheet_name = sys.argv[1], sys.argv[2]

    if not DATABASE_URL:
        print("ERROR: DATABASE_URL is not set (check your .env file)")
        sys.exit(1)

    df = pd.read_excel(file_path, sheet_name=sheet_name)

    conn = psycopg2.connect(DATABASE_URL)
    conn.autocommit = False
    cur = conn.cursor()
    operator_map = get_operator_map(cur)

    inserted = skipped_cancel = skipped_empty = 0
    last_project_nr = None

    insert_sql = f"""
        INSERT INTO {SCHEMA}.measurements
            (date_in, project_nr, lom_nr, part_description, type, qty, test_stage,
             reliability, status, planning_start, planning_end, actual_start, actual_end,
             t1_temp, t2_temp, t3_temp, t4_temp, t5_temp, t6_temp, t7_temp,
             operator_id, remark)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
    """

    for _, row in df.iterrows():
        project_nr = row.get("Project Nr") or last_project_nr
        if not project_nr or pd.isna(project_nr):
            skipped_empty += 1
            continue
        last_project_nr = project_nr

        status_raw = str(row.get("Status") or "").strip().lower()
        if status_raw == "cancel":
            skipped_cancel += 1
            continue
        status = STATUS_MAP.get(status_raw, "Measurement Yet")

        temps = []
        for i in range(1, 8):
            val = row.get(f"T{i} (°C)")
            temps.append(str(val).strip() if pd.notna(val) and val not in (None, "") else None)

        operator_name = str(row.get("Operator") or "").strip().lower()
        operator_id = operator_map.get(operator_name)

        remark_val = row.get("Remark")
        remark = str(remark_val) if pd.notna(remark_val) else None

        qty_val = row.get("Qty")
        qty = int(qty_val) if pd.notna(qty_val) else 0

        cur.execute(insert_sql, (
            to_date_or_none(row.get("Date in")),
            str(project_nr),
            row.get("LOM Nr") if pd.notna(row.get("LOM Nr")) else None,
            row.get("Part Description") if pd.notna(row.get("Part Description")) else None,
            str(row.get("Type")) if pd.notna(row.get("Type")) else None,
            qty,
            row.get("Bf Test / Af Test") if pd.notna(row.get("Bf Test / Af Test")) else None,
            row.get("Reliability") if pd.notna(row.get("Reliability")) else None,
            status,
            to_date_or_none(row.get("Planning")),
            to_date_or_none(row.get("Column1")),
            to_date_or_none(row.get("Actual")),
            to_date_or_none(row.get("Column2")),
            *temps,
            operator_id,
            remark,
        ))
        inserted += 1

    conn.commit()
    cur.close()
    conn.close()

    print(f"Done. Inserted: {inserted}, skipped (Cancel): {skipped_cancel}, skipped (empty row): {skipped_empty}")


if __name__ == "__main__":
    main()
