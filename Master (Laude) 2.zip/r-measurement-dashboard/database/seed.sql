-- =========================================================
-- Seed data - run AFTER schema.sql
-- Generate real bcrypt hashes with:
--   cd backend && python -m app.utils.hash_password "yourpassword"
-- and paste them below before running this file.
-- =========================================================

INSERT INTO monitoringmeasurement.operators (name) VALUES
    ('Kenya'),
    ('Septy'),
    ('Niki');

INSERT INTO monitoringmeasurement.users (username, password_hash, role, operator_id) VALUES
    ('engineer1', '$2b$12$REPLACE_WITH_REAL_HASH', 'engineer', NULL),
    ('kenya',     '$2b$12$REPLACE_WITH_REAL_HASH', 'operator', (SELECT id FROM monitoringmeasurement.operators WHERE name = 'Kenya')),
    ('septy',     '$2b$12$REPLACE_WITH_REAL_HASH', 'operator', (SELECT id FROM monitoringmeasurement.operators WHERE name = 'Septy')),
    ('niki',      '$2b$12$REPLACE_WITH_REAL_HASH', 'operator', (SELECT id FROM monitoringmeasurement.operators WHERE name = 'Niki'));

-- After first login, the engineer account can create further logins
-- via the "Kelola User" page (or POST /api/users), so this seed only
-- needs to bootstrap the very first engineer + the 3 operators.
