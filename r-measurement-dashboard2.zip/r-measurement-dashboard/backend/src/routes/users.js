const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();

// GET /api/users (Engineer only) - list accounts that can access List Measurement
router.get('/', requireAuth, requireRole('engineer'), async (req, res) => {
  const { rows } = await pool.query(
    `SELECT u.id, u.username, u.role, u.active, u.operator_id, o.name AS operator_name, u.created_at
     FROM users u LEFT JOIN operators o ON o.id = u.operator_id
     ORDER BY u.created_at DESC`
  );
  res.json(rows);
});

// POST /api/users (Engineer only) - create a new login (engineer or operator role)
router.post('/', requireAuth, requireRole('engineer'), async (req, res) => {
  const { username, password, role, operator_id } = req.body;
  if (!username || !password || !role) {
    return res.status(400).json({ error: 'username, password, and role are required' });
  }
  if (!['engineer', 'operator'].includes(role)) {
    return res.status(400).json({ error: "role must be 'engineer' or 'operator'" });
  }
  if (role === 'operator' && !operator_id) {
    return res.status(400).json({ error: 'operator_id is required when role is operator' });
  }

  try {
    const hash = await bcrypt.hash(password, 10);
    const { rows } = await pool.query(
      `INSERT INTO users (username, password_hash, role, operator_id, created_by)
       VALUES ($1,$2,$3,$4,$5)
       RETURNING id, username, role, operator_id, active, created_at`,
      [username, hash, role, role === 'operator' ? operator_id : null, req.user.id]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    if (err.code === '23505') return res.status(409).json({ error: 'Username already exists' });
    res.status(500).json({ error: 'Failed to create user' });
  }
});

// PATCH /api/users/:id (Engineer only) - toggle active, change role/operator, reset password
router.patch('/:id', requireAuth, requireRole('engineer'), async (req, res) => {
  const { active, role, operator_id, password } = req.body;
  const sets = [];
  const params = [];
  let i = 1;

  if (active !== undefined) { sets.push(`active = $${i++}`); params.push(active); }
  if (role) { sets.push(`role = $${i++}`); params.push(role); }
  if (operator_id !== undefined) { sets.push(`operator_id = $${i++}`); params.push(operator_id); }
  if (password) {
    const hash = await bcrypt.hash(password, 10);
    sets.push(`password_hash = $${i++}`); params.push(hash);
  }
  if (!sets.length) return res.status(400).json({ error: 'Nothing to update' });

  params.push(req.params.id);
  try {
    const { rows } = await pool.query(
      `UPDATE users SET ${sets.join(', ')} WHERE id = $${i} RETURNING id, username, role, operator_id, active`,
      params
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

module.exports = router;
