const express = require('express');
const pool = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/operators  (dropdown source: Kenya, Septy, Niki)
router.get('/', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    'SELECT id, name FROM operators WHERE active = TRUE ORDER BY name'
  );
  res.json(rows);
});

module.exports = router;
