const express = require('express');
const pool = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');

const router = express.Router();
const STATUSES = ['Measurement Yet', 'Ongoing', 'Finished Measurement'];
const TEMP_FIELDS = ['t1_temp', 't2_temp', 't3_temp', 't4_temp', 't5_temp', 't6_temp', 't7_temp'];

function pickTemps(b) {
  return TEMP_FIELDS.map((f) => (b[f] ? String(b[f]).trim() : null));
}

// ---------------------------------------------------------------
// GET /api/measurements
// Primary mode: ?year=2026&month=8  -> returns ALL rows in that month
//   (List Measurement page loads one month at a time, can be 200-500 rows)
// Fallback mode: generic page/limit pagination (kept for flexibility)
// Filters: status, operator_id, search
// Requires login (List Measurement is only accessible to registered users)
// ---------------------------------------------------------------
router.get('/', requireAuth, async (req, res) => {
  const {
    year, month, status, operator_id, search,
    page = 1, limit = 500,
  } = req.query;

  const conditions = [];
  const params = [];
  let i = 1;

  if (year && month) {
    conditions.push(`EXTRACT(YEAR FROM m.date_in) = $${i++}`);
    params.push(Number(year));
    conditions.push(`EXTRACT(MONTH FROM m.date_in) = $${i++}`);
    params.push(Number(month));
  }
  if (status) { conditions.push(`m.status = $${i++}`); params.push(status); }
  if (operator_id) { conditions.push(`m.operator_id = $${i++}`); params.push(operator_id); }
  if (search) {
    conditions.push(`(m.project_nr ILIKE $${i} OR m.lom_nr ILIKE $${i} OR m.part_description ILIKE $${i} OR m.remark ILIKE $${i})`);
    params.push(`%${search}%`);
    i++;
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const countResult = await pool.query(`SELECT COUNT(*) FROM measurements m ${where}`, params);
    const total = Number(countResult.rows[0].count);

    const offset = (Number(page) - 1) * Number(limit);
    const dataResult = await pool.query(
      `SELECT m.*, o.name AS operator_name
       FROM measurements m
       LEFT JOIN operators o ON o.id = m.operator_id
       ${where}
       ORDER BY m.date_in ASC, m.id ASC
       LIMIT $${i} OFFSET $${i + 1}`,
      [...params, limit, offset]
    );

    // available year range, so the frontend can disable Prev/Next past real data
    const rangeResult = await pool.query(
      `SELECT MIN(date_in) AS min_date, MAX(date_in) AS max_date FROM measurements`
    );

    res.json({
      data: dataResult.rows,
      total,
      range: rangeResult.rows[0],
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch measurements' });
  }
});

// GET /api/measurements/:id
router.get('/:id', requireAuth, async (req, res) => {
  const { rows } = await pool.query(
    `SELECT m.*, o.name AS operator_name FROM measurements m
     LEFT JOIN operators o ON o.id = m.operator_id WHERE m.id = $1`,
    [req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
});

// ---------------------------------------------------------------
// POST /api/measurements (Engineer only)
// ---------------------------------------------------------------
router.post('/', requireAuth, requireRole('engineer'), async (req, res) => {
  const b = req.body;
  if (!b.date_in || !b.project_nr) {
    return res.status(400).json({ error: 'date_in and project_nr are required' });
  }
  const temps = pickTemps(b);
  try {
    const { rows } = await pool.query(
      `INSERT INTO measurements
        (date_in, project_nr, lom_nr, part_description, type, qty, test_stage,
         reliability, status, planning_start, planning_end, actual_start, actual_end,
         t1_temp, t2_temp, t3_temp, t4_temp, t5_temp, t6_temp, t7_temp,
         operator_id, remark, priority, created_by, updated_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$24)
       RETURNING *`,
      [
        b.date_in, b.project_nr, b.lom_nr || null, b.part_description || null,
        b.type || null, b.qty || 0, b.test_stage || null, b.reliability || null,
        STATUSES.includes(b.status) ? b.status : 'Measurement Yet',
        b.planning_start || null, b.planning_end || null,
        b.actual_start || null, b.actual_end || null,
        ...temps,
        b.operator_id || null, b.remark || null, b.priority || null,
        req.user.id,
      ]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    if (err.code === '23505') return res.status(409).json({ error: 'Priority number already used' });
    res.status(500).json({ error: 'Failed to create measurement' });
  }
});

// ---------------------------------------------------------------
// PUT /api/measurements/:id (Engineer only - full update)
// ---------------------------------------------------------------
router.put('/:id', requireAuth, requireRole('engineer'), async (req, res) => {
  const b = req.body;
  const temps = pickTemps(b);
  try {
    const { rows } = await pool.query(
      `UPDATE measurements SET
        date_in=$1, project_nr=$2, lom_nr=$3, part_description=$4, type=$5, qty=$6,
        test_stage=$7, reliability=$8, status=$9, planning_start=$10, planning_end=$11,
        actual_start=$12, actual_end=$13,
        t1_temp=$14, t2_temp=$15, t3_temp=$16, t4_temp=$17, t5_temp=$18, t6_temp=$19, t7_temp=$20,
        operator_id=$21, remark=$22, priority=$23, updated_by=$24
       WHERE id=$25 RETURNING *`,
      [
        b.date_in, b.project_nr, b.lom_nr || null, b.part_description || null,
        b.type || null, b.qty || 0, b.test_stage || null, b.reliability || null,
        STATUSES.includes(b.status) ? b.status : 'Measurement Yet',
        b.planning_start || null, b.planning_end || null,
        b.actual_start || null, b.actual_end || null,
        ...temps,
        b.operator_id || null, b.remark || null, b.priority || null,
        req.user.id, req.params.id,
      ]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    if (err.code === '23505') return res.status(409).json({ error: 'Priority number already used' });
    res.status(500).json({ error: 'Failed to update measurement' });
  }
});

// ---------------------------------------------------------------
// PATCH /api/measurements/:id/status
// Operator role: may only change status + operator_id.
// ---------------------------------------------------------------
router.patch('/:id/status', requireAuth, requireRole('engineer', 'operator'), async (req, res) => {
  const { status, operator_id } = req.body;
  if (status && !STATUSES.includes(status)) {
    return res.status(400).json({ error: `status must be one of: ${STATUSES.join(', ')}` });
  }
  try {
    const { rows } = await pool.query(
      `UPDATE measurements SET
        status = COALESCE($1, status),
        operator_id = COALESCE($2, operator_id),
        updated_by = $3
       WHERE id = $4 RETURNING *`,
      [status || null, operator_id || null, req.user.id, req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update status' });
  }
});

// PATCH /api/measurements/:id/priority (Engineer only)
router.patch('/:id/priority', requireAuth, requireRole('engineer'), async (req, res) => {
  const { priority } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE measurements SET priority = $1, updated_by = $2 WHERE id = $3 RETURNING *`,
      [priority || null, req.user.id, req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    if (err.code === '23505') return res.status(409).json({ error: 'Priority number already used, choose another (1-10)' });
    res.status(500).json({ error: 'Failed to update priority' });
  }
});

// DELETE /api/measurements/:id (Engineer only)
router.delete('/:id', requireAuth, requireRole('engineer'), async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM measurements WHERE id = $1', [req.params.id]);
  if (!rowCount) return res.status(404).json({ error: 'Not found' });
  res.status(204).send();
});

module.exports = router;
