const express = require('express');
const pool = require('../db');
const { validatePeriod, currentPeriodRange, PERIOD_TRUNC } = require('../utils/period');

const router = express.Router();
const STATUSES = ['Measurement Yet', 'Ongoing', 'Finished Measurement'];

// NOTE: Dashboard is publicly viewable (no login required) per requirement -
// only the "List Measurement" page and its write endpoints need auth.

// ---------------------------------------------------------------
// GET /api/dashboard/summary?period=week
// ---------------------------------------------------------------
router.get('/summary', async (req, res) => {
  const period = validatePeriod(req.query.period);
  const [start, end] = currentPeriodRange(period);

  try {
    const { rows } = await pool.query(
      `SELECT
         COUNT(DISTINCT project_nr) AS project_count,
         COALESCE(SUM(temp_slot) FILTER (WHERE status = 'Measurement Yet'), 0) AS measurement_yet,
         COALESCE(SUM(temp_slot) FILTER (WHERE status = 'Ongoing'), 0) AS ongoing,
         COALESCE(SUM(temp_slot) FILTER (WHERE status = 'Finished Measurement'), 0) AS finished,
         COALESCE(SUM(temp_slot), 0) AS temp_slot_total
       FROM measurements
       WHERE date_in >= $1 AND date_in < $2`,
      [start, end]
    );
    res.json({ period, range: { start, end }, ...rows[0] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load summary' });
  }
});

// ---------------------------------------------------------------
// GET /api/dashboard/trend?period=week&buckets=12
// Combo (bar+line) data: temp slot volume grouped by the chosen period.
// When period = 'week', the frontend renders labels as "CW1", "CW2", ...
// ---------------------------------------------------------------
router.get('/trend', async (req, res) => {
  const period = validatePeriod(req.query.period);
  const trunc = PERIOD_TRUNC[period];
  const buckets = Math.min(Number(req.query.buckets) || 12, 52);

  try {
    const { rows } = await pool.query(
      `SELECT date_trunc($1, date_in) AS bucket,
              COALESCE(SUM(temp_slot), 0) AS temp_slot_total,
              COALESCE(SUM(qty), 0) AS qty_total
       FROM measurements
       WHERE date_in >= (CURRENT_DATE - ($2 || ' ' || $1 || 's')::interval)
       GROUP BY bucket
       ORDER BY bucket`,
      [trunc, buckets]
    );
    res.json({ period, series: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load trend' });
  }
});

// ---------------------------------------------------------------
// GET /api/dashboard/workload-temperature?status=Measurement Yet
// Stacked bar: qty per temperature, broken down by project (top 12 + "Others")
// so a tooltip can show "at R25: Project A = 40, Project B = 20, ..."
// ---------------------------------------------------------------
router.get('/workload-temperature', async (req, res) => {
  const status = STATUSES.includes(req.query.status) ? req.query.status : 'Measurement Yet';

  try {
    const { rows } = await pool.query(
      `SELECT project_nr, qty, t1_temp AS temp FROM measurements WHERE status = $1 AND t1_temp IS NOT NULL AND t1_temp <> ''
       UNION ALL SELECT project_nr, qty, t2_temp FROM measurements WHERE status = $1 AND t2_temp IS NOT NULL AND t2_temp <> ''
       UNION ALL SELECT project_nr, qty, t3_temp FROM measurements WHERE status = $1 AND t3_temp IS NOT NULL AND t3_temp <> ''
       UNION ALL SELECT project_nr, qty, t4_temp FROM measurements WHERE status = $1 AND t4_temp IS NOT NULL AND t4_temp <> ''
       UNION ALL SELECT project_nr, qty, t5_temp FROM measurements WHERE status = $1 AND t5_temp IS NOT NULL AND t5_temp <> ''
       UNION ALL SELECT project_nr, qty, t6_temp FROM measurements WHERE status = $1 AND t6_temp IS NOT NULL AND t6_temp <> ''
       UNION ALL SELECT project_nr, qty, t7_temp FROM measurements WHERE status = $1 AND t7_temp IS NOT NULL AND t7_temp <> ''`,
      [status]
    );

    const tempMap = {};      // temp -> { project_nr: qtySum }
    const projectTotals = {}; // project_nr -> qtySum (to find top projects)

    rows.forEach((r) => {
      const t = r.temp;
      const qty = Number(r.qty) || 0;
      tempMap[t] = tempMap[t] || {};
      tempMap[t][r.project_nr] = (tempMap[t][r.project_nr] || 0) + qty;
      projectTotals[r.project_nr] = (projectTotals[r.project_nr] || 0) + qty;
    });

    const temperatures = Object.keys(tempMap).sort(
      (a, b) => parseFloat(a.replace(/[^-\d.]/g, '')) - parseFloat(b.replace(/[^-\d.]/g, ''))
    );

    const TOP_N = 12;
    const topProjects = Object.entries(projectTotals)
      .sort((a, b) => b[1] - a[1])
      .slice(0, TOP_N)
      .map(([p]) => p);

    const series = topProjects.map((p) => ({
      project: p,
      values: temperatures.map((t) => tempMap[t][p] || 0),
    }));

    const othersValues = temperatures.map((t) => {
      let sum = 0;
      Object.keys(tempMap[t]).forEach((p) => {
        if (!topProjects.includes(p)) sum += tempMap[t][p];
      });
      return sum;
    });
    if (othersValues.some((v) => v > 0)) {
      series.push({ project: 'Others', values: othersValues });
    }

    res.json({ status, temperatures, series });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load workload temperature' });
  }
});

// ---------------------------------------------------------------
// GET /api/dashboard/top-project-load?period=week&limit=10
// ---------------------------------------------------------------
router.get('/top-project-load', async (req, res) => {
  const period = validatePeriod(req.query.period);
  const [start, end] = currentPeriodRange(period);
  const limit = Math.min(Number(req.query.limit) || 10, 50);

  try {
    const { rows } = await pool.query(
      `SELECT project_nr, SUM(qty) AS qty, SUM(temp_slot) AS temp_slot
       FROM measurements
       WHERE date_in >= $1 AND date_in < $2
       GROUP BY project_nr
       ORDER BY qty DESC
       LIMIT $3`,
      [start, end, limit]
    );
    res.json({ period, data: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load top project load' });
  }
});

// ---------------------------------------------------------------
// GET /api/dashboard/backlog-aging-trend
// Bar chart, ALWAYS weekly (CW) regardless of the period selector.
// X = Calendar Week, Y = qty still open (Measurement Yet + Ongoing)
// ---------------------------------------------------------------
router.get('/backlog-aging-trend', async (req, res) => {
  const weeks = Math.min(Number(req.query.weeks) || 12, 52);
  try {
    const { rows } = await pool.query(
      `SELECT date_trunc('week', date_in) AS week_start,
              COALESCE(SUM(qty), 0) AS qty,
              COUNT(*) AS lines
       FROM measurements
       WHERE status IN ('Measurement Yet', 'Ongoing')
         AND date_in >= (CURRENT_DATE - ($1 || ' weeks')::interval)
       GROUP BY week_start
       ORDER BY week_start`,
      [weeks]
    );
    res.json({ data: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load backlog aging trend' });
  }
});

// ---------------------------------------------------------------
// GET /api/dashboard/operator-load-trend
// Line/scatter chart, ALWAYS weekly (CW) regardless of the period selector.
// One series per operator: X = Calendar Week, Y = open temp slot
// ---------------------------------------------------------------
router.get('/operator-load-trend', async (req, res) => {
  const weeks = Math.min(Number(req.query.weeks) || 12, 52);
  try {
    const { rows } = await pool.query(
      `SELECT o.name AS operator_name,
              date_trunc('week', m.date_in) AS week_start,
              COALESCE(SUM(m.temp_slot), 0) AS temp_slot
       FROM operators o
       LEFT JOIN measurements m
         ON m.operator_id = o.id
         AND m.status != 'Finished Measurement'
         AND m.date_in >= (CURRENT_DATE - ($1 || ' weeks')::interval)
       WHERE o.active = TRUE
       GROUP BY o.name, week_start
       ORDER BY week_start`,
      [weeks]
    );
    res.json({ data: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load operator load trend' });
  }
});

// ---------------------------------------------------------------
// GET /api/dashboard/top-priority
// ---------------------------------------------------------------
router.get('/top-priority', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT priority AS nr, project_nr, part_description AS desc, remark
       FROM measurements
       WHERE priority IS NOT NULL
       ORDER BY priority ASC
       LIMIT 10`
    );
    res.json({ data: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to load priority list' });
  }
});

module.exports = router;
