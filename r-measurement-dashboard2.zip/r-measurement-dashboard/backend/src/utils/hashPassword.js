/**
 * Usage: node src/utils/hashPassword.js "yourpassword"
 * Copy the printed hash into database/seed.sql
 */
const bcrypt = require('bcrypt');

const plain = process.argv[2];
if (!plain) {
  console.error('Usage: node hashPassword.js "yourpassword"');
  process.exit(1);
}

bcrypt.hash(plain, 10).then((hash) => {
  console.log(hash);
});
