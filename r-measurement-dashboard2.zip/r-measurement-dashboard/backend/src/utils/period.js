/**
 * Maps the dashboard "period" selector (Day / Week / Month / Year) to:
 *  - a Postgres date_trunc unit, for grouping trend data
 *  - a default lookback window, for the summary cards / current period
 */
const PERIOD_TRUNC = {
  day: 'day',
  week: 'week',
  month: 'month',
  year: 'year',
};

function validatePeriod(period) {
  const p = (period || 'week').toLowerCase();
  return PERIOD_TRUNC[p] ? p : 'week';
}

/**
 * Returns [startDate, endDate] (inclusive) covering the CURRENT period
 * (e.g. current ISO week, current month) anchored on `refDate` (default: today).
 */
function currentPeriodRange(period, refDate = new Date()) {
  const p = validatePeriod(period);
  const start = new Date(refDate);

  if (p === 'day') {
    // just today
  } else if (p === 'week') {
    const day = (start.getDay() + 6) % 7; // Monday = 0
    start.setDate(start.getDate() - day);
  } else if (p === 'month') {
    start.setDate(1);
  } else if (p === 'year') {
    start.setMonth(0, 1);
  }
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  if (p === 'day') end.setDate(end.getDate() + 1);
  else if (p === 'week') end.setDate(end.getDate() + 7);
  else if (p === 'month') end.setMonth(end.getMonth() + 1);
  else if (p === 'year') end.setFullYear(end.getFullYear() + 1);

  return [start.toISOString().slice(0, 10), end.toISOString().slice(0, 10)];
}

module.exports = { validatePeriod, currentPeriodRange, PERIOD_TRUNC };
