# R-Measurement Dashboard (v2)

Sistem digitalisasi tracking measurement untuk station **R-Measurement**.
Stack: **Vue 2 (JS, no TypeScript, no Tailwind)** + **Node.js / Express** + **PostgreSQL**.

## Struktur folder

```
r-measurement-dashboard/
├── database/
│   ├── schema.sql          # DDL: operators, users, measurements (T1-T7 kolom terpisah)
│   ├── seed.sql            # seed operator (Kenya, Septy, Niki) + user pertama
│   └── import_excel.js     # migrasi bertahap dari file Excel lama
├── backend/                # REST API (Express + JWT + pg)
└── frontend/                # Vue CLI app (Dashboard publik + List Measurement login-only)
```

## 1. Setup Database

```bash
createdb r_measurement
psql -d r_measurement -f database/schema.sql

cd backend
npm install
node src/utils/hashPassword.js "passwordEngineer"
# tempel hash-nya ke database/seed.sql, lalu:
psql -d r_measurement -f ../database/seed.sql
```

Setelah login pertama, akun **engineer** bisa membuat akun lain (operator/engineer)
langsung dari halaman **Kelola User** di aplikasi (`/users`) — tidak perlu edit `seed.sql` lagi.

## 2. Migrasi data Excel lama (bertahap, per sheet/bulan)

```bash
cd database
node import_excel.js "/path/ke/R-Measurement_Status.xlsx" "March, 2026"
node import_excel.js "/path/ke/R-Measurement_Status.xlsx" "April, 2026"
```
Baris berstatus **"Cancel"** otomatis dilewati.

## 3. Jalankan Backend

```bash
cd backend
cp .env.example .env    # isi DATABASE_URL, JWT_SECRET, CORS_ORIGIN
npm install
npm run dev              # http://localhost:4000
```

## 4. Jalankan Frontend

```bash
cd frontend
cp .env.example .env
npm install
npm run serve             # http://localhost:8080
```

---

## Revisi v2 (berdasarkan hasil review Anda)

### Dashboard
| # | Revisi | Implementasi |
|---|---|---|
| 1 | Login hanya untuk List Measurement, dashboard tetap publik | Semua endpoint `/api/dashboard/*` sekarang **tanpa auth**. Endpoint `/api/measurements*` dan `/api/users*` tetap wajib login |
| 2 | Operator Load → chart, bukan tabel | Diganti **multi-line chart** (`MultiLineChart.vue`), X = Calendar Week, Y = Temp Slot, 1 garis per operator |
| 3 | Penyebutan minggu pakai "CW1, CW2, ..." | Helper `frontend/src/utils/cw.js` menghitung ISO calendar week; dipakai di Trend chart (saat period=Week) & Backlog/Operator chart |
| 4 | Workload Temperature perlu filter status | Ditambah dropdown status (Measurement Yet / Ongoing / Finished Measurement) di atas chart, memanggil ulang `/api/dashboard/workload-temperature?status=...` |
| 5 | Backlog Aging → chart bar, X=CW, Y=Qty | Endpoint baru `/api/dashboard/backlog-aging-trend`, selalu mingguan (CW) — **tidak** ikut dropdown Summary per |
| 6 | Operator Load → line/scatter chart, X=CW, Y=Temp Slot | Endpoint baru `/api/dashboard/operator-load-trend`, selalu mingguan (CW), tidak ikut dropdown Summary per |
| 7 | Urutan section diubah | Card Summary → Tren → Top Priority → (Workload Temp + Top Project Load) → (Backlog Aging + Operator Load) |
| 8 | Tren jadi combo chart (bar+line); Workload Temperature jadi stacked bar dgn tooltip per-project | `ComboChart.vue` (bar+line gabungan) & `StackedBarChart.vue` (stacked per project, tooltip menampilkan total & breakdown project) |
| — | Visual look & feel | Redesign penuh `main.css`: gradient topbar, kartu dengan ikon & shadow-hover, warna lebih segar, radius lebih besar |

### List Measurement
| # | Revisi | Implementasi |
|---|---|---|
| 1 | Temperature tetap 7 kolom terpisah (T1..T7), bukan array | Kolom DB `temperatures TEXT[]` diganti jadi `t1_temp ... t7_temp VARCHAR(20)`. `temp_slot` dihitung dari jumlah kolom T yang terisi × qty |
| 2 | Load per bulan (bisa 200-500 baris), bukan pagination generik | `GET /api/measurements?year=&month=` mengembalikan **semua baris** dalam bulan tsb. UI punya tombol navigasi ‹ Bulan Berikutnya/Sebelumnya › |
| 3 | Tampilan tabel mengikuti referensi (sortable header, search, badge, pagination "Show N entries") | Tabel baru dengan sort klik-header, search box, badge status berwarna, kolom Project Nr/LOM Nr ditonjolkan, "Showing X to Y of Z items" + pagination bergaya seperti referensi |

### Lainnya
- Ditambahkan halaman **Kelola User** (`/users`, khusus role engineer) supaya akun operator/engineer baru bisa dibuat langsung dari UI (sesuai permintaan "user dibikinkan username & password oleh pihak kita")
- Backlog Aging threshold **belum ditentukan final** (Anda sebutkan akan menentukan kemudian) — saat ini backend masih mengelompokkan berdasarkan status terbuka per Calendar Week, siap disesuaikan begitu threshold final ditentukan
- Fitur export Excel/PDF: **tidak dibuat** (sesuai keputusan Anda)
- Notifikasi priority: **tidak dibuat** (akan didiskusikan nanti)
- Karena deployment akan dilakukan via Docker oleh tim Anda: source code ini murni Node.js + Vue statis, tanpa dependensi khusus platform, jadi tinggal di-dockerize dengan `Dockerfile` standar Node (backend) & static build (frontend, `npm run build` menghasilkan folder `dist/`) — beri tahu saya jika Anda ingin saya siapkan `Dockerfile` & `docker-compose.yml` contohnya.

## Yang masih terbuka untuk didiskusikan
1. Threshold **Backlog Aging** final (kapan Anda sudah menentukan)
2. Apakah perlu `Dockerfile` + `docker-compose.yml` contoh untuk memudahkan tim infra Anda
3. Apakah kolom `Actual Start/End` & `Plan Start/End` di List Measurement perlu bisa diedit langsung dari tabel (saat ini hanya bisa diisi lewat form tambah project / edit penuh oleh engineer)
