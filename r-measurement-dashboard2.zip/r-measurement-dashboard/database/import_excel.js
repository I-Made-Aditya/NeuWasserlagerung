/**
 * Import existing "R-Measurement" Excel sheets into PostgreSQL.
 *
 * Usage:
 *   node import_excel.js <path-to-file.xlsx> "<Sheet Name>"
 *
 * Notes:
 *  - Rows with Status = "Cancel" are SKIPPED (not migrated).
 *  - Status text is normalized to the 3 canonical values.
 *  - Operator names are normalized against the `operators` table (case-insensitive).
 *  - T1..T7 (°C) columns are copied 1:1 into t1_temp..t7_temp.
 */

const XLSX = require('xlsx');
const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const STATUS_MAP = {
  'measurement yet': 'Measurement Yet',
  'ongoing': 'Ongoing',
  'finished measurement': 'Finished Measurement',
};

async function getOperatorMap() {
  const { rows } = await pool.query('SELECT id, name FROM operators');
  const map = {};
  rows.forEach((r) => { map[r.name.trim().toLowerCase()] = r.id; });
  return map;
}

function toDateOrNull(v) {
  if (!v) return null;
  const d = v instanceof Date ? v : new Date(v);
  return isNaN(d.getTime()) ? null : d.toISOString().slice(0, 10);
}

async function run() {
  const [, , filePath, sheetName] = process.argv;
  if (!filePath || !sheetName) {
    console.error('Usage: node import_excel.js <file.xlsx> "<Sheet Name>"');
    process.exit(1);
  }

  const wb = XLSX.readFile(filePath, { cellDates: true });
  const ws = wb.Sheets[sheetName];
  if (!ws) {
    console.error(`Sheet "${sheetName}" not found. Available: ${wb.SheetNames.join(', ')}`);
    process.exit(1);
  }

  const rows = XLSX.utils.sheet_to_json(ws, { defval: null });
  const operatorMap = await getOperatorMap();

  let inserted = 0, skippedCancel = 0, skippedEmpty = 0, lastProjectNr = null;

  for (const row of rows) {
    const projectNr = row['Project Nr'] || lastProjectNr;
    if (!projectNr) { skippedEmpty++; continue; }
    lastProjectNr = projectNr;

    const statusRaw = (row['Status'] || '').toString().trim().toLowerCase();
    if (statusRaw === 'cancel') { skippedCancel++; continue; }
    const status = STATUS_MAP[statusRaw] || 'Measurement Yet';

    const temps = [1, 2, 3, 4, 5, 6, 7].map((i) => {
      const val = row[`T${i} (°C)`];
      return val ? String(val).trim() : null;
    });

    const operatorName = (row['Operator'] || '').toString().trim().toLowerCase();
    const operatorId = operatorMap[operatorName] || null;

    await pool.query(
      `INSERT INTO measurements
        (date_in, project_nr, lom_nr, part_description, type, qty, test_stage,
         reliability, status, planning_start, planning_end, actual_start, actual_end,
         t1_temp, t2_temp, t3_temp, t4_temp, t5_temp, t6_temp, t7_temp,
         operator_id, remark)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22)`,
      [
        toDateOrNull(row['Date in']),
        projectNr,
        row['LOM Nr'] || null,
        row['Part Description'] || null,
        row['Type'] != null ? String(row['Type']) : null,
        Number(row['Qty']) || 0,
        row['Bf Test / Af Test'] || null,
        row['Reliability'] || null,
        status,
        toDateOrNull(row['Planning']),
        toDateOrNull(row['Column1']),
        toDateOrNull(row['Actual']),
        toDateOrNull(row['Column2']),
        ...temps,
        operatorId,
        (row['Remark'] && typeof row['Remark'] !== 'object') ? String(row['Remark']) : null,
      ]
    );
    inserted++;
  }

  console.log(`Done. Inserted: ${inserted}, skipped (Cancel): ${skippedCancel}, skipped (empty row): ${skippedEmpty}`);
  await pool.end();
}

run().catch((err) => { console.error(err); process.exit(1); });
