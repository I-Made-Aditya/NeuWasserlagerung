-- =========================================================
-- Seed data - run AFTER schema.sql
-- Generate real bcrypt hashes with:
--   node backend/src/utils/hashPassword.js "yourpassword"
-- and paste them below before running this file.
-- =========================================================

INSERT INTO operators (name) VALUES
    ('Kenya'),
    ('Septy'),
    ('Niki');

INSERT INTO users (username, password_hash, role, operator_id) VALUES
    ('engineer1', '$2b$10$REPLACE_WITH_REAL_HASH', 'engineer', NULL),
    ('kenya',     '$2b$10$REPLACE_WITH_REAL_HASH', 'operator', (SELECT id FROM operators WHERE name = 'Kenya')),
    ('septy',     '$2b$10$REPLACE_WITH_REAL_HASH', 'operator', (SELECT id FROM operators WHERE name = 'Septy')),
    ('niki',      '$2b$10$REPLACE_WITH_REAL_HASH', 'operator', (SELECT id FROM operators WHERE name = 'Niki'));

-- NOTE: after first login, the engineer account can create/manage further
-- logins via POST /api/users (see backend/src/routes/users.js), so this
-- seed only needs to bootstrap the very first engineer + the 3 operators.
