-- =========================================================
-- R-Measurement Dashboard - PostgreSQL Schema (v2)
-- Revisions:
--  - Temperatures split back into T1..T7 columns (max 7), not an array
--  - users table: active flag + created_by (engineer who created the login)
--  - Dashboard is public; List Measurement requires login (enforced in backend)
-- =========================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ---------------------------------------------------------
-- OPERATORS (dropdown master data: Kenya, Septy, Niki)
-- ---------------------------------------------------------
CREATE TABLE operators (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    active      BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------
-- USERS (login required ONLY for List Measurement page)
--   role = 'engineer' -> full access (create/edit all fields, manage users)
--   role = 'operator' -> may only change Status + Operator column
-- ---------------------------------------------------------
CREATE TABLE users (
    id            SERIAL PRIMARY KEY,
    username      VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          VARCHAR(20)  NOT NULL CHECK (role IN ('engineer', 'operator')),
    operator_id   INTEGER REFERENCES operators(id),
    active        BOOLEAN NOT NULL DEFAULT TRUE,
    created_by    INTEGER REFERENCES users(id),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------
-- MEASUREMENTS (the main "R-Measurement" list)
-- ---------------------------------------------------------
CREATE TYPE measurement_status AS ENUM (
    'Measurement Yet',
    'Ongoing',
    'Finished Measurement'
);

CREATE TABLE measurements (
    id                SERIAL PRIMARY KEY,

    date_in           DATE NOT NULL,
    project_nr        VARCHAR(50) NOT NULL,
    lom_nr            VARCHAR(50),
    part_description  TEXT,
    type              VARCHAR(50),
    qty               INTEGER NOT NULL DEFAULT 0,
    test_stage        VARCHAR(100),
    reliability       VARCHAR(150),

    status            measurement_status NOT NULL DEFAULT 'Measurement Yet',

    planning_start    DATE,
    planning_end      DATE,
    actual_start      DATE,
    actual_end        DATE,

    -- Temperatures kept as 7 discrete columns (per user's preference)
    t1_temp           VARCHAR(20),
    t2_temp           VARCHAR(20),
    t3_temp           VARCHAR(20),
    t4_temp           VARCHAR(20),
    t5_temp           VARCHAR(20),
    t6_temp           VARCHAR(20),
    t7_temp           VARCHAR(20),

    operator_id       INTEGER REFERENCES operators(id),
    remark            TEXT,

    priority          SMALLINT CHECK (priority IS NULL OR (priority BETWEEN 1 AND 10)),

    created_by        INTEGER REFERENCES users(id),
    updated_by        INTEGER REFERENCES users(id),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX uniq_priority_when_set
    ON measurements (priority)
    WHERE priority IS NOT NULL;

CREATE INDEX idx_measurements_date_in   ON measurements (date_in);
CREATE INDEX idx_measurements_status    ON measurements (status);
CREATE INDEX idx_measurements_operator  ON measurements (operator_id);
CREATE INDEX idx_measurements_project   ON measurements (project_nr);
CREATE INDEX idx_measurements_year_month ON measurements (date_part('year', date_in), date_part('month', date_in));

-- temp_slot = qty * (number of T1..T7 columns actually filled in)
ALTER TABLE measurements
    ADD COLUMN temp_slot INTEGER GENERATED ALWAYS AS (
        qty * (
            (t1_temp IS NOT NULL AND t1_temp <> '')::int +
            (t2_temp IS NOT NULL AND t2_temp <> '')::int +
            (t3_temp IS NOT NULL AND t3_temp <> '')::int +
            (t4_temp IS NOT NULL AND t4_temp <> '')::int +
            (t5_temp IS NOT NULL AND t5_temp <> '')::int +
            (t6_temp IS NOT NULL AND t6_temp <> '')::int +
            (t7_temp IS NOT NULL AND t7_temp <> '')::int
        )
    ) STORED;

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_measurements_updated_at
    BEFORE UPDATE ON measurements
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();
