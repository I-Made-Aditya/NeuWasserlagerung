/**
 * ISO-8601 calendar week helpers.
 * "CW1" = the first calendar week of the year, "CW2" = second, etc.
 */
export function getCalendarWeek(dateInput) {
  const d = new Date(Date.UTC(
    new Date(dateInput).getFullYear(),
    new Date(dateInput).getMonth(),
    new Date(dateInput).getDate()
  ));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

export function toCWLabel(dateInput) {
  return `CW${getCalendarWeek(dateInput)}`;
}

/**
 * Formats a bucket label based on the selected summary period.
 * week -> "CW32", month -> "Aug 2026", year -> "2026", day -> "27 Aug"
 */
export function formatBucketLabel(dateInput, period) {
  const d = new Date(dateInput);
  if (period === 'week') return toCWLabel(d);
  if (period === 'month') return d.toLocaleDateString('id-ID', { month: 'short', year: 'numeric' });
  if (period === 'year') return String(d.getFullYear());
  return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
}
