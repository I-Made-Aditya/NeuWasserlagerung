import Vue from 'vue';
import http from '../api/http';

const state = Vue.observable({
  user: JSON.parse(localStorage.getItem('rm_user') || 'null'),
  token: localStorage.getItem('rm_token') || null,
});

export default {
  state,
  get isLoggedIn() {
    return !!state.token;
  },
  get isEngineer() {
    return state.user && state.user.role === 'engineer';
  },
  async login(username, password) {
    const { data } = await http.post('/auth/login', { username, password });
    state.token = data.token;
    state.user = data.user;
    localStorage.setItem('rm_token', data.token);
    localStorage.setItem('rm_user', JSON.stringify(data.user));
  },
  logout() {
    state.token = null;
    state.user = null;
    localStorage.removeItem('rm_token');
    localStorage.removeItem('rm_user');
  },
};
