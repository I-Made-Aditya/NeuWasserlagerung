import axios from 'axios';

const http = axios.create({
  baseURL: process.env.VUE_APP_API_URL || 'http://localhost:4000/api',
});

http.interceptors.request.use((config) => {
  const token = localStorage.getItem('rm_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

http.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response && err.response.status === 401) {
      localStorage.removeItem('rm_token');
      localStorage.removeItem('rm_user');
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  }
);

export default http;
