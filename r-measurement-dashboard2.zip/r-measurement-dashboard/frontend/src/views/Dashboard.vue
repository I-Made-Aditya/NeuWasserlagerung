<template>
  <div class="app-shell">
    <div class="topbar">
      <div class="brand">
        <span class="brand-dot"></span>
        <h1>R-Measurement Dashboard</h1>
      </div>
      <div class="nav-links">
        <router-link to="/measurement-list" target="_blank">List Measurement</router-link>
        <router-link v-if="!isLoggedIn" to="/login">Login</router-link>
        <a v-else href="#" @click.prevent="logout">Logout ({{ userName }})</a>
      </div>
    </div>

    <div class="page">
      <div class="toolbar">
        <div class="period-select">
          <label>Summary per</label>
          <select v-model="period" @change="loadAll">
            <option value="day">Day</option>
            <option value="week">Week</option>
            <option value="month">Month</option>
            <option value="year">Year</option>
          </select>
        </div>
      </div>

      <!-- ============ 1. SUMMARY CARDS ============ -->
      <div class="card-row">
        <StatCard label="Project" :value="summary.project_count" icon="📁" />
        <StatCard label="Measurement Yet" :value="summary.measurement_yet" variant="yet" icon="⏳" />
        <StatCard label="Ongoing" :value="summary.ongoing" variant="ongoing" icon="⚙️" />
        <StatCard label="Finished" :value="summary.finished" variant="finished" icon="✅" />
        <StatCard label="Temp Slot" :value="summary.temp_slot_total" icon="🌡️" />
      </div>

      <!-- ============ 2. TREND (combo bar+line) ============ -->
      <div class="panel">
        <h3>Tren R-Measurement (Temp Slot) per {{ periodLabel }}</h3>
        <ComboChart :labels="trend.labels" :data="trend.values" label="Temp Slot" />
      </div>

      <!-- ============ 3. TOP PRIORITY ============ -->
      <div class="panel">
        <div class="panel-header">
          <h3>🔥 Top List High Priority</h3>
        </div>
        <table>
          <thead><tr><th style="width:60px;">Nr</th><th>Project / Desc</th><th>Remark</th></tr></thead>
          <tbody>
            <tr v-for="row in topPriority" :key="row.nr">
              <td><span class="priority-badge">{{ row.nr }}</span></td>
              <td><strong>{{ row.project_nr }}</strong> <span class="muted">— {{ row.desc }}</span></td>
              <td>{{ row.remark || '-' }}</td>
            </tr>
            <tr v-if="!topPriority.length"><td colspan="3" class="empty-row">Belum ada project priority</td></tr>
          </tbody>
        </table>
      </div>

      <!-- ============ 4. WORKLOAD TEMP + TOP PROJECT LOAD ============ -->
      <div class="panel-row">
        <div class="panel">
          <div class="panel-header">
            <h3>Workload Temperature</h3>
            <select v-model="workloadStatus" @change="loadWorkloadTemp">
              <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
            </select>
          </div>
          <StackedBarChart :labels="workloadTemp.labels" :series="workloadTemp.series" />
        </div>
        <div class="panel">
          <h3>Top Project Load</h3>
          <BarChart :labels="topProject.labels" :data="topProject.values" label="Qty" horizontal color="#2563eb" />
        </div>
      </div>

      <!-- ============ 5. BACKLOG AGING + OPERATOR LOAD (fixed to CW) ============ -->
      <div class="panel-row">
        <div class="panel">
          <h3>Backlog Aging <span class="muted-sm">(belum Finished, per CW)</span></h3>
          <BarChart :labels="backlogTrend.labels" :data="backlogTrend.values" label="Qty" color="#e0554f" />
        </div>
        <div class="panel">
          <h3>Operator Load <span class="muted-sm">(open work, per CW)</span></h3>
          <MultiLineChart :labels="operatorTrend.labels" :series="operatorTrend.series" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import http from '../api/http';
import auth from '../store/auth';
import { formatBucketLabel, toCWLabel } from '../utils/cw';
import StatCard from '../components/StatCard.vue';
import ComboChart from '../components/ComboChart.vue';
import BarChart from '../components/BarChart.vue';
import StackedBarChart from '../components/StackedBarChart.vue';
import MultiLineChart from '../components/MultiLineChart.vue';

const STATUSES = ['Measurement Yet', 'Ongoing', 'Finished Measurement'];

export default {
  name: 'Dashboard',
  components: { StatCard, ComboChart, BarChart, StackedBarChart, MultiLineChart },
  data() {
    return {
      STATUSES,
      period: 'week',
      workloadStatus: 'Measurement Yet',
      summary: { project_count: 0, measurement_yet: 0, ongoing: 0, finished: 0, temp_slot_total: 0 },
      trend: { labels: [], values: [] },
      workloadTemp: { labels: [], series: [] },
      topProject: { labels: [], values: [] },
      backlogTrend: { labels: [], values: [] },
      operatorTrend: { labels: [], series: [] },
      topPriority: [],
    };
  },
  computed: {
    isLoggedIn() { return auth.isLoggedIn; },
    userName() { return auth.state.user ? auth.state.user.username : ''; },
    periodLabel() {
      return { day: 'day', week: 'week (CW)', month: 'month', year: 'year' }[this.period];
    },
  },
  mounted() {
    this.loadAll();
  },
  methods: {
    logout() { auth.logout(); this.$router.push('/'); },
    async loadAll() {
      await Promise.all([
        this.loadSummary(), this.loadTrend(), this.loadWorkloadTemp(),
        this.loadTopProject(), this.loadBacklogTrend(), this.loadOperatorTrend(),
        this.loadTopPriority(),
      ]);
    },
    async loadSummary() {
      const { data } = await http.get('/dashboard/summary', { params: { period: this.period } });
      this.summary = data;
    },
    async loadTrend() {
      const { data } = await http.get('/dashboard/trend', { params: { period: this.period } });
      this.trend = {
        labels: data.series.map((r) => formatBucketLabel(r.bucket, this.period)),
        values: data.series.map((r) => Number(r.temp_slot_total)),
      };
    },
    async loadWorkloadTemp() {
      const { data } = await http.get('/dashboard/workload-temperature', { params: { status: this.workloadStatus } });
      this.workloadTemp = { labels: data.temperatures, series: data.series };
    },
    async loadTopProject() {
      const { data } = await http.get('/dashboard/top-project-load', { params: { period: this.period, limit: 10 } });
      this.topProject = {
        labels: data.data.map((r) => r.project_nr),
        values: data.data.map((r) => Number(r.qty)),
      };
    },
    async loadBacklogTrend() {
      const { data } = await http.get('/dashboard/backlog-aging-trend', { params: { weeks: 12 } });
      this.backlogTrend = {
        labels: data.data.map((r) => toCWLabel(r.week_start)),
        values: data.data.map((r) => Number(r.qty)),
      };
    },
    async loadOperatorTrend() {
      const { data } = await http.get('/dashboard/operator-load-trend', { params: { weeks: 12 } });
      const weekSet = [...new Set(data.data.map((r) => r.week_start))].sort();
      const labels = weekSet.map((w) => toCWLabel(w));
      const operatorNames = [...new Set(data.data.map((r) => r.operator_name))];
      const series = operatorNames.map((name) => ({
        name,
        values: weekSet.map((w) => {
          const match = data.data.find((r) => r.operator_name === name && r.week_start === w);
          return match ? Number(match.temp_slot) : 0;
        }),
      }));
      this.operatorTrend = { labels, series };
    },
    async loadTopPriority() {
      const { data } = await http.get('/dashboard/top-priority');
      this.topPriority = data.data;
    },
  },
};
</script>
