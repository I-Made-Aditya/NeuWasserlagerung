<template>
  <div class="app-shell">
    <div class="topbar">
      <div class="brand">
        <span class="brand-dot"></span>
        <h1>Kelola User</h1>
      </div>
      <div class="nav-links">
        <router-link to="/measurement-list">List Measurement</router-link>
        <router-link to="/">Dashboard</router-link>
        <a href="#" @click.prevent="logout">Logout</a>
      </div>
    </div>

    <div class="page">
      <div class="panel">
        <h3>Tambah Login Baru</h3>
        <form @submit.prevent="createUser" class="add-form-grid">
          <div class="form-group"><label>Username</label><input v-model="form.username" required /></div>
          <div class="form-group"><label>Password</label><input v-model="form.password" type="password" required /></div>
          <div class="form-group">
            <label>Role</label>
            <select v-model="form.role">
              <option value="operator">Operator</option>
              <option value="engineer">Engineer</option>
            </select>
          </div>
          <div class="form-group" v-if="form.role === 'operator'">
            <label>Operator</label>
            <select v-model="form.operator_id">
              <option :value="null">-</option>
              <option v-for="o in operators" :key="o.id" :value="o.id">{{ o.name }}</option>
            </select>
          </div>
          <div style="grid-column: span 4; text-align:right;">
            <button class="btn" type="submit">Buat Akun</button>
          </div>
        </form>
        <div v-if="error" class="error-text">{{ error }}</div>
      </div>

      <div class="panel">
        <h3>Daftar User</h3>
        <table>
          <thead><tr><th>Username</th><th>Role</th><th>Operator</th><th>Status</th><th>Aksi</th></tr></thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td>{{ u.username }}</td>
              <td>{{ u.role }}</td>
              <td>{{ u.operator_name || '-' }}</td>
              <td><span class="badge" :class="u.active ? 'finished' : 'yet'">{{ u.active ? 'Aktif' : 'Nonaktif' }}</span></td>
              <td><button class="btn secondary" @click="toggleActive(u)">{{ u.active ? 'Nonaktifkan' : 'Aktifkan' }}</button></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import http from '../api/http';
import auth from '../store/auth';

export default {
  name: 'UsersAdmin',
  data() {
    return {
      users: [],
      operators: [],
      error: '',
      form: { username: '', password: '', role: 'operator', operator_id: null },
    };
  },
  mounted() {
    this.fetchUsers();
    this.fetchOperators();
  },
  methods: {
    logout() { auth.logout(); this.$router.push('/'); },
    async fetchUsers() {
      const { data } = await http.get('/users');
      this.users = data;
    },
    async fetchOperators() {
      const { data } = await http.get('/operators');
      this.operators = data;
    },
    async createUser() {
      this.error = '';
      try {
        await http.post('/users', this.form);
        this.form = { username: '', password: '', role: 'operator', operator_id: null };
        this.fetchUsers();
      } catch (err) {
        this.error = (err.response && err.response.data && err.response.data.error) || 'Gagal membuat user';
      }
    },
    async toggleActive(u) {
      await http.patch(`/users/${u.id}`, { active: !u.active });
      this.fetchUsers();
    },
  },
};
</script>
