<template>
  <div class="app-shell">
    <div class="topbar">
      <div class="brand">
        <span class="brand-dot"></span>
        <h1>List Measurement</h1>
      </div>
      <div class="nav-links">
        <router-link to="/">Dashboard</router-link>
        <router-link v-if="isEngineer" to="/users">Kelola User</router-link>
        <a href="#" @click.prevent="logout">Logout ({{ userName }})</a>
      </div>
    </div>

    <div class="page">
      <div class="list-toolbar">
        <div class="month-nav">
          <button @click="changeMonth(-1)" title="Bulan sebelumnya">&lsaquo;</button>
          <span class="month-label">{{ monthLabel }}</span>
          <button @click="changeMonth(1)" title="Bulan berikutnya">&rsaquo;</button>
        </div>
        <button v-if="isEngineer" class="btn" @click="showForm = !showForm">
          {{ showForm ? 'Tutup Form' : '+ Tambah Project' }}
        </button>
      </div>

      <!-- Add form (engineer only) -->
      <div v-if="showForm" class="panel add-form-panel">
        <h3>Tambah Project Baru</h3>
        <form @submit.prevent="createMeasurement" class="add-form-grid">
          <div class="form-group"><label>Date In</label><input v-model="form.date_in" type="date" required /></div>
          <div class="form-group"><label>Project Nr</label><input v-model="form.project_nr" required /></div>
          <div class="form-group"><label>LOM Nr</label><input v-model="form.lom_nr" /></div>
          <div class="form-group"><label>Part Description</label><input v-model="form.part_description" /></div>
          <div class="form-group"><label>Type</label><input v-model="form.type" /></div>
          <div class="form-group"><label>Qty</label><input v-model.number="form.qty" type="number" min="0" /></div>
          <div class="form-group"><label>Bf/Af Test</label><input v-model="form.test_stage" /></div>
          <div class="form-group"><label>Reliability</label><input v-model="form.reliability" /></div>
          <div class="form-group" v-for="n in 7" :key="n">
            <label>T{{ n }} (°C)</label>
            <input v-model="form['t' + n + '_temp']" placeholder="mis. R25" />
          </div>
          <div class="form-group">
            <label>Operator</label>
            <select v-model="form.operator_id">
              <option :value="null">-</option>
              <option v-for="o in operators" :key="o.id" :value="o.id">{{ o.name }}</option>
            </select>
          </div>
          <div class="form-group"><label>Remark</label><input v-model="form.remark" /></div>
          <div class="form-group">
            <label>Priority (1-10, opsional)</label>
            <select v-model="form.priority">
              <option :value="null">-</option>
              <option v-for="n in 10" :key="n" :value="n">{{ n }}</option>
            </select>
          </div>
          <div class="form-group"><label>Plan Start</label><input v-model="form.planning_start" type="date" /></div>
          <div class="form-group"><label>Plan End</label><input v-model="form.planning_end" type="date" /></div>
          <div style="grid-column: span 4; text-align:right;">
            <button class="btn" type="submit">Simpan</button>
          </div>
        </form>
        <div v-if="formError" class="error-text">{{ formError }}</div>
      </div>

      <div class="list-card">
        <div class="list-card-header">
          <div class="entries-info">
            Showing {{ startIdx + 1 }} to {{ endIdx }} of {{ filteredRows.length }} items
            <span v-if="loading"> · memuat...</span>
          </div>
          <div class="search-box">
            <input v-model="search" placeholder="Search..." />
          </div>
        </div>

        <div class="table-scroll">
          <table class="data-table">
            <thead>
              <tr>
                <th v-for="col in columns" :key="col.key" :class="{ sorted: sortKey === col.key }" @click="sortBy(col.key)">
                  {{ col.label }} <span class="sort-arrow">{{ arrowFor(col.key) }}</span>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in pagedRows" :key="row.id">
                <td>{{ formatDate(row.date_in) }}</td>
                <td class="link-cell">{{ row.project_nr }}</td>
                <td class="link-cell">{{ row.lom_nr }}</td>
                <td>{{ row.part_description }}</td>
                <td>{{ row.type }}</td>
                <td>{{ row.qty }}</td>
                <td>{{ row.test_stage }}</td>
                <td v-for="n in 7" :key="n">{{ row['t' + n + '_temp'] || '-' }}</td>
                <td>{{ row.reliability }}</td>
                <td>
                  <select v-if="isLoggedIn" v-model="row.status" @change="updateStatus(row)">
                    <option v-for="s in STATUSES" :key="s" :value="s">{{ s }}</option>
                  </select>
                  <span v-else class="badge" :class="statusClass(row.status)">{{ row.status }}</span>
                </td>
                <td>
                  <select v-if="isLoggedIn" v-model="row.operator_id" @change="updateStatus(row)">
                    <option :value="null">-</option>
                    <option v-for="o in operators" :key="o.id" :value="o.id">{{ o.name }}</option>
                  </select>
                  <span v-else>{{ row.operator_name || '-' }}</span>
                </td>
                <td>
                  <select v-if="isEngineer" v-model="row.priority" @change="updatePriority(row)">
                    <option :value="null">-</option>
                    <option v-for="n in 10" :key="n" :value="n">{{ n }}</option>
                  </select>
                  <span v-else>{{ row.priority || '-' }}</span>
                </td>
                <td>{{ row.remark }}</td>
                <td>{{ formatDate(row.planning_start) }}</td>
                <td>{{ formatDate(row.planning_end) }}</td>
                <td>{{ formatDate(row.actual_start) }}</td>
                <td>{{ formatDate(row.actual_end) }}</td>
              </tr>
              <tr v-if="!pagedRows.length"><td :colspan="columns.length" class="empty-row">Tidak ada data untuk bulan ini</td></tr>
            </tbody>
          </table>
        </div>

        <div class="pagination-bar">
          <div class="per-page">
            Show
            <select v-model.number="perPage">
              <option :value="10">10</option>
              <option :value="25">25</option>
              <option :value="50">50</option>
              <option :value="100">100</option>
            </select>
            entries
          </div>
          <div class="pagination-controls">
            <button :disabled="page <= 1" @click="page--">Previous</button>
            <button v-for="p in totalPages" :key="p" :class="{ active: p === page }" @click="page = p">{{ p }}</button>
            <button :disabled="page >= totalPages" @click="page++">Next</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import http from '../api/http';
import auth from '../store/auth';

const STATUSES = ['Measurement Yet', 'Ongoing', 'Finished Measurement'];
const MONTH_NAMES = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];

const COLUMNS = [
  { key: 'date_in', label: 'Date In' },
  { key: 'project_nr', label: 'Project Nr' },
  { key: 'lom_nr', label: 'LOM Nr' },
  { key: 'part_description', label: 'Part Description' },
  { key: 'type', label: 'Type' },
  { key: 'qty', label: 'Qty' },
  { key: 'test_stage', label: 'Bf Test / Af Test' },
  { key: 't1_temp', label: 'T1 (°C)' },
  { key: 't2_temp', label: 'T2 (°C)' },
  { key: 't3_temp', label: 'T3 (°C)' },
  { key: 't4_temp', label: 'T4 (°C)' },
  { key: 't5_temp', label: 'T5 (°C)' },
  { key: 't6_temp', label: 'T6 (°C)' },
  { key: 't7_temp', label: 'T7 (°C)' },
  { key: 'reliability', label: 'Reliability' },
  { key: 'status', label: 'Status' },
  { key: 'operator_name', label: 'Operator' },
  { key: 'priority', label: 'Priority' },
  { key: 'remark', label: 'Remark' },
  { key: 'planning_start', label: 'Plan Start' },
  { key: 'planning_end', label: 'Plan End' },
  { key: 'actual_start', label: 'Actual Start' },
  { key: 'actual_end', label: 'Actual End' },
];

export default {
  name: 'MeasurementList',
  data() {
    const now = new Date();
    return {
      STATUSES,
      columns: COLUMNS,
      rows: [],
      operators: [],
      loading: false,
      year: now.getFullYear(),
      month: now.getMonth() + 1, // 1-12
      search: '',
      sortKey: 'date_in',
      sortDir: 'asc',
      page: 1,
      perPage: 10,
      showForm: false,
      formError: '',
      form: this.emptyForm(),
    };
  },
  computed: {
    isLoggedIn() { return auth.isLoggedIn; },
    isEngineer() { return auth.isEngineer; },
    userName() { return auth.state.user ? auth.state.user.username : ''; },
    monthLabel() { return `${MONTH_NAMES[this.month - 1]} ${this.year}`; },
    filteredRows() {
      let list = this.rows;
      if (this.search) {
        const q = this.search.toLowerCase();
        list = list.filter((r) => COLUMNS.some((c) => String(r[c.key] || '').toLowerCase().includes(q)));
      }
      const key = this.sortKey;
      const dir = this.sortDir === 'asc' ? 1 : -1;
      return [...list].sort((a, b) => {
        const av = a[key]; const bv = b[key];
        if (av == null && bv == null) return 0;
        if (av == null) return 1;
        if (bv == null) return -1;
        if (!isNaN(av) && !isNaN(bv)) return (Number(av) - Number(bv)) * dir;
        return String(av).localeCompare(String(bv)) * dir;
      });
    },
    totalPages() { return Math.max(1, Math.ceil(this.filteredRows.length / this.perPage)); },
    startIdx() { return (this.page - 1) * this.perPage; },
    endIdx() { return Math.min(this.startIdx + this.perPage, this.filteredRows.length); },
    pagedRows() { return this.filteredRows.slice(this.startIdx, this.endIdx); },
  },
  watch: {
    search() { this.page = 1; },
    perPage() { this.page = 1; },
  },
  mounted() {
    this.fetchOperators();
    this.fetchData();
  },
  methods: {
    emptyForm() {
      const f = {
        date_in: '', project_nr: '', lom_nr: '', part_description: '', type: '',
        qty: 0, test_stage: '', reliability: '',
        operator_id: null, remark: '', priority: null,
        planning_start: '', planning_end: '',
      };
      for (let n = 1; n <= 7; n++) f[`t${n}_temp`] = '';
      return f;
    },
    formatDate(d) { return d ? new Date(d).toLocaleDateString('id-ID') : '-'; },
    statusClass(s) {
      if (s === 'Ongoing') return 'ongoing';
      if (s === 'Finished Measurement') return 'finished';
      return 'yet';
    },
    logout() { auth.logout(); this.$router.push('/'); },
    changeMonth(delta) {
      let m = this.month + delta;
      let y = this.year;
      if (m > 12) { m = 1; y++; }
      if (m < 1) { m = 12; y--; }
      this.month = m; this.year = y;
      this.page = 1;
      this.fetchData();
    },
    sortBy(key) {
      if (this.sortKey === key) {
        this.sortDir = this.sortDir === 'asc' ? 'desc' : 'asc';
      } else {
        this.sortKey = key; this.sortDir = 'asc';
      }
    },
    arrowFor(key) {
      if (this.sortKey !== key) return '↕';
      return this.sortDir === 'asc' ? '↑' : '↓';
    },
    async fetchOperators() {
      const { data } = await http.get('/operators');
      this.operators = data;
    },
    async fetchData() {
      this.loading = true;
      try {
        const { data } = await http.get('/measurements', {
          params: { year: this.year, month: this.month },
        });
        this.rows = data.data;
      } finally {
        this.loading = false;
      }
    },
    async updateStatus(row) {
      try {
        await http.patch(`/measurements/${row.id}/status`, {
          status: row.status,
          operator_id: row.operator_id,
        });
      } catch (err) {
        alert((err.response && err.response.data && err.response.data.error) || 'Gagal update status');
        this.fetchData();
      }
    },
    async updatePriority(row) {
      try {
        await http.patch(`/measurements/${row.id}/priority`, { priority: row.priority });
      } catch (err) {
        alert((err.response && err.response.data && err.response.data.error) || 'Gagal update priority');
        this.fetchData();
      }
    },
    async createMeasurement() {
      this.formError = '';
      try {
        await http.post('/measurements', this.form);
        this.form = this.emptyForm();
        this.showForm = false;
        this.fetchData();
      } catch (err) {
        this.formError = (err.response && err.response.data && err.response.data.error) || 'Gagal menyimpan';
      }
    },
  },
};
</script>
