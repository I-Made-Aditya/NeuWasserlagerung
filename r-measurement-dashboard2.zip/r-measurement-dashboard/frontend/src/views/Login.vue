<template>
  <div class="login-box">
    <h2>R-Measurement Login</h2>
    <form @submit.prevent="handleLogin">
      <div class="form-group">
        <label>Username</label>
        <input v-model="username" type="text" required autofocus />
      </div>
      <div class="form-group">
        <label>Password</label>
        <input v-model="password" type="password" required />
      </div>
      <button class="btn" type="submit" style="width:100%" :disabled="loading">
        {{ loading ? 'Signing in...' : 'Login' }}
      </button>
      <div v-if="error" class="error-text">{{ error }}</div>
    </form>
    <p style="text-align:center; margin-top:14px;">
      <router-link to="/">&larr; Kembali ke Dashboard</router-link>
    </p>
  </div>
</template>

<script>
import auth from '../store/auth';

export default {
  name: 'Login',
  data() {
    return { username: '', password: '', error: '', loading: false };
  },
  methods: {
    async handleLogin() {
      this.error = '';
      this.loading = true;
      try {
        await auth.login(this.username, this.password);
        const redirect = this.$route.query.redirect || '/measurement-list';
        this.$router.push(redirect);
      } catch (err) {
        this.error = (err.response && err.response.data && err.response.data.error)
          || 'Login gagal, periksa username/password.';
      } finally {
        this.loading = false;
      }
    },
  },
};
</script>
