<template>
  <div style="position: relative; height: 260px;">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script>
import Chart from 'chart.js/auto';

export default {
  name: 'BarChart',
  props: {
    labels: { type: Array, default: () => [] },
    data: { type: Array, default: () => [] },
    label: { type: String, default: 'Value' },
    horizontal: { type: Boolean, default: false },
    color: { type: String, default: '#0f4c75' },
  },
  data() {
    return { chart: null };
  },
  watch: {
    labels() { this.render(); },
    data() { this.render(); },
  },
  mounted() {
    this.render();
  },
  beforeDestroy() {
    if (this.chart) this.chart.destroy();
  },
  methods: {
    render() {
      if (this.chart) this.chart.destroy();
      this.chart = new Chart(this.$refs.canvas, {
        type: 'bar',
        data: {
          labels: this.labels,
          datasets: [{
            label: this.label,
            data: this.data,
            backgroundColor: this.color,
          }],
        },
        options: {
          indexAxis: this.horizontal ? 'y' : 'x',
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
        },
      });
    },
  },
};
</script>
