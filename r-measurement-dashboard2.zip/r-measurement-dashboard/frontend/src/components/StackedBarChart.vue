<template>
  <div style="position: relative; height: 320px;">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script>
import Chart from 'chart.js/auto';

const PALETTE = [
  '#0f4c75', '#2563eb', '#3b9797', '#f5a623', '#e0554f',
  '#8b5cf6', '#16a34a', '#d97706', '#0891b2', '#be185d',
  '#6366f1', '#059669', '#9ca3af',
];

export default {
  name: 'StackedBarChart',
  props: {
    labels: { type: Array, default: () => [] },       // x-axis categories (temperatures)
    series: { type: Array, default: () => [] },        // [{ project: 'T130-000151', values: [..] }]
    yLabel: { type: String, default: 'Qty' },
  },
  data() {
    return { chart: null };
  },
  watch: {
    labels() { this.render(); },
    series() { this.render(); },
  },
  mounted() { this.render(); },
  beforeDestroy() { if (this.chart) this.chart.destroy(); },
  methods: {
    render() {
      if (this.chart) this.chart.destroy();
      const datasets = this.series.map((s, idx) => ({
        label: s.project,
        data: s.values,
        backgroundColor: s.project === 'Others' ? '#cbd2d9' : PALETTE[idx % PALETTE.length],
        stack: 'stack1',
        borderRadius: 3,
        maxBarThickness: 60,
      }));

      this.chart = new Chart(this.$refs.canvas, {
        type: 'bar',
        data: { labels: this.labels, datasets },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { position: 'right', labels: { boxWidth: 10, font: { size: 11 } } },
            tooltip: {
              callbacks: {
                footer: (items) => {
                  const total = items.reduce((sum, it) => sum + it.parsed.y, 0);
                  return `Total: ${total.toLocaleString('id-ID')}`;
                },
              },
            },
          },
          scales: {
            x: { stacked: true, title: { display: true, text: 'Temperature (°C)' }, grid: { display: false } },
            y: { stacked: true, title: { display: true, text: this.yLabel }, grid: { color: '#eef1f4' }, beginAtZero: true },
          },
        },
      });
    },
  },
};
</script>
