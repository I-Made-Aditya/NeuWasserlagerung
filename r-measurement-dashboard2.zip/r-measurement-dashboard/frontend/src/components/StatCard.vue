<template>
  <div class="stat-card" :class="variant">
    <div class="stat-icon">{{ icon }}</div>
    <div class="stat-body">
      <div class="label">{{ label }}</div>
      <div class="value">{{ formattedValue }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'StatCard',
  props: {
    label: { type: String, required: true },
    value: { type: [Number, String], default: 0 },
    variant: { type: String, default: '' },
    icon: { type: String, default: '' },
  },
  computed: {
    formattedValue() {
      const n = Number(this.value);
      return isNaN(n) ? this.value : n.toLocaleString('id-ID');
    },
  },
};
</script>
