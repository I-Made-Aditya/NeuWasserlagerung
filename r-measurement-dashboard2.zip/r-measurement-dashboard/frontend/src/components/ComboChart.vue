<template>
  <div style="position: relative; height: 300px;">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script>
import Chart from 'chart.js/auto';

export default {
  name: 'ComboChart',
  props: {
    labels: { type: Array, default: () => [] },
    data: { type: Array, default: () => [] },
    label: { type: String, default: 'Value' },
  },
  data() {
    return { chart: null };
  },
  watch: {
    labels() { this.render(); },
    data() { this.render(); },
  },
  mounted() { this.render(); },
  beforeDestroy() { if (this.chart) this.chart.destroy(); },
  methods: {
    render() {
      if (this.chart) this.chart.destroy();
      const ctx = this.$refs.canvas.getContext('2d');
      const gradient = ctx.createLinearGradient(0, 0, 0, 280);
      gradient.addColorStop(0, 'rgba(37, 99, 235, 0.35)');
      gradient.addColorStop(1, 'rgba(37, 99, 235, 0.02)');

      this.chart = new Chart(this.$refs.canvas, {
        data: {
          labels: this.labels,
          datasets: [
            {
              type: 'bar',
              label: this.label,
              data: this.data,
              backgroundColor: gradient,
              borderRadius: 6,
              maxBarThickness: 42,
              order: 2,
            },
            {
              type: 'line',
              label: `Trend ${this.label}`,
              data: this.data,
              borderColor: '#f5a623',
              backgroundColor: '#f5a623',
              borderWidth: 3,
              tension: 0.35,
              pointRadius: 4,
              pointBackgroundColor: '#fff',
              pointBorderColor: '#f5a623',
              pointBorderWidth: 2,
              fill: false,
              order: 1,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { display: true, position: 'top', labels: { boxWidth: 12, font: { size: 12 } } },
          },
          scales: {
            x: { grid: { display: false } },
            y: { grid: { color: '#eef1f4' }, beginAtZero: true },
          },
        },
      });
    },
  },
};
</script>
