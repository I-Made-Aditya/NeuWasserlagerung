<template>
  <div style="position: relative; height: 300px;">
    <canvas ref="canvas"></canvas>
  </div>
</template>

<script>
import Chart from 'chart.js/auto';

const COLORS = ['#0f4c75', '#f5a623', '#e0554f', '#16a34a', '#8b5cf6', '#0891b2'];

export default {
  name: 'MultiLineChart',
  props: {
    labels: { type: Array, default: () => [] },   // CW labels
    series: { type: Array, default: () => [] },    // [{ name: 'Kenya', values: [..] }]
    yLabel: { type: String, default: 'Temp Slot' },
  },
  data() {
    return { chart: null };
  },
  watch: {
    labels() { this.render(); },
    series() { this.render(); },
  },
  mounted() { this.render(); },
  beforeDestroy() { if (this.chart) this.chart.destroy(); },
  methods: {
    render() {
      if (this.chart) this.chart.destroy();
      const datasets = this.series.map((s, idx) => ({
        label: s.name,
        data: s.values,
        borderColor: COLORS[idx % COLORS.length],
        backgroundColor: COLORS[idx % COLORS.length],
        tension: 0.3,
        pointRadius: 4,
        pointHoverRadius: 6,
        borderWidth: 2.5,
        fill: false,
      }));

      this.chart = new Chart(this.$refs.canvas, {
        type: 'line',
        data: { labels: this.labels, datasets },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { position: 'top', labels: { boxWidth: 12, font: { size: 12 } } },
          },
          scales: {
            x: { title: { display: true, text: 'Calendar Week' }, grid: { display: false } },
            y: { title: { display: true, text: this.yLabel }, grid: { color: '#eef1f4' }, beginAtZero: true },
          },
        },
      });
    },
  },
};
</script>
