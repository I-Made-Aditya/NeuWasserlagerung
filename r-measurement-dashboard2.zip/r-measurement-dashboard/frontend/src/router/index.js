import Vue from 'vue';
import VueRouter from 'vue-router';
import auth from '../store/auth';

import Dashboard from '../views/Dashboard.vue';
import Login from '../views/Login.vue';
import MeasurementList from '../views/MeasurementList.vue';
import UsersAdmin from '../views/UsersAdmin.vue';

Vue.use(VueRouter);

const routes = [
  { path: '/', name: 'Dashboard', component: Dashboard }, // public, per requirement
  { path: '/login', name: 'Login', component: Login },
  {
    path: '/measurement-list',
    name: 'MeasurementList',
    component: MeasurementList,
    meta: { requiresAuth: true },
  },
  {
    path: '/users',
    name: 'UsersAdmin',
    component: UsersAdmin,
    meta: { requiresAuth: true, requiresEngineer: true },
  },
];

const router = new VueRouter({
  mode: 'history',
  routes,
});

router.beforeEach((to, from, next) => {
  if (to.meta.requiresAuth && !auth.isLoggedIn) {
    next({ name: 'Login', query: { redirect: to.fullPath } });
  } else if (to.meta.requiresEngineer && !auth.isEngineer) {
    next({ name: 'MeasurementList' });
  } else {
    next();
  }
});

export default router;
