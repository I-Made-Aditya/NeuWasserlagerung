# Voltage Monitoring System — Full Stack

Aplikasi monitoring & logging tegangan DC untuk instrumen **Keithley DAQ6510**
dan **GWInstek DAQ9600** (mode pengukuran **2-Wire** / **4-Wire**), dengan
frontend Vue 3 (UI dipertahankan sesuai desain asli) dan backend FastAPI +
PostgreSQL.

```
voltage-monitoring/
├── frontend/          Vue 3 app (UI asli, sekarang terhubung ke backend via API)
├── backend/           FastAPI + SQLAlchemy + JWT auth + DAQ drivers
└── docker-compose.yml Menjalankan PostgreSQL + backend sekaligus
```

## Quick start (paling cepat, pakai Docker)

```bash
cd voltage-monitoring
cp backend/.env.example backend/.env
# (opsional) edit backend/.env sesuai kebutuhan Anda
docker compose up --build
```

Backend akan otomatis membuat schema `monitoringdaq`, semua tabel, dan
2 user default (`admin` / `engineer`) — lihat kredensial di `backend/README.md`.

Lalu jalankan frontend secara terpisah (Vue CLI dev-server):

```bash
cd frontend
cp .env.example .env      # sudah diisi default http://localhost:8000/api
npm install
npm run serve
```

Buka **http://localhost:8080** dan login dengan salah satu akun default.

## Tanpa Docker

Ikuti instruksi detail di:
- `backend/README.md` — setup Python venv, PostgreSQL, migrasi/schema, menjalankan uvicorn
- Bagian **frontend** di bawah ini

### Frontend (tanpa Docker)

```bash
cd frontend
npm install
npm run serve       # dev server di http://localhost:8080
# atau
npm run build        # build produksi ke frontend/dist
```

## Ringkasan perubahan dari versi awal

1. **Struktur ulang style** — semua `<style>` di dalam file `.vue` dipindahkan
   ke satu file `frontend/src/assets/main.css`. Setiap komponen `.vue`
   sekarang hanya berisi `<template>` dan `<script>`.
2. **Login & Role-based access** — halaman login baru (`LoginView.vue`),
   header menampilkan nama user + badge role + tombol logout. Role
   `administrator` bisa CRUD penuh (Settings, Add, Delete, Release Alarm,
   Test Connection); role `engineer` hanya bisa melihat (Data, Graph, Detail)
   — tombol konfigurasi otomatis disembunyikan, dan backend juga menolak
   (`403 Forbidden`) permintaan tulis dari role engineer sebagai lapisan
   keamanan kedua.
3. **Backend FastAPI** — CRUD konfigurasi, histori data, alarm, autentikasi
   JWT, serta endpoint trigger DAQ sesuai contoh yang diminta:
   `POST /api/{equipment_type}/{ip_address}/{wire_mode}`
   (mis. `POST /api/DAQ6510/192.168.1.101/4-wire`).
   Dokumentasi otomatis (Swagger) tersedia di `http://localhost:8000/docs`.
4. **Database PostgreSQL** — seluruh tabel berada di schema `monitoringdaq`
   (bukan `public`), sesuai batasan IT. Tersedia baik SQL manual
   (`backend/db/schema.sql`) maupun auto-provisioning saat backend start.
5. **DAQ driver abstraction** — `backend/app/daq_drivers/` berisi driver
   template untuk kedua instrumen (SCPI-over-LAN) plus fallback simulator
   otomatis (`REAL_DAQ_MODE=false` secara default) sehingga seluruh sistem
   bisa langsung dites tanpa hardware fisik.
6. **Background monitoring loop** — mengaktifkan toggle "Active" pada
   Settings modal otomatis menyalakan proses logging berkala (sesuai
   `interval`) di backend, menulis ke `measurement_data`, dan membuka
   `alarm_events` bila nilai keluar dari rentang Min/Max.

Detail lebih lanjut & seluruh daftar endpoint ada di `backend/README.md`.
