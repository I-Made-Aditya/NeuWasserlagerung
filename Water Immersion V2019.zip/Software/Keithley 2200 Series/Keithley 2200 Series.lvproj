<?xml version='1.0'?>
<Project Type="Project" LVVersion="8208000">
   <Property Name="CCSymbols" Type="Str"></Property>
   <Property Name="Instrument Driver" Type="Str">True</Property>
   <Property Name="NI.Project.Description" Type="Str">This project is used by developers to edit API and example files for LabVIEW Plug and Play instrument drivers.</Property>
   <Item Name="My Computer" Type="My Computer">
      <Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
      <Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
      <Property Name="server.tcp.enabled" Type="Bool">false</Property>
      <Property Name="server.tcp.port" Type="Int">0</Property>
      <Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
      <Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
      <Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
      <Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
      <Property Name="specify.custom.address" Type="Bool">false</Property>
      <Item Name="Examples" Type="Folder">
         <Item Name="Keithley 2200 Series Create and Save a List.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Examples/Keithley 2200 Series Create and Save a List.vi"/>
         <Item Name="Keithley 2200 Series Execute a List.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Examples/Keithley 2200 Series Execute a List.vi"/>
         <Item Name="Keithley 2200 Series Monitor Output.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Examples/Keithley 2200 Series Monitor Output.vi"/>
         <Item Name="Keithley 2200 Series Output List File Settings.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Examples/Keithley 2200 Series Output List File Settings.vi"/>
         <Item Name="Keithley 2200 Series Save Instrument Settings.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Examples/Keithley 2200 Series Save Instrument Settings.vi"/>
         <Item Name="Keithley 2200 Series.bin3" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Examples/Keithley 2200 Series.bin3"/>
      </Item>
      <Item Name="Keithley 2200 Series.lvlib" Type="Library" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Keithley 2200 Series.lvlib">
         <Item Name="Public" Type="Folder">
            <Item Name="Action-Status" Type="Folder">
               <Item Name="Action_Status.mnu" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Action_Status.mnu"/>
               <Item Name="Enable Digital Port.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Enable Digital Port.vi"/>
               <Item Name="Enable Output.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Enable Output.vi"/>
               <Item Name="Output Protection Status.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Output Protection Status.vi"/>
               <Item Name="Query Status.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Query Status.vi"/>
               <Item Name="Read List Name.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Read List Name.vi"/>
               <Item Name="Read List Operation.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Read List Operation.vi"/>
               <Item Name="Save-Recall Setup.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Save-Recall Setup.vi"/>
               <Item Name="Status Register.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Action-Status/Status Register.vi"/>
            </Item>
            <Item Name="Configure" Type="Folder">
               <Item Name="Low Level" Type="Folder">
                  <Item Name="Configure_Low_Level.mnu" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Low Level/Configure_Low_Level.mnu"/>
                  <Item Name="Configure Trigger.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Low Level/Configure Trigger.vi"/>
               </Item>
               <Item Name="Configure.mnu" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure.mnu"/>
               <Item Name="Configure List Name.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure List Name.vi"/>
               <Item Name="Configure List Operation.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure List Operation.vi"/>
               <Item Name="Configure List Step Parameter.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure List Step Parameter.vi"/>
               <Item Name="Configure Output Range.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure Output Range.vi"/>
               <Item Name="Configure Output.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure Output.vi"/>
               <Item Name="Configure OVP.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure OVP.vi"/>
               <Item Name="Configure Port.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure Port.vi"/>
               <Item Name="Configure Power Supply Mode.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/Configure Power Supply Mode.vi"/>
               <Item Name="RI DFI Operation.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Configure/RI DFI Operation.vi"/>
            </Item>
            <Item Name="Data" Type="Folder">
               <Item Name="Data.mnu" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Data/Data.mnu"/>
               <Item Name="Read List Step Parameter.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Data/Read List Step Parameter.vi"/>
               <Item Name="Read Output.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Data/Read Output.vi"/>
               <Item Name="Read RI and DFI Mode.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Data/Read RI and DFI Mode.vi"/>
            </Item>
            <Item Name="Utility" Type="Folder">
               <Item Name="Utility.mnu" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Utility/Utility.mnu"/>
               <Item Name="Configure Output Timer.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Utility/Configure Output Timer.vi"/>
               <Item Name="Control Mode.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Utility/Control Mode.vi"/>
               <Item Name="Error Query.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Utility/Error Query.vi"/>
               <Item Name="Reset.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Utility/Reset.vi"/>
               <Item Name="Revision Query.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Utility/Revision Query.vi"/>
            </Item>
            <Item Name="Close.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Close.vi"/>
            <Item Name="Initialize.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/Initialize.vi"/>
            <Item Name="VI Tree.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/VI Tree.vi"/>
            <Item Name="dir.mnu" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Public/dir.mnu"/>
         </Item>
         <Item Name="Private" Type="Folder">
            <Item Name="Default Instrument Setup.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Private/Default Instrument Setup.vi"/>
         </Item>
         <Item Name="Keithley 2200 Series Readme.html" Type="Document" URL="/&lt;instrlib&gt;/Keithley 2200 Series/Keithley 2200 Series Readme.html"/>
      </Item>
      <Item Name="Dependencies" Type="Dependencies"/>
      <Item Name="Build Specifications" Type="Build">
         <Item Name="Ke2200" Type="Zip File">
            <Property Name="Absolute[0]" Type="Bool">false</Property>
            <Property Name="BuildName" Type="Str">Ke2200</Property>
            <Property Name="Comments" Type="Str"></Property>
            <Property Name="DestinationID[0]" Type="Str">{9390EBC0-59D0-469C-BAAA-15A2D72EC507}</Property>
            <Property Name="DestinationItemCount" Type="Int">1</Property>
            <Property Name="DestinationName[0]" Type="Str">Destination Directory</Property>
            <Property Name="IncludedItemCount" Type="Int">1</Property>
            <Property Name="IncludedItems[0]" Type="Ref">/My Computer</Property>
            <Property Name="IncludeProject" Type="Bool">true</Property>
            <Property Name="Path[0]" Type="Path">../../builds/Keithley 2200 Series Power Supplies/My Zip File/Keithley 2200 Series Power Supplies.zip</Property>
            <Property Name="ZipBase" Type="Str">NI_zipbasedefault</Property>
         </Item>
      </Item>
   </Item>
</Project>
