﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="17008000">
	<Property Name="Instrument Driver" Type="Str">True</Property>
	<Property Name="NI.Project.Description" Type="Str">This project is used by developers to edit API and example files for LabVIEW Plug and Play instrument drivers.</Property>
	<Item Name="My Computer" Type="My Computer">
		<Property Name="CCSymbols" Type="Str">OS,Win;CPU,x86;</Property>
		<Property Name="NI.SortType" Type="Int">3</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="Examples" Type="Folder">
			<Item Name="Keithley 27XX Advanced Scan.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Advanced Scan.vi"/>
			<Item Name="Keithley 27XX Connect and Read Buffer.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Connect and Read Buffer.vi"/>
			<Item Name="Keithley 27XX Continuous Multi Read.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Continuous Multi Read.vi"/>
			<Item Name="Keithley 27XX Data Information.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Data Information.vi"/>
			<Item Name="Keithley 27XX Finite Multi Read.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Finite Multi Read.vi"/>
			<Item Name="Keithley 27XX Math Measurement.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Math Measurement.vi"/>
			<Item Name="Keithley 27XX Performance.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Performance.vi"/>
			<Item Name="Keithley 27XX Single Measurement.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Single Measurement.vi"/>
			<Item Name="Keithley 27XX Temperature (Thermocouple).vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Temperature (Thermocouple).vi"/>
			<Item Name="Keithley 27XX Totalizer.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Totalizer.vi"/>
			<Item Name="Keithley 27XX Acquire and Graph Time Measurement Data.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX Acquire and Graph Time Measurement Data.vi"/>
			<Item Name="Keithley 27XX.bin3" Type="Document" URL="/&lt;instrlib&gt;/Keithley 27XX/Examples/Keithley 27XX.bin3"/>
		</Item>
		<Item Name="Keithley 27XX.lvlib" Type="Library" URL="../Keithley 27XX.lvlib"/>
		<Item Name="VI Tree.vi" Type="VI" URL="/&lt;instrlib&gt;/Keithley 27XX/Public/VI Tree.vi"/>
		<Item Name="Dependencies" Type="Dependencies">
			<Item Name="Keithley 27XX.lvlib" Type="Library" URL="../../../03 - RT 2014SW/V1.1/Software/Sub VIs/Keithley 27XX/Keithley 27XX.lvlib"/>
			<Item Name="Error Query (Multiple).vi" Type="VI" URL="../../../03 - RT 2014SW/V1.1/Software/Sub VIs/Keithley 27XX/Public/Utility/Error Query (Multiple).vi"/>
		</Item>
		<Item Name="Build Specifications" Type="Build"/>
	</Item>
</Project>
